// Cache ONLY the static application shell. No Notion API, signed CDN URLs,
// tokens, decrypted bytes, or mutable user data are cached by this worker.
const CACHE = "ndrive-web-shell-1.1.8-rc3-web1";
const ASSETS = ["./index.html", "./app.js", "./styles.css", "./web-bootstrap.js", "./web-config.js", "./web-storage.js", "./site.webmanifest", "./icons/ndrive.svg", "./vendor/mpegts.js", "./crypto.js", "./zip-store.js", "./encrypted-flv-range.js", "./encrypted-mp3.js", "./encrypted-mse-video.js", "./flac-progressive.js", "./memory-media-source.js", "./mp4-progressive.js", "./ndrv1-random-reader.js", "./range-http.js", "./preview-media-enhancements.js", "./_locales/zh_TW/messages.json", "./_locales/en/messages.json"];
self.addEventListener("install", event => event.waitUntil(
  caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting())
));
self.addEventListener("activate", event => event.waitUntil(
  caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith("ndrive-web-shell-") && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())
));
self.addEventListener("fetch", event => {
  const req = event.request, url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== self.location.origin || !url.pathname.startsWith(new URL(self.registration.scope).pathname)) return;
  if (url.search && req.mode !== "navigate") return;
  if (req.mode === "navigate") {
    event.respondWith(fetch(req).catch(() => caches.match("./index.html")));
    return;
  }
  event.respondWith(caches.match(req).then(cached => cached || fetch(req)));
});
