// Web-only storage: IndexedDB for encrypted profiles/cache; sessionStorage for tab session.
// This is per-origin browser storage, never shared with the Chrome extension.
const DATABASE = "notion-drive-web-1.1.4";
const STORE = "local";
let databasePromise;
function openDB() {
  if (!databasePromise) databasePromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("IndexedDB 無法開啟"));
  });
  return databasePromise;
}
function transaction(mode, operation) {
  return openDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, mode);
    const store = tx.objectStore(STORE);
    let value;
    try { value = operation(store); } catch (e) { tx.abort(); reject(e); return; }
    tx.oncomplete = () => resolve(value);
    tx.onerror = () => reject(tx.error || new Error("IndexedDB 寫入失敗"));
    tx.onabort = () => reject(tx.error || new Error("IndexedDB 已取消"));
  }));
}
export function createWebStorageAreas() {
  return {
    local: {
      async get(keys) {
        const db = await openDB();
        return new Promise((resolve, reject) => {
          const tx = db.transaction(STORE, "readonly"), store = tx.objectStore(STORE), results = {};
          for (const k of keys) {
            const r = store.get(k);
            r.onsuccess = () => { results[k] = r.result; };
          }
          tx.oncomplete = () => resolve(results);
          tx.onerror = () => reject(tx.error || new Error("IndexedDB 讀取失敗"));
        });
      },
      set(values) { return transaction("readwrite", store => {
        for (const [key, value] of Object.entries(values)) store.put(value, key);
      }); },
      remove(keys) { return transaction("readwrite", store => {
        for (const key of keys) store.delete(key);
      }); },
    },
    session: {
      async get(keys) {
        const out = {};
        for (const key of keys) {
          const raw = sessionStorage.getItem(`ndrive:web:session:${key}`);
          try { out[key] = raw === null ? undefined : JSON.parse(raw); }
          catch { out[key] = undefined; }
        }
        return out;
      },
      async set(values) {
        for (const [key, value] of Object.entries(values))
          sessionStorage.setItem(`ndrive:web:session:${key}`, JSON.stringify(value));
      },
      async remove(keys) {
        for (const key of keys) sessionStorage.removeItem(`ndrive:web:session:${key}`);
      },
    },
  };
}
