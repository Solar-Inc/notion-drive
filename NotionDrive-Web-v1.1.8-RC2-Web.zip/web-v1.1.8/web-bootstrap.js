import { config } from "./web-config.js";
// Bootstrap must complete BEFORE importing app.js (which starts init at module load).
const locale = (navigator.language || "zh-TW").toLowerCase().startsWith("zh") ? "zh_TW" : "en";
let messages;
try {
  const res = await fetch(`./_locales/${locale}/messages.json`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  messages = await res.json();
} catch (error) {
  document.body.textContent = `無法載入語系檔：${error.message}`;
  throw error;
}
globalThis.__NDRIVE_WEB_MODE__ = true;
globalThis.__NDRIVE_API_BASE__ = config.apiBase;
globalThis.__NDRIVE_I18N__ = {
  locale: locale === "zh_TW" ? "zh-TW" : "en",
  getMessage(key, substitutions) {
    let result = messages[key]?.message || "";
    const args = Array.isArray(substitutions) ? substitutions : substitutions == null ? [] : [substitutions];
    // Chrome i18n supports both $1 and named placeholders such as $COUNT$.
    const entry = messages[key];
    if (entry?.placeholders) {
      result = result.replace(/\$([A-Za-z_][A-Za-z0-9_]*)\$/g, (match, name) => {
        const placeholder = Object.entries(entry.placeholders).find(([k]) => k.toLowerCase() === name.toLowerCase())?.[1];
        if (!placeholder) return match;
        return String(placeholder.content || "").replace(/\$(\d+)/g,
          (inner, index) => String(args[Number(index) - 1] ?? ""));
      });
    }
    result = result.replace(/\$\$|\$(\d+)/g, (match, index) =>
      match === "$$" ? "$" : String(args[Number(index) - 1] ?? ""));
    return result;
  },
};
const proxy = (config.cdnProxyBase || "").trim();
if (proxy && new URL(proxy).protocol !== "https:")
  throw new Error("CDN Proxy 必須使用 HTTPS 網址");
globalThis.__NDRIVE_FETCH_URL__ = (raw) => {
  if (!proxy) return raw;
  const u = new URL(raw);
  if (u.protocol !== "https:") throw new Error("CDN 僅接受 HTTPS");
  return `${proxy}${proxy.includes("?") ? "&" : "?"}url=${encodeURIComponent(u.href)}`;
};
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(err => console.warn("PWA 未啟用：", err));
}
await import("./app.js");
