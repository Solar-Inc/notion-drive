/** Exact, bounded HTTP Range reads. No credentials or remote executable code. */
export function abortError() {
  return new DOMException('媒體讀取已取消', 'AbortError');
}

export function abortableDelay(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(abortError());
    const cancel = () => { clearTimeout(timer); reject(abortError()); };
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', cancel);
      resolve();
    }, ms);
    signal?.addEventListener('abort', cancel, {once: true});
  });
}

export async function readExactHttpRange(url, start, end, {
  signal, fetchImpl = globalThis.fetch, timeoutMs = 45_000,
  maxAttempts = 3, delay = abortableDelay,
} = {}) {
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end <= start)
    throw new Error('HTTP Range 範圍無效');
  if (new URL(url).protocol !== 'https:' && !/^http:\/\/(127\.0\.0\.1|localhost)(:|\/)/.test(url))
    throw new Error('遠端媒體必須使用 HTTPS');
  const wanted = end - start;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (signal?.aborted) throw abortError();
    const controller = new AbortController();
    const cancel = () => controller.abort();
    signal?.addEventListener('abort', cancel, {once: true});
    let timedOut = false, response = null, reader = null;
    const timer = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
    try {
      response = await fetchImpl(url, {
        headers: {Range: `bytes=${start}-${end - 1}`}, signal: controller.signal,
        cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer',
      });
      if (response.status !== 206) {
        const error = new Error(`媒體 Range 讀取失敗：HTTP ${response.status}（需要 206）`);
        error.status = response.status;
        error.expired = [401, 403, 404].includes(response.status);
        error.retryable = [408, 429, 500, 502, 503, 504, 529].includes(response.status);
        const retry = response.headers.get('Retry-After');
        if (retry) error.retryMs = Math.min(15_000, Math.max(0, Number(retry) * 1000 || Date.parse(retry) - Date.now() || 0));
        throw error;
      }
      const match = (response.headers.get('Content-Range') || '').match(/^bytes\s+(\d+)-(\d+)\/(\d+)$/i);
      if (!match || Number(match[1]) !== start || Number(match[2]) !== end - 1 ||
          !Number.isSafeInteger(Number(match[3])) || Number(match[3]) < end)
        throw new Error('伺服器回傳的 Content-Range 不符，已停止讀取');
      const length = response.headers.get('Content-Length');
      if (length !== null && (!/^\d+$/.test(length) || Number(length) !== wanted))
        throw new Error('伺服器回傳的 Range 長度不符，已停止讀取');
      if (!response.body?.getReader) throw new Error('媒體回應缺少可讀取的串流');
      reader = response.body.getReader();
      const result = new Uint8Array(wanted);
      let received = 0;
      while (true) {
        const {done, value} = await reader.read();
        if (done) break;
        if (received + value.byteLength > wanted) throw new Error('伺服器回傳超量 Range 資料，已取消下載');
        result.set(value, received);
        received += value.byteLength;
      }
      if (received !== wanted) throw new Error(`Range 資料截斷：${received} / ${wanted}`);
      if (signal?.aborted) throw abortError();
      return result;
    } catch (error) {
      if (signal?.aborted) throw abortError();
      const retryable = timedOut || error instanceof TypeError || error.retryable;
      if (!retryable || attempt + 1 >= maxAttempts) {
        if (timedOut) throw new Error('媒體 Range 讀取逾時，請檢查網路後重新開啟預覽');
        throw error;
      }
      // Dispose the failed response before waiting or retrying.
      controller.abort();
      if (reader) await reader.cancel().catch(() => {});
      else await response?.body?.cancel().catch(() => {});
      clearTimeout(timer);
      await delay(error.retryMs ?? Math.min(4000, 500 * 2 ** attempt), signal);
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', cancel);
      if (reader) { await reader.cancel().catch(() => {}); reader.releaseLock(); }
      else await response?.body?.cancel().catch(() => {});
    }
  }
  throw new Error('媒體 Range 重試次數無效');
}

/** Coalesce URL refreshes and allow later expiries during long recordings. */
export function createRefreshingRangeReader({load, refresh, signal}) {
  let generation = 0, refreshing = null;
  return async (...args) => {
    const version = generation;
    try { return await load(...args); }
    catch (error) {
      if (!error.expired || signal?.aborted) throw error;
      if (version === generation) {
        refreshing ||= Promise.resolve().then(refresh).then(() => { generation++; }).finally(() => { refreshing = null; });
        await refreshing;
      }
      if (signal?.aborted) throw abortError();
      return load(...args);
    }
  };
}
