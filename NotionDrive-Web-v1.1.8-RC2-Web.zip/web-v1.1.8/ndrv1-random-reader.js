/** NDRVENC1 range-decryption proof of concept. No mutation of crypto.js.
 * One physical NDRVENC1 encrypted volume ONLY. Multi-volume and shards must be mapped externally.
 * readRange(start,endExclusive) must return EXACT bytes; it may use HTTP Range or local Blob.slice.
 */
const MAGIC=new TextEncoder().encode('NDRVENC1');
const INFO=new TextEncoder().encode('Notion Drive encrypted file v1');
export async function openEncryptedVolume({readRange, vmk, signal=null}) {
 if(typeof readRange!=='function'||!(vmk instanceof Uint8Array)||vmk.length!==32)throw new Error('readRange 或 VMK 無效');
 const check=()=>{if(signal?.aborted)throw new DOMException('影片已關閉','AbortError');};
 check();
 async function exactly(a,b,operationSignal=signal) {
   check();
   if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a<0||b<=a)throw new Error('不安全的位元組範圍');
   const bytes=await readRange(a,b,operationSignal);
   check();
   const buf=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);
   if(buf.length!==b-a)throw new Error(`伺服器未回傳指定 Range (${b-a})；實得 ${buf.length}`);
   return buf;
 }
 const fixed=await exactly(0,49);
 if(!MAGIC.every((b,i)=>fixed[i]===b)||fixed[8]!==1)throw new Error('不是 NDRVENC1 卷');
 const view=new DataView(fixed.buffer,fixed.byteOffset,fixed.byteLength);
 const chunkSize=view.getUint32(9,false), sizeBig=view.getBigUint64(13,false);
 if(sizeBig>BigInt(Number.MAX_SAFE_INTEGER) || !chunkSize || chunkSize>64*1024*1024)throw new Error('不支援的密文區塊設定');
 const plainSize=Number(sizeBig),salt=fixed.slice(21,37),ivPrefix=fixed.slice(37,45);
 const nameLen=view.getUint16(45,false),mimeLen=view.getUint16(47,false),headerBytes=49+nameLen+mimeLen;
 const variable=headerBytes>49?await exactly(49,headerBytes):new Uint8Array(),header=new Uint8Array(headerBytes);
 header.set(fixed);header.set(variable,49);
 const material=await crypto.subtle.importKey('raw',vmk,'HKDF',false,['deriveKey']);
 const key=await crypto.subtle.deriveKey({name:'HKDF',hash:'SHA-256',salt,info:INFO},material,{name:'AES-GCM',length:256},false,['decrypt']);
 check();
 const count=Math.ceil(plainSize/chunkSize);
 // A tiny playback-local authenticated block cache eliminates repeated 8 MiB
 // downloads during MP4 box probing and adjacent fragment reads.  At most 2
 // plaintext blocks are kept and nothing is persisted to disk.
 const blocks=new Map(),inflight=new Map();let disposed=false;
 const closedController=new AbortController();
 function waitForConsumer(promise,signal){
   if(!signal)return promise;
   if(signal.aborted)return Promise.reject(new DOMException('影片請求已取消','AbortError'));
   return new Promise((resolve,reject)=>{
     const abort=()=>{cleanup();reject(new DOMException('影片請求已取消','AbortError'));};
     const cleanup=()=>signal.removeEventListener('abort',abort);
     signal.addEventListener('abort',abort,{once:true});
     promise.then(v=>{cleanup();signal.aborted?reject(new DOMException('影片請求已取消','AbortError')):resolve(v);},e=>{cleanup();reject(e);});
   });
 }
 async function decryptChunk(index,signal=null){
   if(disposed)throw new DOMException('影片已關閉','AbortError');
   if(signal?.aborted)throw new DOMException('影片請求已取消','AbortError');
   if(!Number.isSafeInteger(index)||index<0||index>=count)throw new Error('區塊索引超出範圍');
   if(blocks.has(index)){
     const cached=blocks.get(index);blocks.delete(index);blocks.set(index,cached);return cached;
   }
   if(!inflight.has(index)){
     // Shared fetch belongs to the volume lifetime, not any single seeker.
     // Aborting a fast seek must not cancel an overlapping preload request.
     const promise=(async()=>{
       const len=Math.min(chunkSize,plainSize-index*chunkSize);
       const start=headerBytes+index*(chunkSize+16);
       const cipher=await exactly(start,start+len+16,closedController.signal);
       const iv=new Uint8Array(12);iv.set(ivPrefix);
       new DataView(iv.buffer).setUint32(8,index,false);
       let plain;
       try{
         plain=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv,additionalData:header,tagLength:128},key,cipher));
       }catch(error){throw new Error('GCM 驗證失敗，密文可能損壞，拒絕播放');}
       if(disposed)throw new DOMException('影片已關閉','AbortError');
       blocks.set(index,plain);
       while(blocks.size>2)blocks.delete(blocks.keys().next().value);
       return plain;
     })().finally(()=>inflight.delete(index));
     inflight.set(index,promise);
   }
   return waitForConsumer(inflight.get(index),signal);
 }
 async function decryptRange(start,endExclusive,signal=null){
   if(!Number.isSafeInteger(start)||!Number.isSafeInteger(endExclusive)||start<0||endExclusive>plainSize||endExclusive<=start)throw new Error('指定明文 Range 不合法');
   const chunks=[];let total=0;
   for(let idx=Math.floor(start/chunkSize);idx<=Math.floor((endExclusive-1)/chunkSize);idx++){
      const chunk=await decryptChunk(idx,signal),offset=idx*chunkSize;
      if(disposed||signal?.aborted)throw new DOMException('影片請求已取消','AbortError');
      const a=Math.max(start,offset)-offset,b=Math.min(endExclusive,offset+chunk.length)-offset;
      chunks.push(chunk.subarray(a,b));total+=b-a;
   }
   if(disposed||signal?.aborted)throw new DOMException('影片請求已取消','AbortError');
   const result=new Uint8Array(total);let o=0;for(const c of chunks){result.set(c,o);o+=c.length;}return result;
 }
 return {headerBytes,plainSize,chunkSize,chunkCount:count,decryptChunk,decryptRange,close(){disposed=true;closedController.abort();for(const bytes of blocks.values())bytes.fill(0);blocks.clear();inflight.clear();}};
}
