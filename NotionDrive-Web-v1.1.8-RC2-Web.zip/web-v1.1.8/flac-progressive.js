const te=new TextEncoder();
const u16=(b,p)=>((b[p]<<8)|b[p+1])>>>0;
const u24=(b,p)=>((b[p]<<16)|(b[p+1]<<8)|b[p+2])>>>0;
const u32=(b,p)=>(b[p]*16777216+b[p+1]*65536+b[p+2]*256+b[p+3])>>>0;
const n32=n=>Uint8Array.of(n>>>24&255,n>>>16&255,n>>>8&255,n&255);
const n64=n=>new Uint8Array([...n32(Math.floor(n/4294967296)),...n32(n>>>0)]);
const cat=(...bs)=>{const len=bs.reduce((s,b)=>s+b.length,0),out=new Uint8Array(len);let p=0;for(const b of bs){out.set(b,p);p+=b.length;}return out;};
const box=(name,...bs)=>{const data=cat(...bs);return cat(n32(data.length+8),te.encode(name),data);};
const full=(name,flags,...bs)=>box(name,n32(flags),...bs);
const set32=(b,p,n)=>b.set(n32(n),p);
const entries=(b,start=0,end=b.length)=>{const out=[];for(let p=start;p+8<=end;){let size=u32(b,p);if(size<8||p+size>end)throw Error('無效 MP4 box');out.push({type:new TextDecoder().decode(b.subarray(p+4,p+8)),start:p,end:p+size,body:p+8});p+=size;}return out;};
const child=(b,x,n)=>{const y=entries(b,x.body,x.end).find(x=>x.type===n);if(!y)throw Error(`missing box ${n}`);return y;};
const crc8=(b,start,end)=>{let crc=0;for(let i=start;i<end;i++){crc^=b[i];for(let bit=0;bit<8;bit++)crc=crc&0x80?((crc<<1)^7)&255:(crc<<1)&255;}return crc;};
const sizes={1:192,2:576,3:1152,4:2304,5:4608,8:256,9:512,10:1024,11:2048,12:4096,13:8192,14:16384,15:32768};
function decodeUTF8(b,p){let c=b[p];if(c<128)return {num:c,p:p+1};let count=0,mask=128;while(c&mask){count++;mask>>=1;}
 if(count<2||count>7||p+count>b.length)return null;
 let n=c&(127>>count);for(let j=1;j<count;j++){let x=b[p+j];if((x&192)!==128)return null;n=n*64+(x&63);}
 return {num:n,p:p+count};
}
export function decodeFrameHeader(b,p,info){
 if(p+8>=b.length||b[p]!==255||(b[p+1]&0xfe)!==0xf8||b[p+3]&1)return null;
 const variable=b[p+1]&1,sc=b[p+2]>>4,rate=b[p+2]&15,channel=b[p+3]>>4,bps=(b[p+3]>>1)&7;
 if(!sc||rate===15||channel>10||bps===3||bps===7)return null;
 if(channel<=7&&channel+1!==info.channels)return null;
 if(channel>=8&&info.channels!==2)return null;
 let off=p+4;const counter=decodeUTF8(b,off);if(!counter||!Number.isSafeInteger(counter.num))return null;off=counter.p;
 let block=sizes[sc];if(sc===6){if(off>=b.length)return null;block=b[off++]+1;}else if(sc===7){if(off+1>=b.length)return null;block=u16(b,off)+1;off+=2;}
 if(!block||block>65536)return null;
 if(rate===12)off++;else if(rate===13||rate===14)off+=2;
 if(off>=b.length||crc8(b,p,off)!==b[off])return null;
 const index=variable?counter.num:counter.num*(info.minBlock===info.maxBlock?info.minBlock:block);
 if(!Number.isSafeInteger(index))return null;
 return {offset:p,number:index,block,headerBytes:off+1-p};
}
export function flacHeader(bytes){
 if(String.fromCharCode(...bytes.subarray(0,4))!=='fLaC')throw Error('不是原生 FLAC 檔案');
 let pos=4,info=null,seek=[];
 while(pos+4<=bytes.length){const raw=bytes[pos],size=u24(bytes,pos+1),start=pos+4,end=start+size;
  if(end>bytes.length)throw Error('FLAC metadata 未完整');
  if((raw&127)===0){if(size<34)throw Error('FLAC STREAMINFO 無效');const v=bytes.subarray(start,start+34);
   const sampleRate=(v[10]<<12)|(v[11]<<4)|(v[12]>>4),channels=((v[12]>>1)&7)+1,bits=(((v[12]&1)<<4)|(v[13]>>4))+1;
   const total=((v[13]&15)*4294967296)+u32(v,14);info={sampleRate,channels,bits,total,minBlock:u16(v,0),maxBlock:u16(v,2),streamInfo:v.slice()};
  }else if((raw&127)===3){for(let i=start;i+18<=end;i+=18){const sample=u32(bytes,i)*4294967296+u32(bytes,i+4),offset=u32(bytes,i+8)*4294967296+u32(bytes,i+12);if(sample!==0xffffffffffffffff&&Number.isSafeInteger(sample)&&Number.isSafeInteger(offset))seek.push({sample,offset});}}
  pos=end;if(raw&128){if(!info||info.sampleRate<8000||info.sampleRate>384000||info.channels>8||info.total<1)throw Error('FLAC STREAMINFO 不受支援');return {...info,dataOffset:pos,seek};}
 }
 throw Error('FLAC 中繼資料不完整');
}
export async function loadFlacHeader(source,signal){
 const {total}=await source.ready();const sig=await source.readRange(0,Math.min(total,4),signal);
 if(String.fromCharCode(...sig)!=='fLaC')throw Error('檔案不是 FLAC');
 let p=4,streamInfo=null,seek=[],ended=false;
 for(let i=0;i<256;i++){
  if(signal?.aborted)throw new DOMException('FLAC 讀取取消','AbortError');
  const h=await source.readRange(p,Math.min(total,p+4),signal);
  if(h.length!==4)throw Error('FLAC 區塊頭截斷');
  const len=u24(h,1),type=h[0]&127;
  if(p+4+len>total)throw Error('FLAC 中繼資料超出檔案');
  if(type===0){
   if(len!==34)throw Error('FLAC STREAMINFO 不合法');
   streamInfo=await source.readRange(p+4,p+4+34,signal);
  }else if(type===3){
   if(len>8*1024*1024)throw Error('FLAC SEEKTable 過大');
   const rows=await source.readRange(p+4,p+4+len,signal);
   for(let at=0;at+18<=rows.length;at+=18){
    const hi=u32(rows,at),lo=u32(rows,at+4),s=hi*4294967296+lo;
    const offset=u32(rows,at+8)*4294967296+u32(rows,at+12);
    if(hi!==0xffffffff&&Number.isSafeInteger(s)&&Number.isSafeInteger(offset))seek.push({sample:s,offset});
   }
  }
  p+=4+len;if(h[0]&128){ended=true;break;}
 }
 if(!ended||!streamInfo)throw Error('FLAC 缺少完整的 STREAMINFO／末尾標記');
 const info=flacHeader(cat(te.encode('fLaC'),Uint8Array.of(0x80,0,0,34),streamInfo));
 // Album art and tags were deliberately skipped without downloading them.
 return {...info,seek,totalSamples:info.total,dataOffset:p,total};
}

function frameStarts(b,info,min=0){const list=[];for(let i=min;i+8<b.length;i++){
 if(b[i]!==255|| (b[i+1]&254)!==248)continue;const h=decodeFrameHeader(b,i,info);if(h){list.push(h);i+=h.headerBytes-1;}
 }return list;
}
export async function flacBatch(source,info,offset,signal){
 let size=512*1024,bytes,headers;
 for(let j=0;j<5;j++){
   const end=Math.min(info.total,offset+size);bytes=await source.readRange(offset,end,signal);
   headers=frameStarts(bytes,info);
   if(headers.length>=2||end===info.total)break;
   size*=2;
 }
 if(!headers.length)throw Error('FLAC 未找到有效音框');
 const samples=[];
 for(let i=0;i<headers.length;i++){
  const a=headers[i],b=headers[i+1];if(!b&&offset+bytes.length<info.total)break;
  const end=b?b.offset:bytes.length;
  if(end<=a.offset)continue;
  samples.push({number:a.number,block:a.block,offset:offset+a.offset,size:end-a.offset});
 }
 if(!samples.length)throw Error('FLAC 音框跨越讀取區塊');
 const last=samples.at(-1),next=last.offset+last.size;
 return {samples,bytes,startOffset:offset,nextOffset:next};
}
function template(){
 // Generated by FFmpeg 7.1 from a test FLAC; placeholder is replaced by source STREAMINFO.
 const base64='AAAAIGZ0eXBpc29tAAACAGlzb21pc282aXNvMm1wNDEAAAKkbW9vdgAAAGxtdmhkAAAAAAAAAAAAAAAAAAAD6AAAAAAAAQAAAQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAad0cmFrAAAAXHRraGQAAAADAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAEBAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAFDbWRpYQAAACBtZGhkAAAAAAAAAAAAAAAAAACsRAAAAABVxAAAAAAALWhkbHIAAAAAAAAAAHNvdW4AAAAAAAAAAAAAAABTb3VuZEhhbmRsZXIAAAAA7m1pbmYAAAAQc21oZAAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAAAsnN0YmwAAABmc3RzZAAAAAAAAAABAAAAVmZMYUMAAAAAAAAAAQAAAAAAAAAAAAEAEAAAAACsRAAAAAAAMmRmTGEAAAAAgAAAIhIAEgAABCUABPUKxEDwAANdVOkbuUcDPxfRj8LTaMoTDm4AAAAQc3R0cwAAAAAAAAAAAAAAEHN0c2MAAAAAAAAAAAAAABRzdHN6AAAAAAAAAAAAAAAAAAAAEHN0Y28AAAAAAAAAAAAAAChtdmV4AAAAIHRyZXgAAAAAAAAAAQAAAAEAAAAAAAAAAAAAAAAAAABhdWR0YQAAAFltZXRhAAAAAAAAACFoZGxyAAAAAAAAAABtZGlyYXBwbAAAAAAAAAAAAAAAACxpbHN0AAAAJKl0b28AAAAcZGF0YQAAAAEAAAAATGF2ZjYxLjcuMTAz';
 const bin=Uint8Array.from(atob(base64), c=>c.charCodeAt(0));return bin;
}
export function flacInit(info){
 const b=template(),root=entries(b),moov=root.find(x=>x.type==='moov'),mvhd=child(b,moov,'mvhd'),trak=child(b,moov,'trak'),tkhd=child(b,trak,'tkhd'),mdia=child(b,trak,'mdia'),mdhd=child(b,mdia,'mdhd'),minf=child(b,mdia,'minf'),stbl=child(b,minf,'stbl'),stsd=child(b,stbl,'stsd'),entry=entries(b,stsd.body+8,stsd.end)[0],dfLa=entries(b,entry.start+36,entry.end).find(x=>x.type==='dfLa');if(!dfLa)throw Error('FLAC MP4 template 缺少 dfLa');
 set32(b,mvhd.body+12,1000);set32(b,mvhd.body+16,Math.min(0xffffffff,Math.floor((info.totalSamples??info.total)/info.sampleRate*1000)));
 set32(b,tkhd.body+20,Math.min(0xffffffff,Math.floor((info.totalSamples??info.total)/info.sampleRate*1000)));
 set32(b,mdhd.body+12,info.sampleRate);set32(b,mdhd.body+16,Math.min(0xffffffff,info.totalSamples??info.total));
 b[entry.start+24]=info.channels>>>8;b[entry.start+25]=info.channels&255;
 b[entry.start+26]=info.bits>>>8;b[entry.start+27]=info.bits&255;
 set32(b,entry.start+32,(Math.min(info.sampleRate,65535)*65536)>>>0);
 b.set(info.streamInfo,dfLa.body+8);
 return b;
}
export function flacFragment(samples,bytes,baseOffset,sequence=1){
 if(!samples.length)throw Error('沒有音框');
 const payload=samples.map(s=>bytes.subarray(s.offset-baseOffset,s.offset-baseOffset+s.size));
 let trun=full('trun',0x301,n32(samples.length),n32(0),...samples.flatMap(s=>[n32(s.block),n32(s.size)]));
 const tfhd=full('tfhd',0x020000,n32(1)),tfdt=full('tfdt',0x01000000,n64(samples[0].number));
 let moof=box('moof',full('mfhd',0,n32(sequence)),box('traf',tfhd,tfdt,trun));
 const traf=child(moof,entries(moof)[0],'traf'),tr=child(moof,traf,'trun');
 set32(moof,tr.body+8,moof.length+8);
 return cat(moof,box('mdat',...payload));
}

const abortError=()=>new DOMException('FLAC 預覽已關閉','AbortError');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function parseFirstFrameAt(source,info,offset,signal){
 const end=Math.min(info.total,offset+256*1024);
 const bytes=await source.readRange(offset,end,signal);
 const starts=frameStarts(bytes,info);return starts.length?{...starts[0],offset:offset+starts[0].offset}:null;
}
/** Locate a seekable FLAC frame without building a full-file index.
 * Respect the FLAC SEEKTABLE if present; otherwise use sparse probes and
 * CRC8-validated frame headers. Approximate seeking can land a frame before
 * the desired time, never farther than the 1st supported sync frame.
 */
export async function locateFlacFrame(source,info,seconds,signal){
 const target=Math.max(0,Math.min(info.totalSamples, Math.floor(seconds*info.sampleRate)));
 if(target<info.sampleRate)return {offset:info.dataOffset,number:0};
 let low=info.dataOffset,high=info.total-1;
 let best={offset:low,number:0};
 for(const s of info.seek||[]){if(s.sample<=target&&s.sample>=best.number){best={offset:info.dataOffset+s.offset,number:s.sample};low=best.offset;}}
 let desired=info.dataOffset+(info.total-info.dataOffset)*(target/info.totalSamples);
 for(let i=0;i<16;i++){
  if(signal?.aborted)throw abortError();
  const probe=Math.max(low,Math.min(high-1024, Math.floor(i===0?desired:(low+high)/2)));
  if(!Number.isFinite(probe)||probe<=low+256||probe>=high)break;
  const frame=await parseFirstFrameAt(source,info,probe,signal);
  if(!frame){high=probe;continue;}
  if(frame.number>target){high=probe;continue;}
  if(frame.number>=best.number){best={offset:frame.offset,number:frame.number};low=frame.offset;}
  if(target-frame.number < info.sampleRate*1.2)break;
 }
 return best;
}

/** FLAC-in-MP4 remux for browser MSE, preserving lossless samples. */
export class ProgressiveFlacPlayer {
 constructor(audio,source,{signal,onStatus}={}){
  this.audio=audio;this.source=source;this.parentSignal=signal;this.lifetime=new AbortController();this.signal=this.lifetime.signal;this.onStatus=onStatus||(()=>{});
  this.closed=false;this.url=null;this.ms=null;this.sb=null;this.seq=0;
  this.onParentAbort=()=>this.destroy();this.parentSignal?.addEventListener('abort',this.onParentAbort,{once:true});if(this.parentSignal?.aborted)this.destroy();
 }
 get active(){return !this.closed&&!this.signal?.aborted;}
 async start(){
  if(!globalThis.MediaSource?.isTypeSupported?.('audio/mp4; codecs="flac"'))throw Error('Chrome 不支援 MSE FLAC-in-MP4');
  this.info=await loadFlacHeader(this.source,this.signal);
  if(!this.active)throw abortError();
  const seconds=this.info.totalSamples/this.info.sampleRate;
  const bytesPerSecond=Math.max(1,(this.info.total-this.info.dataOffset)/seconds);
  // Audio SourceBuffer quotas are much smaller than a full RAM file cache.
  this.aheadLimit=Math.max(0.5,Math.min(30,4*1024*1024/bytesPerSecond));
  this.keepBehind=Math.max(0.5,Math.min(10,2*1024*1024/bytesPerSecond));
  // ftyp/moov is generated from source STREAMINFO (same uncompressed PCM data).
  this.ms=new MediaSource();this.url=URL.createObjectURL(this.ms);this.audio.src=this.url;
  await new Promise((resolve,reject)=>{
   const ok=()=>{clean();resolve();},bad=()=>{clean();reject(abortError());};
   const clean=()=>{this.ms.removeEventListener('sourceopen',ok);this.signal?.removeEventListener('abort',bad);};
   this.ms.addEventListener('sourceopen',ok,{once:true});this.signal?.addEventListener('abort',bad,{once:true});
  });
  if(!this.active)throw abortError();
  this.sb=this.ms.addSourceBuffer('audio/mp4; codecs="flac"');
  await this.append(flacInit(this.info));
  // Total samples are stored in STREAMINFO and provide exact duration.
  this.ms.duration=this.info.totalSamples/this.info.sampleRate;
  this.audio.addEventListener('seeking',this.onSeek=()=>{
   if(!this.active)return;
   const time=this.audio.currentTime,ranges=this.audio.buffered;
   for(let i=0;i<ranges.length;i++)if(time>=ranges.start(i)&&time+0.2<ranges.end(i))return;
   this.beginAt(time);
  });
  this.beginAt(0);
 }
 async append(data){
  if(!this.active)throw abortError();const sb=this.sb;
  await new Promise((resolve,reject)=>{
   const done=()=>{clean();resolve();},bad=()=>{clean();reject(Error('FLAC MP4 MSE 追加失敗'));},abort=()=>{clean();reject(abortError());};
   const clean=()=>{sb.removeEventListener('updateend',done);sb.removeEventListener('error',bad);this.signal?.removeEventListener('abort',abort);};
   sb.addEventListener('updateend',done,{once:true});sb.addEventListener('error',bad,{once:true});this.signal?.addEventListener('abort',abort,{once:true});
   try{sb.appendBuffer(data);}catch(e){clean();reject(e);}
  });
 }
 async clear(){
  if(!this.sb?.buffered.length)return;
  const end=this.sb.buffered.end(this.sb.buffered.length-1);if(end<=0)return;
  await new Promise((resolve,reject)=>{
   const ok=()=>{clean();resolve();},bad=()=>{clean();reject(abortError());};
   const clean=()=>{this.sb.removeEventListener('updateend',ok);this.signal?.removeEventListener('abort',bad);};
   this.sb.addEventListener('updateend',ok,{once:true});this.signal?.addEventListener('abort',bad,{once:true});
   try{this.sb.remove(0,end);}catch(e){clean();reject(e);}
  });
 }
 async removeOld(){
  const before=this.audio.currentTime-this.keepBehind,sb=this.sb;
  if(!this.active||sb.updating||before<=0||!sb.buffered.length||sb.buffered.start(0)>=before)return;
  await new Promise((resolve,reject)=>{
   const ok=()=>{clean();resolve();},bad=()=>{clean();reject(abortError());};
   const clean=()=>{sb.removeEventListener('updateend',ok);sb.removeEventListener('error',bad);this.signal?.removeEventListener('abort',bad);};
   sb.addEventListener('updateend',ok,{once:true});sb.addEventListener('error',bad,{once:true});this.signal?.addEventListener('abort',bad,{once:true});
   try{sb.remove(0,before);}catch(e){clean();reject(e);}
  });
 }
 beginAt(time){
  const id=++this.seq;this.pendingAbort?.abort();const ac=new AbortController();this.pendingAbort=ac;
  this.task=(this.task||Promise.resolve()).catch(()=>{}).then(async()=>{
   if(!this.active||ac.signal.aborted)return;
   await this.feedFrom(time,id,ac.signal);
  }).catch(e=>{if(this.active&&id===this.seq&&e?.name!=='AbortError'){
   this.onStatus(`FLAC 串流中斷：${e.message}`);console.warn('[NotionDrive FLAC]',e);
  }});
 }
 async feedFrom(time,id,signal){
  if(time>0.2){while(this.sb.updating){if(!this.active||signal.aborted)return;await wait(20);}await this.clear();}
  const where=await locateFlacFrame(this.source,this.info,time,signal);
  let offset=where.offset,n=0;
  while(this.active&&!signal.aborted&&id===this.seq&&offset<this.info.total){
   const ranges=this.audio.buffered;
   const ahead=ranges.length?ranges.end(ranges.length-1)-this.audio.currentTime:0;
   if(ahead>this.aheadLimit){await wait(180);continue;}
   const batch=await flacBatch(this.source,this.info,offset,signal);
   // Drop frames already decoded in a discontinuity; the first frame remains a valid MSE random access sample.
   const chunk=flacFragment(batch.samples,batch.bytes,batch.startOffset,++n);
   if(signal.aborted||!this.active)return;
   await this.append(chunk);
   await this.removeOld();
   offset=batch.nextOffset;
   this.onStatus(`FLAC 無損串流中 · ${Math.round(100*offset/this.info.total)}% 檔案讀取位置（無需先下載整首）`);
  }
  if(this.active&&!signal.aborted&&id===this.seq&&offset>=this.info.total&&this.ms.readyState==='open'&&!this.sb.updating){
   this.ms.endOfStream();
  }
 }
 destroy(){if(this.closed)return;this.closed=true;
    this.parentSignal?.removeEventListener('abort',this.onParentAbort);this.lifetime.abort();this.seq++;this.pendingAbort?.abort();
  if(this.onSeek)this.audio.removeEventListener('seeking',this.onSeek);
  try{this.audio.pause();}catch{}
  try{if(this.sb&&!this.sb.updating)this.sb.abort();}catch{}
  try{this.audio.removeAttribute('src');this.audio.load();}catch{}
  if(this.url)URL.revokeObjectURL(this.url);
  this.source?.close();
 }
}
