/**
 * Progressive ISO BMFF (ordinary MP4) to fragmented MP4 for NDRVENC1 Range sources.
 * Supports AVC/H.264, HEVC and audio-only AAC tracks, inside the
 * authenticated NDRVENC1 envelope. Does NOT re-encode or rewrite Vault data.
 * It parses moov metadata, builds MSE init segment, and creates short muxed
 * fragments from sparse byte ranges. Unsupported layouts reject cleanly.
 * Pure helpers are exported for offline MP4 fixture tests.
 */
const te = new TextEncoder();
const bytes4 = s => te.encode(s);
const be32 = (b,p) => (b[p]*0x1000000+b[p+1]*65536+b[p+2]*256+b[p+3])>>>0;
const be16 = (b,p) => b[p]*256+b[p+1];
const be64 = (b,p) => {const x=be32(b,p)*0x100000000+be32(b,p+4);if(!Number.isSafeInteger(x))throw Error('超過安全位元組範圍');return x;};
const enc32=n=>Uint8Array.from([(n>>>24)&255,(n>>>16)&255,(n>>>8)&255,n&255]);
const enc64=n=>new Uint8Array([...enc32(Math.floor(n/0x100000000)),...enc32(n>>>0)]);
function concat(parts){let n=0;for(const p of parts)n+=p.length;const o=new Uint8Array(n);let i=0;for(const p of parts){o.set(p,i);i+=p.length;}return o;}
function atom(type, ...parts){const content=concat(parts);return concat([enc32(content.length+8),bytes4(type),content]);}
function full(type,flags,...parts){return atom(type,Uint8Array.from([(flags>>>24)&255,(flags>>>16)&255,(flags>>>8)&255,flags&255]),...parts);}
const raw=(b,x)=>b.subarray(x.from,x.to);
export function atoms(b,begin=0,end=b.length){const result=[];for(let p=begin;p+8<=end;){let size=be32(b,p),head=8;const type=String.fromCharCode(...b.subarray(p+4,p+8));if(size===1){if(p+16>end)throw Error('MP4 extended box 標頭不完整');size=be64(b,p+8);head=16;}else if(size===0)size=end-p;if(size<head||p+size>end)throw Error(`MP4 box 範圍不合法：${type}`);result.push({type,from:p,to:p+size,payload:p+head,header:head});p+=size;}return result;}
const find=(list,type)=>list.find(b=>b.type===type);
function children(b,x){return atoms(b,x.payload,x.to);}
function requireBox(arr,type){const x=find(arr,type);if(!x)throw Error(`MP4 缺少 ${type}`);return x;}
function table(b,x,unit){const pos=x.payload+8,n=be32(b,x.payload+4);if(n>2e7||pos+n*unit>x.to)throw Error('MP4 sample table 無效');return {n,pos};}
function times(b,x){const {n,pos}=table(b,x,8);const out=[];for(let i=0;i<n;i++)out.push([be32(b,pos+i*8),be32(b,pos+i*8+4)]);return out;}
function signed32(n){return n>0x7fffffff?n-0x100000000:n;}
/** RFC 6381 HEVC codec string derived from the hvcC decoder record.
 * The sample data is not transcoded: actual decoding is decided by Chrome MSE.
 */
export function hevcCodecFromConfig(b, sampleKind, entryAt, entrySize){
  if(!['hvc1','hev1'].includes(sampleKind))throw Error('不是 HEVC sample entry');
  const boxes=atoms(b,entryAt+86,entryAt+entrySize),hvcc=requireBox(boxes,'hvcC');
  if(hvcc.to-hvcc.payload<13||b[hvcc.payload]!==1)throw Error('HEVC hvcC 設定不完整');
  const pos=hvcc.payload;
  const first=b[pos+1],space=(first>>>6)&3, tier=(first>>>5)&1,profile=first&31;
  const flags=be32(b,pos+2);
  let reversed=0;for(let i=0;i<32;i++)reversed=(reversed*2+((flags>>>i)&1))>>>0;
  const level=b[pos+12],parts=[];
  const prefix=['','A','B','C'][space];
  const suffix=b.subarray(pos+6,pos+12);
  let last=suffix.length;while(last>0&&suffix[last-1]===0)last--;
  for(let i=0;i<last;i++)parts.push(suffix[i].toString(16).toUpperCase().padStart(2,'0'));
  return `${sampleKind}.${prefix}${profile}.${reversed.toString(16).toUpperCase()}.${tier?'H':'L'}${level}${parts.length?'.'+parts.join('.'):''}`;
}
function sampleMeta(b,trak){
  const tlist=children(b,trak),tkhd=requireBox(tlist,'tkhd'),tid=be32(b,tkhd.payload+(b[tkhd.payload]===1?20:12));
  const mdia=requireBox(tlist,'mdia'),mlist=children(b,mdia),mdhd=requireBox(mlist,'mdhd'),timescale=be32(b,mdhd.payload+(b[mdhd.payload]===1?20:12));
  const hdlr=requireBox(mlist,'hdlr');const kind=String.fromCharCode(...b.subarray(hdlr.payload+8,hdlr.payload+12));
  if(!timescale||!['vide','soun'].includes(kind))return null;
  const minf=requireBox(mlist,'minf'),stbl=requireBox(children(b,minf),'stbl'),box=children(b,stbl);
  const stsd=requireBox(box,'stsd'),entryCount=be32(b,stsd.payload+4);if(entryCount!==1)throw Error('MP4 多個編碼配置尚未支援');
  const entryAt=stsd.payload+8,entrySize=be32(b,entryAt),codec=String.fromCharCode(...b.subarray(entryAt+4,entryAt+8));
  if(entrySize<12||entryAt+entrySize>stsd.to)throw Error('MP4 stsd 無效');
  let codecString;
  if(kind==='vide'){
    if(['hvc1','hev1'].includes(codec)){
      codecString=hevcCodecFromConfig(b,codec,entryAt,entrySize);
    }else if(['avc1','avc3'].includes(codec)){
      const avcStart=entryAt+86, boxes=atoms(b,avcStart,entryAt+entrySize),avc=requireBox(boxes,'avcC');
      const h=n=>n.toString(16).padStart(2,'0');codecString=`${codec}.${h(b[avc.payload+1])}${h(b[avc.payload+2])}${h(b[avc.payload+3])}`;
    }else throw Error(`MP4 視訊編碼 ${codec} 尚未支援（目前串流支援 H.264／HEVC）`);
  } else {
    if(codec!=='mp4a')throw Error(`MP4 音訊編碼 ${codec} 尚未支援`);
    codecString='mp4a.40.2';
  }
  const stsz=requireBox(box,'stsz');const def=be32(b,stsz.payload+4),count=be32(b,stsz.payload+8);
  if(count>2000000)throw Error('MP4 樣本數超過此版安全上限');
  if(!def&&stsz.payload+12+4*count>stsz.to)throw Error('MP4 stsz 截斷');
  const sizes=new Uint32Array(count);for(let i=0;i<count;i++)sizes[i]=def||be32(b,stsz.payload+12+4*i);
  const offsetBox=find(box,'stco')||find(box,'co64');if(!offsetBox)throw Error('MP4 stco/co64 缺失');
  const is64=offsetBox.type==='co64',ct=be32(b,offsetBox.payload+4);if(ct>count+1||offsetBox.payload+8+ct*(is64?8:4)>offsetBox.to)throw Error('MP4 stco 不合法');
  const chunks=[];for(let i=0;i<ct;i++)chunks.push(is64?be64(b,offsetBox.payload+8+i*8):be32(b,offsetBox.payload+8+i*4));
  const stsc=requireBox(box,'stsc'),sc=be32(b,stsc.payload+4),groups=[];
  if(sc>ct||stsc.payload+8+sc*12>stsc.to)throw Error('MP4 stsc 無效');
  for(let i=0;i<sc;i++)groups.push({first:be32(b,stsc.payload+8+12*i),n:be32(b,stsc.payload+12+12*i),desc:be32(b,stsc.payload+16+12*i)});
  const spans=times(b,requireBox(box,'stts'));let si=0,dts=0,g=0;const samples=new Array(count);
  for(let ch=0;ch<chunks.length;ch++){
    while(g+1<groups.length && ch+1>=groups[g+1].first)g++;
    const grp=groups[g];if(!grp||grp.desc!==1||grp.first>ch+1)throw Error('MP4 樣本配置不支援');
    let o=chunks[ch];for(let j=0;j<grp.n;j++){
      if(si>=count)throw Error('MP4 sample count 不符');
      samples[si]={offset:o,size:sizes[si],dts:0,duration:0,cto:0,sync:true};o+=sizes[si];si++;
    }
  }
  if(si!==count)throw Error('MP4 樣本數與 stsc 不符');
  let index=0;for(const [n,dt] of spans){for(let j=0;j<n;j++){if(index>=count)throw Error('MP4 stts 溢位');samples[index].dts=dts;samples[index].duration=dt;dts+=dt;index++;}}
  if(index!==count)throw Error('MP4 stts 樣本不完整');
  const ctts=find(box,'ctts');if(ctts){const {n,pos}=table(b,ctts,8);let a=0;for(let i=0;i<n;i++){const num=be32(b,pos+8*i),v=be32(b,pos+8*i+4),value=b[ctts.payload]===1?signed32(v):v;for(let j=0;j<num;j++){if(a>=count)throw Error('MP4 ctts 溢位');samples[a++].cto=value;}}if(a!==count)throw Error('MP4 ctts 不完整');}
  const stss=find(box,'stss');if(kind==='vide'&&stss){samples.forEach(s=>s.sync=false);const {n,pos}=table(b,stss,4);for(let i=0;i<n;i++){const idx=be32(b,pos+i*4)-1;if(idx<0||idx>=count)throw Error('MP4 stss 錯誤');samples[idx].sync=true;}}
  if(samples.some(s=>!Number.isSafeInteger(s.offset)||!s.size))throw Error('MP4 樣本偏移無效');
  return {id:tid,kind,timescale,codec:codecString,samples};
}
function initMovie(b,moov,tracks){
  const parentTypes=new Set(['moov','trak','mdia','minf','stbl']);
  const clearTypes=new Set(['stts','ctts','stsc','stss','stco','co64','stsz','stz2','sdtp']);
  function rebox(x){
    if(clearTypes.has(x.type)){
      if(x.type==='stsz')return full('stsz',0,enc32(0),enc32(0));
      if(x.type==='stz2')return full('stz2',0,enc32(0),enc32(0));
      return full(x.type,0,enc32(0));
    }
    if(!parentTypes.has(x.type))return raw(b,x);
    const subs=children(b,x).filter(y=>x.type!=='moov'||y.type!=='mvex').map(rebox);
    if(x.type==='moov')subs.push(atom('mvex',...tracks.map(t=>full('trex',0,enc32(t.id),enc32(1),enc32(0),enc32(0),enc32(0)))));
    return atom(x.type,...subs);
  }
  return rebox(moov);
}
export function parseOrdinaryMp4(moovBytes,ftypBytes){
  const moov=find(atoms(moovBytes),'moov');if(!moov)throw Error('沒有 moov box');
  const tracks=children(moovBytes,moov).filter(x=>x.type==='trak').map(x=>sampleMeta(moovBytes,x)).filter(Boolean);
  if(!tracks.length||tracks.length>2)throw Error('MP4 影音軌數不支援');
  const videoTracks=tracks.filter(x=>x.kind==='vide'),audioTracks=tracks.filter(x=>x.kind==='soun');
  if(videoTracks.length>1||audioTracks.length>1||(!videoTracks.length&&!audioTracks.length))throw Error('MP4 影音軌配置不支援');
  const audioOnly=!videoTracks.length;
  const mime=`${audioOnly?'audio':'video'}/mp4; codecs="${tracks.map(x=>x.codec).join(', ')}"`;
  const init=concat([ftypBytes,initMovie(moovBytes,moov,tracks)]);
  // Audio-only M4A is also an ISO BMFF track: all audio samples are random-access.
  // Pick roughly two-second AAC anchors to avoid a huge keyframe index.
  const video=videoTracks[0]||audioTracks[0];
  const keys=video.samples.map((s,i)=>
    audioOnly ? (i===0 || (i>0&&Math.floor(s.dts/video.timescale/2)>Math.floor(video.samples[i-1].dts/video.timescale/2))?i:-1)
      : (s.sync?i:-1)).filter(i=>i>=0);
  if(!keys.length)throw Error('MP4 未包含可用起點');
  return {tracks,video,keys,init,mime,audioOnly};
}
function seekIndex(p,time){const {video,keys}=p;let result=keys[0];for(const n of keys){if(video.samples[n].dts/video.timescale>time+0.05)break;result=n;}return result;}
function choose(p,startIndex){
  const v=p.video,keys=p.keys;let ki=keys.findIndex(i=>i===startIndex);if(ki<0)throw Error('非同步影格起點');
  let next=keys[Math.min(keys.length-1,ki+1)];
  // Prefer ~2 sec; one GOP per fragment, limit video frames to avoid large buffers.
  while(ki+1<keys.length-1 && (v.samples[next].dts-v.samples[startIndex].dts)/v.timescale<1.8 && next-startIndex<240){ki++;next=keys[ki+1];}
  const last=ki+1<keys.length?next:v.samples.length;
  const start=v.samples[startIndex].dts/v.timescale;
  const end=last<v.samples.length?v.samples[last].dts/v.timescale:(v.samples.at(-1).dts+v.samples.at(-1).duration)/v.timescale;
  const selection=[];
  for(const t of p.tracks){const samples=t===p.video?t.samples.slice(startIndex,last):t.samples.filter(s=>s.dts/t.timescale>=start-0.025 && s.dts/t.timescale<end-0.005);if(samples.length)selection.push({track:t,samples});}
  return {selection,next:last,timeStart:start,timeEnd:end};
}
function trafSegment(t,samples){
  const dts=samples[0].dts;
  const version=samples.some(s=>s.cto<0)?1:0;
  const table=[];
  for(const s of samples){
    table.push(enc32(s.duration),enc32(s.size),enc32(s.sync?0x02000000:0x01010000),enc32(s.cto));
  }
  const run=full('trun',(version<<24)|0x000f01,enc32(samples.length),enc32(0),...table);
  return atom('traf',full('tfhd',0x020000,enc32(t.id)),full('tfdt',0x01000000,enc64(dts)),run);
}
function setOffset(moof,trackNo,offset){const trafs=children(moof,atoms(moof)[0]).filter(x=>x.type==='traf');const trun=requireBox(children(moof,trafs[trackNo]),'trun');moof.set(enc32(offset),trun.payload+8);}
export async function fragment(p,selection,source,signal,sequence){
  const tracks=selection.filter(x=>x.samples.length);
  const all=tracks.flatMap(t=>t.samples);
  const from=Math.min(...all.map(s=>s.offset)),to=Math.max(...all.map(s=>s.offset+s.size));
  // Tracks are typically interleaved. Avoid any unbounded read amplification.
  // A short GOP may be larger than 24 MiB in high bitrate captures; reject cleanly.
  if(!Number.isSafeInteger(to)||to-from>24*1024*1024)throw Error('MP4 單段資料範圍過大，無法安全串流');
  const sourceBytes=await source.readRange(from,to,signal);
  const payload=[];for(const {samples} of tracks){for(const s of samples)payload.push(sourceBytes.subarray(s.offset-from,s.offset-from+s.size));}
  const moof=atom('moof',full('mfhd',0,enc32(sequence)),...tracks.map(x=>trafSegment(x.track,x.samples)));
  let dataOffset=moof.length+8;
  tracks.forEach((x,i)=>{setOffset(moof,i,dataOffset);dataOffset+=x.samples.reduce((a,s)=>a+s.size,0);});
  return concat([moof,atom('mdat',...payload)]);
}
export async function openProgressiveMp4(source,signal){
  const {total}=await source.ready();let offset=0,ftyp=null,moov=null;
  // Each root header takes a small Range. Jump past mdat rather than fetching it.
  for(let i=0;i<80 && offset<total;i++){
    const h=await source.readRange(offset,Math.min(offset+16,total),signal);if(h.length<8)break;
    let length=be32(h,0);const type=String.fromCharCode(...h.subarray(4,8));
    if(length===1)length=be64(h,8);else if(length===0)length=total-offset;
    if(length<8||offset+length>total)throw Error('MP4 box 大小錯誤');
    if(type==='ftyp'||type==='moov'){
      if(length>16*1024*1024)throw Error('MP4 索引過大');
      const fullBytes=await source.readRange(offset,offset+length,signal);
      if(type==='ftyp')ftyp=fullBytes;else moov=fullBytes;
    }
    offset+=length;if(moov&&ftyp)break;
  }
  if(!ftyp||!moov)throw Error('未取得 MP4 ftyp／moov 索引');
  return parseOrdinaryMp4(moov,ftyp);
}
const cancelled=()=>new DOMException('影片讀取取消','AbortError');
export class ProgressiveMp4Player{
  constructor(video,source,{signal,onStatus}={}){this.video=video;this.source=source;this.parentSignal=signal;this.lifetime=new AbortController();this.signal=this.lifetime.signal;this.onStatus=onStatus||(()=>{});this.closed=false;this.fetchAbort=null;this.url=null;this.buffer=null;this.media=null;this.seq=0;this.onParentAbort=()=>this.destroy();this.parentSignal?.addEventListener('abort',this.onParentAbort,{once:true});if(this.parentSignal?.aborted)this.destroy();}
  get active(){return !this.closed&&!this.signal?.aborted;}
  async start(){
    this.p=await openProgressiveMp4(this.source,this.signal);
    if(!this.active)throw cancelled();
    if(!MediaSource.isTypeSupported(this.p.mime))throw Error(`此 Chrome／硬體不支援此 MP4 的 MSE 編碼：${this.p.mime}；會安全回退原版完整解密`);
    this.media=new MediaSource();this.url=URL.createObjectURL(this.media);this.video.src=this.url;
    await new Promise((resolve,reject)=>{const ok=()=>{cleanup();resolve();},bad=()=>{cleanup();reject(cancelled());};const cleanup=()=>{this.media.removeEventListener('sourceopen',ok);this.signal?.removeEventListener('abort',bad);};this.media.addEventListener('sourceopen',ok,{once:true});this.signal?.addEventListener('abort',bad,{once:true});});
    if(!this.active)throw cancelled();
    this.buffer=this.media.addSourceBuffer(this.p.mime);
    this.video.addEventListener('error',this.onVideoError=()=>{
      if(this.active)this.onStatus(`MP4 解碼失敗：${this.video.error?.message||'編碼或影片片段不相容'}`);
    });
    await this.append(this.p.init);
    this.video.addEventListener('seeking',this.onSeek=()=>{
      if(!this.active)return;
      const time=this.video.currentTime,ranges=this.video.buffered;
      // A native seek inside buffered content must not cancel the active feed.
      for(let i=0;i<ranges.length;i++)if(time>=ranges.start(i)&&time+0.3<ranges.end(i))return;
      this.beginAt(time);
    });
    const last=this.p.video.samples.at(-1);
    this.media.duration=(last.dts+last.duration)/this.p.video.timescale;
    this.beginAt(0);
  }
  async append(data){if(!this.active)throw cancelled();const sb=this.buffer;
    await new Promise((resolve,reject)=>{const done=()=>{clean();resolve();},err=()=>{clean();reject(Error('MP4 MSE SourceBuffer 更新失敗'));},abort=()=>{clean();reject(cancelled());};
      const clean=()=>{sb.removeEventListener('updateend',done);sb.removeEventListener('error',err);this.signal?.removeEventListener('abort',abort);};
      sb.addEventListener('updateend',done,{once:true});sb.addEventListener('error',err,{once:true});this.signal?.addEventListener('abort',abort,{once:true});try{sb.appendBuffer(data);}catch(e){clean();reject(e);}
    });
  }
  async removeRange(start,end){const sb=this.buffer;
    if(end<=start)return;
    await new Promise((resolve,reject)=>{const done=()=>{cleanup();resolve();},bad=()=>{cleanup();reject(cancelled());};const cleanup=()=>{sb.removeEventListener('updateend',done);this.signal?.removeEventListener('abort',bad);};sb.addEventListener('updateend',done,{once:true});this.signal?.addEventListener('abort',bad,{once:true});try{sb.remove(start,end);}catch(e){cleanup();reject(e);}});
  }
  async clearBuffer(){if(!this.buffer?.buffered.length)return;
    const last=this.buffer.buffered.end(this.buffer.buffered.length-1);
    await this.removeRange(0,last);
  }
  beginAt(time){
    // Only one SourceBuffer writer may run at a time. Stop the prior Range
    // request and let its in-flight append finish before a new seek begins.
    const seq=++this.seq;this.fetchAbort?.abort();const ac=new AbortController();this.fetchAbort=ac;
    this.feed=(this.feed||Promise.resolve()).catch(()=>{}).then(()=>{
      if(!this.active||ac.signal.aborted)return;
      return this._playFrom(Math.max(0,time),seq,ac.signal);
    }).catch(e=>{
      if(this.active&&seq===this.seq&&e.name!=='AbortError'){
        this.onStatus(`MP4 串流錯誤：${e.message}`);console.error(e);
      }
    });
  }
  async _playFrom(time,seq,signal){
    const seek=time>0.3;
    if(seek){while(this.buffer.updating){await new Promise(r=>setTimeout(r,25));if(signal.aborted)return;}
      await this.clearBuffer();}
    let pos=seekIndex(this.p,time),n=0;
    while(this.active&&!signal.aborted&&seq===this.seq&&pos<this.p.video.samples.length){
      const chosen=choose(this.p,pos);
      const part=await fragment(this.p,chosen.selection,this.source,signal,++n);
      if(!this.active||signal.aborted||seq!==this.seq)return;
      // MSE is NOT archival storage: keep at most ~60s ahead. Network continues
      // only while buffer can accept data; avoid overwhelming Chrome memory.
      while(this.video.buffered.length && this.video.buffered.end(this.video.buffered.length-1)-this.video.currentTime>60){
        if(signal.aborted||!this.active||seq!==this.seq)return;
        await new Promise(r=>setTimeout(r,200));
      }
      await this.append(part);pos=chosen.next;
      // Bounded backward SourceBuffer retention. Old chunks can be fetched
      // again through the authenticated Range reader when seeking back.
      if(this.video.currentTime>120 && this.buffer.buffered.length && !this.buffer.updating){
        const cutoff=this.video.currentTime-90;
        const oldest=this.buffer.buffered.start(0);
        if(oldest<cutoff)await this.removeRange(0,cutoff);
      }
      this.onStatus(`加密 MP4 串流中，緩衝至 ${Math.round(chosen.timeEnd)} 秒`);
    }
    if(this.active&&!signal.aborted&&this.media.readyState==='open'&&!this.buffer.updating)this.media.endOfStream();
  }
  destroy(){if(this.closed)return;this.closed=true;
    this.parentSignal?.removeEventListener('abort',this.onParentAbort);this.lifetime.abort();
    if(this.onSeek)this.video.removeEventListener('seeking',this.onSeek);
    if(this.onVideoError)this.video.removeEventListener('error',this.onVideoError);
    this.fetchAbort?.abort();try{this.video.pause();}catch{}try{this.buffer?.abort();}catch{}try{this.video.removeAttribute('src');this.video.load();}catch{}if(this.url)URL.revokeObjectURL(this.url);this.source?.close();}
}
