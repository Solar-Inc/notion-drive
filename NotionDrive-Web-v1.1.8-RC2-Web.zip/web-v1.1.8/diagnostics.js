import {config} from './web-config.js';
const $ = id => document.getElementById(id);
$('api').onclick = async () => {
  $('api-result').textContent = '測試中…';
  try {
    const response = await fetch(`${config.apiBase}/users/me`, {
      headers: {'Authorization':'Bearer ndrive-invalid-cors-test-token','Notion-Version':'2026-03-11'},
      cache:'no-store',referrerPolicy:'no-referrer'
    });
    $('api-result').textContent = `已成功跨來源讀取 HTTP ${response.status}。HTTP 401 表示示範 Token 無效，但 CORS 測試已通過。`;
  } catch (e) {
    $('api-result').textContent = `瀏覽器未能跨來源讀取 Notion API：${e.name}。請從 DevTools Network 查詢 CORS/連線錯誤。`;
  }
};
async function testCdn(useProxy) {
  const output = $('cdn-result'), input = $('url').value.trim();
  output.textContent = '測試中…';
  let url;
  try {
    url = new URL(input);
    if (url.protocol !== 'https:') throw Error('只能使用 HTTPS');
  } catch {
    output.textContent = '請先貼入有效 HTTPS 簽署網址';return;
  }
  const proxy = config.cdnProxyBase.trim();
  if (useProxy && !proxy) {output.textContent = '未設定 web-config.js 的 cdnProxyBase';return;}
  const target = useProxy ? `${proxy}${proxy.includes('?')?'&':'?'}url=${encodeURIComponent(url.href)}` : url.href;
  try {
    const response = await fetch(target,{headers:{Range:'bytes=0-15'},cache:'no-store',credentials:'omit',referrerPolicy:'no-referrer'});
    const contentRange = response.headers.get('Content-Range'),length=response.headers.get('Content-Length');
    if (response.status === 206 && contentRange?.startsWith('bytes 0-15/') && (length === null || Number(length)===16)) {
      const bytes = new Uint8Array(await response.arrayBuffer());
      output.textContent = bytes.length===16 ? '通過：HTTP 206、Content-Range 可讀、收到 16 bytes。可進一步實測真正加密播放。' : '失敗：回應長度不是 16 bytes。';
    } else {
      await response.body?.cancel().catch(()=>{});
      output.textContent = `HTTP ${response.status}；Content-Range：${contentRange || '不可讀或不存在'}；Content-Length：${length || '未提供'}。Range Reader 要求 206 與精確長度。`;
    }
  } catch (e) {
    output.textContent = `讀取失敗（${e.name}）：可能是 CDN CORS、網址過期、網路錯誤或 Proxy 未部署。檢查 DevTools Network，勿在公開訊息貼上簽署網址。`;
  }
}
$('cdn').onclick = () => testCdn(false);
$('proxy').onclick = () => testCdn(true);
