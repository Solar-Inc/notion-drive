function t(key, substitutions) {
  const message = globalThis.chrome?.i18n?.getMessage?.(key, substitutions);
  return message || globalThis.chrome?.i18n?.getMessage?.("extensionName") || "Notion Drive";
}

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const MAGIC = encoder.encode("NDRVENC1");
const VERSION = 1;
const FIXED_HEADER_SIZE = 49;
const DEFAULT_CHUNK_SIZE = 8 * 1024 * 1024;
const HKDF_INFO = encoder.encode("Notion Drive encrypted file v1");
const WRAPPED_VMK_AAD = encoder.encode("Notion Drive wrapped VMK v1");
const KDF_ITERATIONS = 250000;

function concatBytes(parts) {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const output = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) {
    output.set(part, offset);
    offset += part.length;
  }
  return output;
}

function assertVmk(vmk) {
  const bytes = vmk instanceof Uint8Array ? vmk : null;
  if (!bytes || bytes.byteLength !== 32)
    throw new TypeError("VMK must be exactly 32 bytes");
  return bytes;
}

function base64url(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 32768)
    binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
  return btoa(binary)
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replaceAll("=", "");
}
function fromBase64url(value) {
  const normalized =
      value.replaceAll("-", "+").replaceAll("_", "/") +
      "=".repeat((4 - (value.length % 4)) % 4),
    binary = atob(normalized),
    out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

export function createVmk() {
  return crypto.getRandomValues(new Uint8Array(32));
}
export function encodeVmk(vmk) {
  return base64url(assertVmk(vmk));
}
export function decodeVmk(value) {
  return assertVmk(fromBase64url(String(value || "")));
}

async function passwordKek(password, salt, usages) {
  if (!password || password.length < 8)
    throw new Error(t("encryptionPasswordRequired"));
  const material = await crypto.subtle.importKey(
    "raw",
    encoder.encode(password),
    "PBKDF2",
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      hash: "SHA-256",
      salt,
      iterations: KDF_ITERATIONS,
    },
    material,
    { name: "AES-GCM", length: 256 },
    false,
    usages,
  );
}

export async function wrapVmk(vmk, password) {
  const keyBytes = assertVmk(vmk),
    salt = crypto.getRandomValues(new Uint8Array(16)),
    iv = crypto.getRandomValues(new Uint8Array(12)),
    kek = await passwordKek(password, salt, ["encrypt"]),
    cipher = new Uint8Array(
      await crypto.subtle.encrypt(
        { name: "AES-GCM", iv, additionalData: WRAPPED_VMK_AAD },
        kek,
        keyBytes,
      ),
    );
  return base64url(concatBytes([salt, iv, cipher]));
}

export async function unwrapVmk(token, password) {
  const bytes = fromBase64url(String(token || ""));
  if (bytes.length !== 16 + 12 + 32 + 16)
    throw new Error(t("metadataIncomplete"));
  const salt = bytes.slice(0, 16),
    iv = bytes.slice(16, 28),
    cipher = bytes.slice(28),
    kek = await passwordKek(password, salt, ["decrypt"]);
  try {
    return assertVmk(
      new Uint8Array(
        await crypto.subtle.decrypt(
          { name: "AES-GCM", iv, additionalData: WRAPPED_VMK_AAD },
          kek,
          cipher,
        ),
      ),
    );
  } catch {
    throw new Error(t("metadataPasswordDamaged"));
  }
}

// Separate password-derived key and random salt; never derived from the VMK.
// Only the explicit credential allowlist below can enter Chrome Sync.
export function validSyncProfile(packet) {
  return packet?.v === 1 && /^[a-f0-9-]{36}$/i.test(packet.profileId) &&
    typeof packet.name === "string" && packet.name.length <= 80 &&
    /^[A-Za-z0-9_-]{22}$/.test(packet.salt) &&
    /^[A-Za-z0-9_-]{16}$/.test(packet.iv) &&
    typeof packet.cipher === "string" && packet.cipher.length <= 4096 &&
    packet.cipher.length >= 24;
}
function syncAad(packet) {
  return encoder.encode(JSON.stringify(["Notion Drive profile sync v1", packet.profileId, packet.name]));
}
async function syncKey(password, packet, usages) {
  return passwordKek(password, concatBytes([
    encoder.encode(`Notion Drive profile sync v1:${packet.profileId}:`),
    fromBase64url(packet.salt),
  ]), usages);
}
export async function encryptSyncProfile(profile, password) {
  const packet = {
    v: 1, profileId: profile.profileId, name: profile.name,
    salt: base64url(crypto.getRandomValues(new Uint8Array(16))),
    iv: base64url(crypto.getRandomValues(new Uint8Array(12))),
  };
  const key = await syncKey(password, packet, ["encrypt"]);
  packet.cipher = base64url(new Uint8Array(await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: fromBase64url(packet.iv), additionalData: syncAad(packet) },
    key, encoder.encode(JSON.stringify({ notionToken: profile.notionToken, rootPageId: profile.rootPageId })),
  )));
  if (!validSyncProfile(packet)) throw new Error(t("syncProfileTooLarge"));
  return packet;
}
export async function decryptSyncProfile(packet, password) {
  if (!validSyncProfile(packet)) throw new Error(t("invalidSyncProfile"));
  const key = await syncKey(password, packet, ["decrypt"]);
  const value = JSON.parse(decoder.decode(await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: fromBase64url(packet.iv), additionalData: syncAad(packet) },
    key, fromBase64url(packet.cipher),
  )));
  if (typeof value.notionToken !== "string" || !value.notionToken ||
      typeof value.rootPageId !== "string" || !/^[a-f0-9-]{32,36}$/i.test(value.rootPageId))
    throw new Error(t("invalidSyncProfile"));
  return { notionToken: value.notionToken, rootPageId: value.rootPageId };
}
export async function sealLocalVmk(vmk, key, binding) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: encoder.encode(binding) }, key, assertVmk(vmk),
  );
  return { iv: base64url(iv), cipher: base64url(new Uint8Array(cipher)) };
}
export async function openLocalVmk(packet, key, binding) {
  return assertVmk(new Uint8Array(await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: fromBase64url(packet.iv), additionalData: encoder.encode(binding) },
    key, fromBase64url(packet.cipher),
  )));
}

async function fileKey(vmk, salt, usages) {
  const base = await crypto.subtle.importKey(
    "raw",
    assertVmk(vmk),
    "HKDF",
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    { name: "HKDF", hash: "SHA-256", salt, info: HKDF_INFO },
    base,
    { name: "AES-GCM", length: 256 },
    false,
    usages,
  );
}

async function purposeKey(vmk, salt, purpose, usages) {
  const base = await crypto.subtle.importKey(
    "raw",
    assertVmk(vmk),
    "HKDF",
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    {
      name: "HKDF",
      hash: "SHA-256",
      salt,
      info: encoder.encode(`Notion Drive ${purpose} v1`),
    },
    base,
    { name: "AES-GCM", length: 256 },
    false,
    usages,
  );
}
export async function encryptMetadata(value, vmk, purpose = "metadata") {
  const salt = crypto.getRandomValues(new Uint8Array(16)),
    iv = crypto.getRandomValues(new Uint8Array(12)),
    key = await purposeKey(vmk, salt, purpose, ["encrypt"]),
    plain = encoder.encode(JSON.stringify(value)),
    cipher = new Uint8Array(
      await crypto.subtle.encrypt(
        { name: "AES-GCM", iv, additionalData: encoder.encode(purpose) },
        key,
        plain,
      ),
    );
  return base64url(concatBytes([salt, iv, cipher]));
}
export async function decryptMetadata(token, vmk, purpose = "metadata") {
  const bytes = fromBase64url(token);
  if (bytes.length < 45) throw new Error(t("metadataIncomplete"));
  const salt = bytes.slice(0, 16),
    iv = bytes.slice(16, 28),
    cipher = bytes.slice(28),
    key = await purposeKey(vmk, salt, purpose, ["decrypt"]);
  try {
    return JSON.parse(
      decoder.decode(
        await crypto.subtle.decrypt(
          { name: "AES-GCM", iv, additionalData: encoder.encode(purpose) },
          key,
          cipher,
        ),
      ),
    );
  } catch {
    throw new Error(t("metadataPasswordDamaged"));
  }
}

function makeIv(prefix, index) {
  const iv = new Uint8Array(12);
  iv.set(prefix, 0);
  new DataView(iv.buffer).setUint32(8, index, false);
  return iv;
}

function createHeader({
  chunkSize,
  originalSize,
  salt,
  noncePrefix,
  originalName,
  originalMime,
}) {
  const name = encoder.encode(originalName),
    mime = encoder.encode(originalMime || "application/octet-stream");
  if (name.length > 65535 || mime.length > 65535)
    throw new Error(t("headerNameMimeTooLong"));
  const header = new Uint8Array(FIXED_HEADER_SIZE + name.length + mime.length),
    view = new DataView(header.buffer);
  header.set(MAGIC, 0);
  view.setUint8(8, VERSION);
  view.setUint32(9, chunkSize, false);
  view.setBigUint64(13, BigInt(originalSize), false);
  header.set(salt, 21);
  header.set(noncePrefix, 37);
  view.setUint16(45, name.length, false);
  view.setUint16(47, mime.length, false);
  header.set(name, FIXED_HEADER_SIZE);
  header.set(mime, FIXED_HEADER_SIZE + name.length);
  return header;
}

export async function createEncryptedDescriptor(
  file,
  vmk,
  storedName,
  hideMetadata = false,
  metadataToken = null,
) {
  assertVmk(vmk);
  const salt = crypto.getRandomValues(new Uint8Array(16)),
    noncePrefix = crypto.getRandomValues(new Uint8Array(8));
  const chunkSize = DEFAULT_CHUNK_SIZE,
    originalMime = hideMetadata
      ? "application/octet-stream"
      : file.type || "application/octet-stream",
    headerName = metadataToken
      ? `NDFMETA1.${metadataToken}`
      : hideMetadata
        ? "encrypted"
        : file.name;
  const header = createHeader({
    chunkSize,
    originalSize: file.size,
    salt,
    noncePrefix,
    originalName: headerName,
    originalMime,
  });
  const chunkCount = Math.ceil(file.size / chunkSize),
    totalSize = header.length + file.size + chunkCount * 16;
  const key = await fileKey(vmk, salt, ["encrypt"]);
  return {
    file,
    vmk,
    storedName,
    originalName: file.name,
    originalMime,
    chunkSize,
    chunkCount,
    totalSize,
    salt,
    noncePrefix,
    header,
    key,
  };
}

function abortIf(signal) {
  if (signal?.aborted) throw new DOMException(t("cancelled"), "AbortError");
}

async function* encryptedSegments(descriptor, onProgress, signal) {
  abortIf(signal);
  yield descriptor.header;
  for (let index = 0; index < descriptor.chunkCount; index++) {
    abortIf(signal);
    const start = index * descriptor.chunkSize,
      end = Math.min(start + descriptor.chunkSize, descriptor.file.size);
    const plain = await descriptor.file.slice(start, end).arrayBuffer();
    const encrypted = await crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv: makeIv(descriptor.noncePrefix, index),
        additionalData: descriptor.header,
        tagLength: 128,
      },
      descriptor.key,
      plain,
    );
    abortIf(signal);
    yield new Uint8Array(encrypted);
    onProgress?.(end, descriptor.file.size);
  }
}

export async function* encryptedParts(
  descriptor,
  partSize,
  onProgress,
  signal,
) {
  let part = new Uint8Array(partSize),
    used = 0;
  for await (const segment of encryptedSegments(
    descriptor,
    onProgress,
    signal,
  )) {
    let offset = 0;
    while (offset < segment.length) {
      const take = Math.min(part.length - used, segment.length - offset);
      part.set(segment.subarray(offset, offset + take), used);
      used += take;
      offset += take;
      if (used === part.length) {
        yield part;
        part = new Uint8Array(partSize);
        used = 0;
      }
    }
  }
  if (used) yield part.slice(0, used);
}

class StreamBytes {
  constructor(reader) {
    this.reader = reader;
    this.buffer = new Uint8Array(0);
  }
  async readExactly(length) {
    const output = new Uint8Array(length);
    let written = 0;
    while (written < length) {
      if (!this.buffer.length) {
        const next = await this.reader.read();
        if (next.done) throw new Error(t("encryptedFileIncomplete"));
        this.buffer =
          next.value instanceof Uint8Array
            ? next.value
            : new Uint8Array(next.value);
      }
      const take = Math.min(length - written, this.buffer.length);
      output.set(this.buffer.subarray(0, take), written);
      written += take;
      this.buffer = this.buffer.subarray(take);
    }
    return output;
  }
}

function parseFixedHeader(fixed) {
  if (
    fixed.length !== FIXED_HEADER_SIZE ||
    !MAGIC.every((value, index) => fixed[index] === value)
  )
    throw new Error(t("notNotionDriveEncryptedFile"));
  const view = new DataView(fixed.buffer, fixed.byteOffset, fixed.byteLength),
    version = view.getUint8(8);
  if (version !== VERSION) throw new Error(t("unsupportedEncryptionVersion", [String(version)]));
  return {
    chunkSize: view.getUint32(9, false),
    originalSize: Number(view.getBigUint64(13, false)),
    salt: fixed.slice(21, 37),
    noncePrefix: fixed.slice(37, 45),
    nameLength: view.getUint16(45, false),
    mimeLength: view.getUint16(47, false),
  };
}

async function decryptStream(readable, vmk, writable, onProgress, signal) {
  abortIf(signal);
  const bytes = new StreamBytes(readable.getReader()),
    fixed = await bytes.readExactly(FIXED_HEADER_SIZE),
    info = parseFixedHeader(fixed);
  if (!Number.isSafeInteger(info.originalSize) || info.originalSize < 0 ||
      !info.chunkSize || info.chunkSize > 64 * 1024 * 1024)
    throw new Error(t("encryptedFileIncomplete"));
  const variable = await bytes.readExactly(info.nameLength + info.mimeLength),
    header = concatBytes([fixed, variable]);
  const originalName = decoder.decode(variable.subarray(0, info.nameLength)),
    originalMime = decoder.decode(variable.subarray(info.nameLength));
  const key = await fileKey(vmk, info.salt, ["decrypt"]),
    chunkCount = Math.ceil(info.originalSize / info.chunkSize);
  let remaining = info.originalSize,
    completed = 0;
  for (let index = 0; index < chunkCount; index++) {
    abortIf(signal);
    const plainLength = Math.min(info.chunkSize, remaining),
      cipher = await bytes.readExactly(plainLength + 16);
    let plain;
    try {
      plain = await crypto.subtle.decrypt(
        {
          name: "AES-GCM",
          iv: makeIv(info.noncePrefix, index),
          additionalData: header,
          tagLength: 128,
        },
        key,
        cipher,
      );
    } catch {
      throw new Error(t("encryptionPasswordOrFileDamaged"));
    }
    abortIf(signal);
    await writable.write(new Uint8Array(plain));
    remaining -= plainLength;
    completed += plainLength;
    onProgress?.(completed, info.originalSize);
  }
  if (bytes.buffer.length || !(await bytes.reader.read()).done)
    throw new Error(t("encryptedFileIncomplete"));
  return { originalName, originalMime, originalSize: info.originalSize };
}

async function decryptSources(
  source,
  vmk,
  writable,
  onProgress,
  signal,
  totalSize,
  errorPrefix,
) {
  const sources = Array.isArray(source) ? source : [source];
  let completedBefore = 0,
    firstInfo = null;
  for (const url of sources) {
    abortIf(signal);
    // A storage-layer shard stream is one complete, unchanged NDRVENC1 file.
    const response = url instanceof ReadableStream
      ? { ok: true, body: url }
      : await fetch(globalThis.__NDRIVE_FETCH_URL__?.(url) || url, { signal });
    if (!response.ok || !response.body) {
      const error = new Error(
        t("httpStatusError", [String(errorPrefix), String(response.status)]),
      );
      error.status = response.status;
      throw error;
    }
    const info = await decryptStream(
      response.body,
      vmk,
      writable,
      (done, currentTotal) =>
        onProgress?.(
          completedBefore + done,
          totalSize ||
            (sources.length === 1
              ? currentTotal
              : completedBefore + currentTotal),
        ),
      signal,
    );
    firstInfo ||= info;
    completedBefore += info.originalSize;
  }
  return {
    ...firstInfo,
    originalSize: completedBefore,
  };
}

export async function decryptToBlob(
  source,
  vmk,
  mime = "application/octet-stream",
  { onProgress, signal, totalSize } = {},
) {
  abortIf(signal);
  const chunks = [],
    writable = {
      async write(value) {
        abortIf(signal);
        chunks.push(value);
      },
    };
  await decryptSources(
    source,
    vmk,
    writable,
    onProgress,
    signal,
    totalSize,
    t("previewDownloadFailed"),
  );
  abortIf(signal);
  return new Blob(chunks, { type: mime });
}

export async function decryptToWritable(
  source,
  vmk,
  writable,
  { onProgress, signal, totalSize } = {},
) {
  abortIf(signal);
  return decryptSources(
    source,
    vmk,
    writable,
    onProgress,
    signal,
    totalSize,
    t("downloadFailed"),
  );
}

export async function decryptDownload(
  source,
  vmk,
  suggestedName,
  { onProgress, signal, totalSize } = {},
) {
  if (!window.showSaveFilePicker)
    throw new Error(t("streamingDownloadUnsupported"));
  abortIf(signal);
  const handle = await window.showSaveFilePicker({ suggestedName });
  abortIf(signal);
  const writable = await handle.createWritable();
  try {
    const info = await decryptToWritable(source, vmk, writable, {
      onProgress,
      signal,
      totalSize,
    });
    await writable.close();
    return info;
  } catch (error) {
    try {
      await writable.abort();
    } catch {}
    throw error;
  }
}

export async function decryptLocalFile(file, vmk) {
  const chunks = [],
    writable = {
      async write(value) {
        chunks.push(value);
      },
    };
  const info = await decryptStream(file.stream(), vmk, writable);
  let name = t("recoveredFileName"),
    mime = "application/octet-stream";
  if (info.originalName.startsWith("NDFMETA1.")) {
    const metadata = await decryptMetadata(
      info.originalName.slice(9),
      vmk,
      "file-metadata",
    );
    name = metadata.name || name;
    mime = metadata.mime || mime;
  } else {
    name = info.originalName || name;
    mime = info.originalMime || mime;
  }
  return { blob: new Blob(chunks, { type: mime }), name, mime };
}
