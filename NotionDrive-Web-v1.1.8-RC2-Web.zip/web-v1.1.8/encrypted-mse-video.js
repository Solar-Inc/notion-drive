/**
 * Optional authenticated streaming preview for container formats that can be
 * fed directly to MSE. This DOES NOT convert ordinary MP4 into fragmented MP4.
 * NDRVENC1 bytes stay encrypted at rest. Nothing is written to persistent storage.
 */
function scanAscii(bytes, needle) {
  const s=Array.from(needle, c=>c.charCodeAt(0));
  outer: for(let i=0;i<=bytes.length-s.length;i++) {
    for(let j=0;j<s.length;j++) if(bytes[i+j]!==s[j])continue outer;
    return i;
  }
  return -1;
}
function getMp4Codecs(bytes) {
  const avc=scanAscii(bytes,'avcC');
  const av1=scanAscii(bytes,'av01');
  const vp9=scanAscii(bytes,'vp09');
  const hvc=scanAscii(bytes,'hvcC');
  let video='';
  if(avc>=0 && avc+7<bytes.length) {
    const hex=x=>x.toString(16).padStart(2,'0').toUpperCase();
    video=`avc1.${hex(bytes[avc+5])}${hex(bytes[avc+6])}${hex(bytes[avc+7])}`;
  } else if(av1>=0 || vp9>=0 || hvc>=0) return null; // require accurate codec profile
  if(!video) return null;
  const audio=scanAscii(bytes,'mp4a')>=0 ? ', mp4a.40.2' : '';
  return `video/mp4; codecs="${video}${audio}"`;
}
// EBML/WebM codec IDs are plain ASCII in the Tracks element. Don't pass MKV's
// Matroska DocType through WebM MSE or invent codecs for unknown tracks.
export function detectWebmMseType(input, audioOnly=false) {
  const b=input instanceof Uint8Array?input:new Uint8Array(input);
  if(b.length<32||b[0]!==0x1a||b[1]!==0x45||b[2]!==0xdf||b[3]!==0xa3)return null;
  const head=b.subarray(0,Math.min(b.length,262144));
  if(scanAscii(head,'webm')<0)return null;
  const video = scanAscii(head,'V_VP9')>=0?'vp9':scanAscii(head,'V_VP8')>=0?'vp8':scanAscii(head,'V_AV1')>=0?'av01.0.05M.08':null;
  const audio = scanAscii(head,'A_OPUS')>=0?'opus':scanAscii(head,'A_VORBIS')>=0?'vorbis':null;
  if(audioOnly&&video)return null;
  if(audioOnly&&!audio)return null;
  if(!audioOnly&&!video)return null;
  // An actual VP9+Opus WebM fixture triggers Chrome's MSE timestamp order error.
  // Until remux/timestamp normalization is verified, preserve the 19.3 Blob path.
  if(!audioOnly&&audio)return null;
  const list=[video,audio].filter(Boolean);
  return `${audioOnly?'audio':'video'}/webm; codecs="${list.join(', ')}"`;
}
export function detectMseVideoType(input, hint='') {
  const bytes=input instanceof Uint8Array ? input : new Uint8Array(input);
  if(bytes.length<16) return null;
  // Only known-good WebM tracks enter MSE. Mixed VP9+Opus failed Chrome tests
  // and remains on the original Blob preview path.
  if(bytes[0]===0x1a && bytes[1]===0x45 && bytes[2]===0xdf && bytes[3]===0xa3) return detectWebmMseType(bytes);
  // MSE requires fragmented ISO BMFF, whose moov includes mvex.
  // A normal MP4 with plain mdat samples MUST fall back, not be passed to MSE.
  if(scanAscii(bytes,'ftyp')>=0 && scanAscii(bytes,'moov')>=0 && scanAscii(bytes,'mvex')>=0)
    return getMp4Codecs(bytes);
  return null;
}
const cancelled = ()=>new DOMException('已關閉影片預覽','AbortError');
export class EncryptedMseVideo {
  constructor(video,{signal=null,onStatus=null}={}) {
    this.video=video;
    this.parentSignal=signal;
    this.lifetime=new AbortController();this.signal=this.lifetime.signal;
    this.onStatus=onStatus;
    this.media=null;
    this.buffer=null;
    this.url=null;
    this.closed=false;
    this.abort=()=>this.destroy();
    this.parentSignal?.addEventListener('abort',this.abort,{once:true});
    if(this.parentSignal?.aborted)this.destroy();
  }
  get active(){return !this.closed && !this.signal?.aborted;}
  async start(source,total,mime) {
    if(!this.active)throw cancelled();
    if(typeof MediaSource==='undefined'||!MediaSource.isTypeSupported(mime))throw new Error(`MSE 不支援 ${mime}`);
    this.media=new MediaSource();
    this.url=URL.createObjectURL(this.media);
    this.video.src=this.url;
    await new Promise((resolve,reject)=>{
      if(!this.active)return reject(cancelled());
      const done=()=>{clean();resolve();};
      const fail=()=>{clean();reject(cancelled());};
      const clean=()=>{this.media?.removeEventListener('sourceopen',done);this.signal?.removeEventListener('abort',fail);};
      this.media.addEventListener('sourceopen',done,{once:true});
      this.signal?.addEventListener('abort',fail,{once:true});
    });
    if(!this.active)throw cancelled();
    this.buffer=this.media.addSourceBuffer(mime);
    // Start async: playing can start after receiving only the first few fragments.
    this.task=this._feed(source,total).catch(e=>{
      if(!this.active||e.name==='AbortError')return;
      this.onStatus?.(`串流失敗：${e.message}`);
      console.error('[NotionDrive encrypted MSE]',e);
    });
  }
  async _append(data){
    if(!this.active)throw cancelled();
    const sb=this.buffer;
    await new Promise((resolve,reject)=>{
      const done=()=>{clean();resolve();};
      const fail=()=>{clean();reject(new Error('MSE 解碼或封裝錯誤'));};
      const abort=()=>{clean();reject(cancelled());};
      const clean=()=>{sb.removeEventListener('updateend',done);sb.removeEventListener('error',fail);this.signal?.removeEventListener('abort',abort);};
      sb.addEventListener('updateend',done,{once:true});
      sb.addEventListener('error',fail,{once:true});
      this.signal?.addEventListener('abort',abort,{once:true});
      try{sb.appendBuffer(data);}catch(e){clean();reject(e);}
    });
  }
  async _cleanup(){
    if(!this.active || this.buffer.updating || this.video.currentTime<100)return;
    const sb=this.buffer;
    // Never hold on to the entire history while streaming a multi-hour video.
    const removeBefore=this.video.currentTime-90;
    if(!sb.buffered.length||sb.buffered.start(0)>=removeBefore)return;
    const removeTo=Math.min(removeBefore,sb.buffered.end(0));
    if(removeTo<=sb.buffered.start(0))return;
    await new Promise((resolve,reject)=>{
      const done=()=>{this.signal?.removeEventListener('abort',fail);resolve();};
      const fail=()=>{sb.removeEventListener('updateend',done);reject(cancelled());};
      sb.addEventListener('updateend',done,{once:true});
      this.signal?.addEventListener('abort',fail,{once:true});
      try{sb.remove(0,removeTo);}catch(e){sb.removeEventListener('updateend',done);reject(e);}
    });
  }
  async _feed(source,total){
    let bytes=0;
    for await(const {offset,data} of source.readParts(0,total,this.signal)){
      if(!this.active)throw cancelled();
      if(offset!==bytes)throw new Error(`遠端解密資料不連續：${offset} != ${bytes}`);
      // Independent RAM preloading continues while MSE waits for playback.
      while(this.active && this.video.buffered.length &&
        this.video.buffered.end(this.video.buffered.length-1)-this.video.currentTime>60)
        await new Promise(resolve=>setTimeout(resolve,150));
      if(!this.active)throw cancelled();
      await this._append(data);
      bytes+=data.byteLength;
      if(bytes % (8*1024*1024)<data.byteLength){
        await this._cleanup();
        this.onStatus?.(`持續下載並驗證解密 ${Math.min(100,100*bytes/total).toFixed(1)}%（循序播放）`);
      }
    }
    if(!this.active)return;
    if(bytes!==total)throw new Error('影片讀取長度不足');
    if(this.media.readyState==='open'&&!this.buffer.updating)this.media.endOfStream();
    this.onStatus?.('已下載及解密至影片結尾（播放緩衝可能被清理）');
  }
  destroy(){
    if(this.closed)return;
    this.closed=true;
    this.parentSignal?.removeEventListener('abort',this.abort);
    this.lifetime.abort();
    try{this.video.pause();}catch{}
    try{this.buffer?.abort();}catch{}
    try{this.video.removeAttribute('src');this.video.load();}catch{}
    if(this.url){URL.revokeObjectURL(this.url);this.url=null;}
    this.buffer=null;this.media=null;
  }
}
