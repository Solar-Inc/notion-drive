// Web configuration. Do not paste a Notion Token or Vault password here.
export const config = Object.freeze({
  apiBase: "https://api.notion.com/v1",
  // Leave empty for direct CDN access. Configure ONLY a trusted, personally
  // controlled proxy if the CDN's CORS headers do not allow binary Range reads.
  cdnProxyBase: "",
});
