/** Authenticated NDRVENC1 MP3 stream -> native Chrome MPEG Audio MSE.
 * This is a byte-stream adapter, not a transcoder. No disk cache is created.
 * Only supported if Chrome advertises MediaSource audio/mpeg support.
 */
const cancelled=()=>new DOMException('預覽已關閉','AbortError');
export class EncryptedMp3Player {
  constructor(audio,source,{signal,onStatus,mime='audio/mpeg',label='MP3'}={}){
    this.audio=audio;this.source=source;this.parentSignal=signal;this.lifetime=new AbortController();this.signal=this.lifetime.signal;this.onStatus=onStatus||(()=>{});this.mime=mime;this.label=label;
    this.closed=false;this.url=null;this.sb=null;this.ms=null;
    this.onParentAbort=()=>this.destroy();this.parentSignal?.addEventListener('abort',this.onParentAbort,{once:true});if(this.parentSignal?.aborted)this.destroy();
  }
  get active(){return !this.closed&&!this.signal?.aborted;}
  async update(bytes){
    if(!this.active)throw cancelled();const sb=this.sb;
    await new Promise((resolve,reject)=>{
      const done=()=>{clean();resolve();},bad=()=>{clean();reject(Error('MP3 MSE 追加失敗'));};
      const clean=()=>{sb.removeEventListener('updateend',done);sb.removeEventListener('error',bad);this.signal?.removeEventListener('abort',bad);};
      sb.addEventListener('updateend',done,{once:true});sb.addEventListener('error',bad,{once:true});this.signal?.addEventListener('abort',bad,{once:true});
      try{sb.appendBuffer(bytes);}catch(e){clean();reject(e);}
    });
  }
  async removeOld(){
    if(!this.active||this.sb.updating||!this.sb.buffered.length)return;
    const before=this.audio.currentTime-90;
    if(before<=0||this.sb.buffered.start(0)>=before)return;
    const sb=this.sb;
    await new Promise((resolve,reject)=>{
      const done=()=>{clean();resolve();},bad=()=>{clean();reject(cancelled());};
      const clean=()=>{sb.removeEventListener('updateend',done);this.signal?.removeEventListener('abort',bad);};
      sb.addEventListener('updateend',done,{once:true});this.signal?.addEventListener('abort',bad,{once:true});
      try{sb.remove(0,before);}catch(e){clean();reject(e);}
    });
  }
  async start(){
    if(!globalThis.MediaSource?.isTypeSupported?.(this.mime))throw Error(`Chrome 不支援 ${this.mime} MSE，保留原版完整解密音訊預覽`);
    const {total}=await this.source.ready();
    if(!this.active)throw cancelled();
    this.ms=new MediaSource();this.url=URL.createObjectURL(this.ms);this.audio.src=this.url;
    await new Promise((resolve,reject)=>{
      const ok=()=>{clean();resolve();},bad=()=>{clean();reject(cancelled());};
      const clean=()=>{this.ms.removeEventListener('sourceopen',ok);this.signal?.removeEventListener('abort',bad);};
      this.ms.addEventListener('sourceopen',ok,{once:true});this.signal?.addEventListener('abort',bad,{once:true});
    });
    if(!this.active)throw cancelled();this.sb=this.ms.addSourceBuffer(this.mime);
    this.readTask=this.feed(total);
  }
  async feed(total){
    let pos=0;
    try {
      while(this.active&&pos<total){
        // Playback-first policy: keep MSE bounded. Download can pause when
        // >60s ahead; no hidden unbounded queue after the audio is paused.
        while(this.active&&this.audio.buffered.length&&
          this.audio.buffered.end(this.audio.buffered.length-1)-this.audio.currentTime>60)
          await new Promise(r=>setTimeout(r,150));
        if(!this.active)return;
        const end=Math.min(total,pos+256*1024);
        const data=await this.source.readRange(pos,end,this.signal);
        if(!this.active)return;
        await this.update(data);pos=end;
        await this.removeOld();
        this.onStatus(`${this.label} 線上播放中 · 已接收 ${Math.round(pos/1048576*10)/10} / ${Math.round(total/1048576*10)/10} MiB`);
      }
      if(this.active&&this.ms.readyState==='open'&&!this.sb.updating)this.ms.endOfStream();
    }catch(e){if(this.active&&e.name!=='AbortError'){this.onStatus(`${this.label} 串流中斷：${e.message}`);console.warn(e);}}
  }
  destroy(){if(this.closed)return;this.closed=true;
    this.parentSignal?.removeEventListener('abort',this.onParentAbort);this.lifetime.abort();
    try{this.audio.pause();}catch{}try{if(this.sb&&!this.sb.updating)this.sb.abort();}catch{}
    try{this.audio.removeAttribute('src');this.audio.load();}catch{}
    if(this.url)URL.revokeObjectURL(this.url);
    this.source?.close();
  }
}
