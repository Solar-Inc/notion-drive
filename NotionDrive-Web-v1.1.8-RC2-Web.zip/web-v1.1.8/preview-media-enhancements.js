/** Minimal keyboard-only controls for the original v1.1.4 preview.
 * Does not create a speed button or modify original file toolbar/UI.
 * No edits to encryption, Range, upload/download, FLV and MSE engines.
 */
export const MIN_PLAYBACK_RATE=0.25;
export const MAX_PLAYBACK_RATE=16;
export const PLAYBACK_RATES=Object.freeze(Array.from({length:64},(_,i)=>(i+1)/4));
const rateKey='notionDrive.previewPlaybackRate';
const alternateKey='notionDrive.previewAlternatePlaybackRate';
const EPSILON=0.001;
export function nearestPlaybackRate(value){
  const n=Number(value);
  return Number.isFinite(n)?Math.min(16,Math.max(0.25,Math.round(n*4)/4)):1;
}
export function stepPlaybackRate(rate,direction){
  return nearestPlaybackRate(nearestPlaybackRate(rate)+(direction>=0?0.25:-0.25));
}
export function installPreviewMediaEnhancements({stage,dialog,getItemId,getSessionId=getItemId,onThumbnail=()=>{}}){
  let currentRate=1, alternate=2, activeMedia=null, mediaBinding=null, toastTimer=null;
  let activeSession=null;
  let fullscreenBusy=false, destroyed=false;
  const lifetime=new AbortController(), captured=new WeakSet();
  function stored(key,fallback){
    try{const raw=localStorage.getItem(key);return raw===null?fallback:nearestPlaybackRate(raw);}catch{return fallback;}
  }
  // Persist last non-1x speed, but do not silently auto-apply a speed to a new video.
  // Press S to recall it; the original play-start behavior remains at 1x.
  const saved=stored(rateKey,1);
  alternate=stored(alternateKey,saved!==1?saved:2);
  if(alternate===1)alternate=2;
  function persist(){
    try{localStorage.setItem(rateKey,String(currentRate));localStorage.setItem(alternateKey,String(alternate));}catch{}
  }
  const indicator=document.createElement('div');
  indicator.className='preview-media-toast';
  indicator.setAttribute('role','status');indicator.setAttribute('aria-live','polite');
  function notify(message){
    if(destroyed||!dialog.open||!activeMedia)return;
    if(!stage.contains(indicator))stage.append(indicator);
    indicator.textContent=message;indicator.classList.add('visible');
    clearTimeout(toastTimer);
    toastTimer=setTimeout(()=>indicator.classList.remove('visible'),650);
  }
  function setRate(value,{notifyUser=false}={}){
    if(!activeMedia)return currentRate;
    const next=nearestPlaybackRate(value);
    try{activeMedia.playbackRate=next;activeMedia.defaultPlaybackRate=next;}
    catch{notify('無法設定此播放速度');return currentRate;}
    currentRate=next;
    if(Math.abs(next-1)>EPSILON)alternate=next;
    persist();
    if(notifyUser)notify(`${Number(next.toFixed(2))}×`);
    return currentRate;
  }
  function readActualRate(){
    const changed=activeMedia?.playbackRate;
    if(Number.isFinite(changed)&&changed>=MIN_PLAYBACK_RATE&&changed<=MAX_PLAYBACK_RATE){
      currentRate=changed;
      if(Math.abs(changed-1)>EPSILON)alternate=nearestPlaybackRate(changed);
    }
    return currentRate;
  }
  function toggleRate(){readActualRate();return setRate(Math.abs(currentRate-1)<EPSILON?alternate:1,{notifyUser:true});}
  const ownsFullscreen=()=>Boolean(document.fullscreenElement &&
    (document.fullscreenElement===stage || stage.contains(document.fullscreenElement)));
  function exitOwnedFullscreen(){
    if(ownsFullscreen())void document.exitFullscreen().catch(()=>{});
  }
  async function toggleFullscreen(){
    if(fullscreenBusy)return;
    fullscreenBusy=true;
    try{
      if(document.fullscreenElement){if(ownsFullscreen())await document.exitFullscreen();}
      else{
        await stage.requestFullscreen();
        if(!dialog.open||destroyed||!activeMedia)exitOwnedFullscreen();
      }
    }catch{notify('無法切換全螢幕');}
    finally{fullscreenBusy=false;}
  }
  function editable(event){
    return (event.composedPath?.()||[event.target]).some(node=>
      node instanceof Element && (node.isContentEditable||Boolean(node.closest(
        'input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="combobox"]'
      )))
    );
  }
  function keyboard(event){
    if(destroyed||!dialog.open||!activeMedia?.isConnected||event.defaultPrevented||
      event.isComposing||event.keyCode===229||event.ctrlKey||event.altKey||event.metaKey||editable(event))return;
    if([...document.querySelectorAll('dialog:modal')].some(node=>node!==dialog))return;
    if(document.fullscreenElement&&!ownsFullscreen())return;
    const code=String(event.code||'');
    const key=String(event.key||'').toLowerCase();
    const physical={KeyA:'decrease',KeyS:'toggle',KeyD:'increase',KeyF:'fullscreen'};
    const logical={a:'decrease',s:'toggle',d:'increase',f:'fullscreen'};
    const command=physical[code]||logical[key];
    if(!command||(command==='fullscreen'&&activeMedia.tagName!=='VIDEO'))return;
    event.preventDefault();event.stopImmediatePropagation();
    if(event.repeat&&(command==='toggle'||command==='fullscreen'))return;
    readActualRate();
    if(command==='decrease')setRate(stepPlaybackRate(currentRate,-1),{notifyUser:true});
    else if(command==='increase')setRate(stepPlaybackRate(currentRate,1),{notifyUser:true});
    else if(command==='toggle')toggleRate();
    else void toggleFullscreen();
  }
  document.addEventListener('keydown',keyboard,{capture:true,signal:lifetime.signal});
  function capture(video){
    if(destroyed||!dialog.open||video!==activeMedia||!stage.contains(video)||captured.has(video)||
      video.readyState<2||!video.videoWidth||!video.videoHeight||
      !Number.isFinite(video.currentTime)||video.currentTime<0.5)return;
    const itemId=getItemId();if(!itemId)return;
    let canvas;
    try{
      canvas=document.createElement('canvas');canvas.width=256;canvas.height=144;
      const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)return;
      ctx.fillStyle='#000';ctx.fillRect(0,0,256,144);
      const scale=Math.min(256/video.videoWidth,144/video.videoHeight);
      const w=video.videoWidth*scale,h=video.videoHeight*scale;
      ctx.drawImage(video,(256-w)/2,(144-h)/2,w,h);
      const dataUrl=canvas.toDataURL('image/webp',0.68);
      if(dataUrl.startsWith('data:image/')){captured.add(video);onThumbnail(itemId,dataUrl);}
    }catch{/* Cross-origin canvas policies are preserved. */}
    finally{if(canvas)canvas.width=canvas.height=0;}
  }
  function bind(media){
    mediaBinding=new AbortController();
    const options={signal:mediaBinding.signal};
    // A streaming fallback can replace the media element within the same preview.
    // Only a new preview session resets the rate; S still recalls the saved speed.
    const session=getSessionId?.();
    if(session!==activeSession){currentRate=1;activeSession=session;}
    try{media.defaultPlaybackRate=currentRate;media.playbackRate=currentRate;}catch{}
    media.addEventListener('ratechange',()=>{
      if(destroyed||media!==activeMedia||!dialog.open)return;
      readActualRate();persist();
    },options);
    if(media.tagName==='VIDEO')for(const type of ['loadeddata','timeupdate','seeked'])
      media.addEventListener(type,()=>capture(media),options);
  }
  function refresh(){
    if(destroyed)return;
    if(!dialog.open){activeSession=null;currentRate=1;}
    const media=dialog.open?stage.querySelector('video,audio'):null;
    if(media!==activeMedia){
      mediaBinding?.abort();mediaBinding=null;activeMedia=media;
      if(media)bind(media);
      else{clearTimeout(toastTimer);indicator.remove();exitOwnedFullscreen();}
    }
    dialog.classList.toggle('media-preview',Boolean(activeMedia));
    stage.classList.toggle('media-preview-stage',Boolean(activeMedia));
  }
  const observer=new MutationObserver(refresh);
  observer.observe(stage,{childList:true,subtree:true});
  const dialogObserver=new MutationObserver(refresh);
  dialogObserver.observe(dialog,{attributes:true,attributeFilter:['open']});
  dialog.addEventListener('close',refresh,{signal:lifetime.signal});
  refresh();
  return {setRate,toggleRate,get rate(){return currentRate;},destroy(){
    if(destroyed)return;
    destroyed=true;observer.disconnect();dialogObserver.disconnect();lifetime.abort();mediaBinding?.abort();
    clearTimeout(toastTimer);exitOwnedFullscreen();activeMedia=null;
    dialog.classList.remove('media-preview');stage.classList.remove('media-preview-stage');indicator.remove();
  }};
}
