# 第三方元件聲明

## mpegts.js 1.8.2

來源：https://github.com/xqq/mpegts.js

包含 Bilibili／mpegts.js 上游原始版權註記的 FLV／MPEG-TS 解封裝與 MP4 重封裝程式，依 Apache License 2.0 使用。完整授權位於 `vendor/mpegts-LICENSE-Apache-2.0.txt`，封裝及改動說明位於 `vendor/BUILD-PROVENANCE.md`。本版保留原始註記，只剔除未使用的 Worker 打包器。

Notion Drive 是獨立第三方工具，不代表 Notion、Bilibili 或 Chrome 官方產品。Notion 名稱僅用於說明互通服務。本文件不替既有自有程式碼新增授權，也不將維護測試用工具誤列為擴充功能執行依賴。
