/**
 * NDRVENC1 encrypted FLV random-access adapter for mpegts.js 1.8.2.
 * New code only; does not modify the original encryption algorithm or format.
 * One logical original FLV stream may span many independently encrypted Notion volumes.
 * Each volume may be one Notion file or many SHARD_SIZE physical file blocks.
 *
 * This module NEVER persists plaintext or a keyframe index to disk.
 */
import {openEncryptedVolume} from './ndrv1-random-reader.js';

const MAX_SAFE = Number.MAX_SAFE_INTEGER;
function assertRange(a,b) {
  if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b) || a < 0 || b <= a || b > MAX_SAFE) {
    throw new Error('無效的加密影片位元組範圍');
  }
}
function joinBytes(parts,total) {
  const merged = new Uint8Array(total);
  let p=0;
  for(const chunk of parts){merged.set(chunk,p);p+=chunk.length;}
  return merged;
}
/**
 * readPhysical(volumeIndex, shardIndexOrNull, start, endExclusive, signal)
 * MUST return exactly the requested ciphertext bytes, not full-response fallback.
 */
export function createEncryptedFlvSource({volumes, vmk, readPhysical, shardSize=4*1024*1024,signal=null}) {
  if(!Array.isArray(volumes)||!volumes.length||!Number.isSafeInteger(shardSize)||shardSize<=0) throw new Error('Volume 配置無效');
  if(!(vmk instanceof Uint8Array)||vmk.length!==32) throw new Error('需要已解鎖的 VMK');
  if(typeof readPhysical!=='function') throw new Error('讀取介面不存在');
  const ordered=[...volumes].sort((a,b)=>a.volumeIndex-b.volumeIndex);
  for(let i=0;i<ordered.length;i++) if(ordered[i].volumeIndex!==i+1)throw new Error('Volume 不完整或排序錯誤');
  let closed=false, initPromise=null;
  const lifetime=new AbortController(), readers=new Set();
  const onAbort=()=>close();
  function check(signal2){if(closed||signal?.aborted||signal2?.aborted)throw new DOMException('FLV 讀取取消','AbortError');}
  async function physicalAt(pos,start,end,signal2){
    assertRange(start,end);check(signal2);
    const entry=ordered[pos];
    if(!entry.shards){
      const chunk=await readPhysical(entry.volumeIndex,null,start,end,signal2);
      check(signal2);return chunk instanceof Uint8Array?chunk:new Uint8Array(chunk);
    }
    const pieces=[];let p=start;
    while(p<end){
      check(signal2);
      const idx=Math.floor(p/shardSize), inside=p-idx*shardSize;
      if(idx>=entry.shards.length)throw new Error('密文 Shard 清單不完整');
      const size=Math.min(end-p,shardSize-inside);
      const bytes=await readPhysical(entry.volumeIndex,idx,inside,inside+size,signal2);
      const view=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);
      if(view.length!==size)throw new Error('Shard 回傳長度不符');
      pieces.push(view);p+=size;
    }
    return joinBytes(pieces,end-start);
  }
  async function initialize(){
    const info=[];let total=0;
    try {
      for(let i=0;i<ordered.length;i++){
        check();
        const r=await openEncryptedVolume({vmk,signal:lifetime.signal,
          readRange:(a,b,operationSignal)=>physicalAt(i,a,b,operationSignal || lifetime.signal)});
        readers.add(r);
        info.push({index:i,offset:total,end:total+r.plainSize,reader:r});
        check();
        total+=r.plainSize;
        if(!Number.isSafeInteger(total))throw new Error('加密影片太大，超過 JavaScript 安全整數');
      }
      if(total<13)throw new Error('影片內容為空或過短');
      return {total,info};
    } catch(error) {
      for(const entry of info){entry.reader.close();readers.delete(entry.reader);}
      throw error;
    }
  }
  async function ready(){
    check();
    if(!initPromise) initPromise=initialize().catch(error=>{initPromise=null;throw error;});
    return initPromise;
  }
  async function readRange(from,endExclusive,signal2){
    const {total,info}=await ready();check(signal2);assertRange(from,endExclusive);
    if(endExclusive>total)throw new Error('明文 Range 超過影片範圍');
    const chunks=[];let got=0;
    for(const entry of info){
      if(entry.end<=from||entry.offset>=endExclusive)continue;
      check(signal2);
      const start=Math.max(from,entry.offset)-entry.offset;
      const end=Math.min(endExclusive,entry.end)-entry.offset;
      const value=await entry.reader.decryptRange(start,end,signal2);
      check(signal2);chunks.push(value);got+=value.length;
    }
    if(got!==endExclusive-from)throw new Error('解密資料長度不符');
    return joinBytes(chunks,got);
  }
  // Each call decrypts one complete authenticated AES-GCM chunk at a time;
  // returns parts with correct global original FLV byte offsets.
  async function* readParts(from,toExclusive,signal2) {
    const {total,info}=await ready();check(signal2);
    assertRange(from,toExclusive);
    if(toExclusive>total)throw new Error('要求的位元組超出影片');
    for(const entry of info){
      if(entry.end<=from||entry.offset>=toExclusive)continue;
      const first=Math.max(0,from-entry.offset);
      const last=Math.min(entry.reader.plainSize,toExclusive-entry.offset);
      const i0=Math.floor(first/entry.reader.chunkSize);
      const i1=Math.floor((last-1)/entry.reader.chunkSize);
      for(let i=i0;i<=i1;i++){
        check(signal2);
        const decrypted=await entry.reader.decryptChunk(i,signal2);
        check(signal2);
        const base=i*entry.reader.chunkSize;
        const a=Math.max(first,base)-base;
        const b=Math.min(last,base+decrypted.length)-base;
        const selected=decrypted.subarray(a,b);
        const byteOffset=entry.offset+base+a;
        // Avoid massive DataArrival / stash buffers on videos with 8 MiB GCM chunks.
        for(let p=0;p<selected.length;p+=512*1024){
          check(signal2);
          const data=selected.slice(p,Math.min(p+512*1024,selected.length));
          yield {offset:byteOffset+p,data};
        }
      }
    }
  }
  function close(){
    if(closed)return;
    closed=true;lifetime.abort();signal?.removeEventListener('abort',onAbort);
    for(const reader of readers)reader.close();
    readers.clear();
  }
  signal?.addEventListener('abort',onAbort,{once:true});
  if(signal?.aborted)close();
  return {ready,readRange,readParts,close,get closed(){return closed;}};
}

export function encryptedFlvLoader(Source) {
  // flv.js's customLoader option expects a constructor with BaseLoader-compatible callback shape.
  return class EncryptedFlvRangeLoader {
    constructor(){
      this._status=0;this._needStash=false;this._seq=0;this._active=false;
      this._abort=null;this.onDataArrival=null;this.onComplete=null;
      this.onContentLengthKnown=null;this.onURLRedirect=null;this.onError=null;
    }
    get type(){return 'ndrv1-authenticated-range';}
    get status(){return this._status;}
    get needStashBuffer(){return this._needStash;}
    isWorking(){return this._active;}
    abort(){this._seq++;this._active=false;this._status=0;this._abort?.abort();this._abort=null;}
    destroy(){this.abort();this.onDataArrival=null;this.onComplete=null;this.onError=null;this.onContentLengthKnown=null;}
    open(_dataSource,range={from:0,to:-1}){
      this.abort();const seq=++this._seq,ac=new AbortController();this._abort=ac;
      this._active=true;this._status=1;
      void (async()=>{
        const {total}=await Source.ready();
        if(seq!==this._seq||ac.signal.aborted)return;
        this.onContentLengthKnown?.(total);
        const start=range.from??0;
        const end=range.to>=start?Math.min(total,range.to+1):total;
        if(!Number.isSafeInteger(start)||start<0||start>=end)throw new Error('FLV 快轉位置不合法');
        let received=0;this._status=2;
        for await(const {offset,data} of Source.readParts(start,end,ac.signal)){
          if(seq!==this._seq||ac.signal.aborted)return;
          received+=data.byteLength;
          this.onDataArrival?.(data.buffer,offset,received);
          // Yield to the browser so flv.js can abort during a seek.
          await new Promise(resolve=>setTimeout(resolve,0));
        }
        if(seq!==this._seq||ac.signal.aborted)return;
        this._active=false;this._status=4;this.onComplete?.(start,end-1);
      })().catch(err=>{
        if(seq!==this._seq||ac.signal.aborted)return;
        this._active=false;this._status=3;
        this.onError?.('Exception',{code:-1,msg:err?.message||String(err)});
      });
    }
  };
}
