import {
  createEncryptedDescriptor,
  encryptedParts,
  decryptToBlob,
  decryptToWritable,
  encryptMetadata,
  decryptMetadata,
  createVmk,
  encodeVmk,
  decodeVmk,
  wrapVmk,
  unwrapVmk,
  encryptSyncProfile, decryptSyncProfile, validSyncProfile,
  sealLocalVmk, openLocalVmk,
} from "./crypto.js";
import { Zip64StoreWriter } from "./zip-store.js";
import { createEncryptedFlvSource, encryptedFlvLoader } from "./encrypted-flv-range.js";
import { EncryptedMseVideo, detectMseVideoType, detectWebmMseType } from "./encrypted-mse-video.js";
import { ProgressiveMp4Player } from "./mp4-progressive.js";
import { EncryptedMp3Player } from "./encrypted-mp3.js";
import { ProgressiveFlacPlayer } from "./flac-progressive.js";
import { readExactHttpRange, createRefreshingRangeReader } from "./range-http.js";
import { createMemoryMediaSource } from "./memory-media-source.js";
import { installPreviewMediaEnhancements } from "./preview-media-enhancements.js";
import { createWebStorageAreas } from "./web-storage.js";

const WEB_MODE = globalThis.__NDRIVE_WEB_MODE__ === true;
const API = String(
  globalThis.__NDRIVE_API_BASE__ || (WEB_MODE ? "" : "https://api.notion.com/v1"),
).replace(/\/$/, "");
function remoteFetchUrl(url) {
  return globalThis.__NDRIVE_FETCH_URL__?.(url) || url;
}
const API_VERSION = "2026-03-11";
const MiB = 1024 * 1024;
const PART_SIZE = 20 * MiB;
const DIRECT_LIMIT = 20 * MiB;
const VOLUME_PARTS = 240;
const VOLUME_SIZE = PART_SIZE * VOLUME_PARTS;
// NDRVENC1 的 header 與每個 AES-GCM chunk 都有少量 overhead。
// 保留 64 KiB，確保每個完整 Volume 一定不超過 240 Parts。
const VOLUME_SOURCE_SIZE = VOLUME_SIZE - 64 * 1024;
const UPLOAD_WORKER_COUNT = 4;
const DOWNLOAD_WORKER_COUNT = 4;
const DOWNLOAD_STAGING_DIRECTORY = "notion-drive-download-staging";
const DOWNLOAD_STAGING_MAX_AGE = 24 * 60 * 60 * 1000;
const API_REQUEST_INTERVAL = Math.ceil(1000 / 3);
const VAULT_CONFIG_PREFIX = "NDVC1.";
const SHARD_SIZE = 4 * MiB;
const SHARD_ATTACH_BATCH = 20;
const SYNC_PREFIX = "ndriveSync:";
const PROFILE_PREFIX = "ndriveProfile:";
const PROFILE_IDS = "ndriveProfileIds";
const ACTIVE_PROFILE = "ndriveActiveProfile";
const profileId = new URL(location.href).searchParams.get("profile");
function profileKey(suffix, id = state.profileId) { return `${PROFILE_PREFIX}${id}:${suffix}`; }
function activeOperations() {
  return state.busy > 0 || hasActiveTransfers() || activeUploadWorkers > 0 || activeDownloadWorkers > 0;
}
function busyOperation(fn) {
  return async function(...args) {
    if (state.leaving) throw new DOMException(t("cancelled"), "AbortError");
    const outermost = state.busy++ === 0;
    if (outermost) {
      stopBackgroundIndex();
      await Promise.allSettled([...indexScanPromises.values()]);
    }
    try {
      return await fn(...args);
    } finally {
      state.busy--;
      if (outermost && !state.busy && !state.leaving) startBackgroundIndex();
    }
  };
}
const DATA_MODEL = "page-mvp-2";
// Explicit opt-in only; encrypted file contents remain the default.
const RAW_VIDEO_FORMAT = "ndrive-native-video-v1";

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const UI_LOCALE =
  globalThis.__NDRIVE_I18N__?.locale ||
  globalThis.chrome?.i18n?.getMessage?.("localeCode") ||
  globalThis.chrome?.i18n?.getUILanguage?.()?.replaceAll("_", "-") ||
  "en";
function t(key, substitutions) {
  const message = globalThis.__NDRIVE_I18N__?.getMessage(key, substitutions) ||
    globalThis.chrome?.i18n?.getMessage?.(key, substitutions);
  return message || globalThis.chrome?.i18n?.getMessage?.("extensionName") || "Notion Drive";
}
function parseNotionPageId(value = "") {
  const input = String(value).trim(),
    uuid = input.match(
      /([0-9a-f]{8})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{12})/i,
    );
  if (uuid) return uuid.slice(1).join("").toLowerCase();
  const rawCompact = input.replaceAll("-", "");
  if (/^[0-9a-f]{32}$/i.test(rawCompact)) return rawCompact.toLowerCase();
  try {
    const url = new URL(input),
      segment = decodeURIComponent(
        url.pathname.split("/").filter(Boolean).at(-1) || "",
      ),
      compactSegment = segment.replaceAll("-", ""),
      match = compactSegment.match(/([0-9a-f]{32})$/i);
    return match ? match[1].toLowerCase() : "";
  } catch {
    const match = input.match(/([0-9a-f]{32})(?!.*[0-9a-f])/i);
    return match ? match[1].toLowerCase() : "";
  }
}
function rootStateKey(rootId = state.settings?.rootPageId) {
  return parseNotionPageId(rootId);
}

function localizeDocument(root = document) {
  root.querySelectorAll("[data-i18n]").forEach((node) => {
    node.textContent = t(node.dataset.i18n);
  });
  root.querySelectorAll("[data-i18n-placeholder]").forEach((node) => {
    node.placeholder = t(node.dataset.i18nPlaceholder);
  });
  root.querySelectorAll("[data-i18n-title]").forEach((node) => {
    node.title = t(node.dataset.i18nTitle);
  });
  root.querySelectorAll("[data-i18n-aria-label]").forEach((node) => {
    node.setAttribute("aria-label", t(node.dataset.i18nAriaLabel));
  });
  document.documentElement.lang = UI_LOCALE.toLowerCase().startsWith("zh")
    ? "zh-Hant"
    : "en";
  document.title = t("appTitle");
}
const hasChrome = !WEB_MODE && typeof chrome !== "undefined" && Boolean(chrome.storage?.local);
const webStorage = WEB_MODE ? createWebStorageAreas() : null;
const droppedPaths = new WeakMap();
const localStore = {
  async get(keys) {
    return hasChrome
      ? chrome.storage.local.get(keys)
      : webStorage.local.get(keys);
  },
  async set(values) {
    if (hasChrome) return chrome.storage.local.set(values);
    return webStorage.local.set(values);
  },
  async remove(keys) {
    if (hasChrome) return chrome.storage.local.remove(keys);
    return webStorage.local.remove(keys);
  },
};
const sessionStore = {
  async get(keys) {
    return hasChrome
      ? chrome.storage.session.get(keys)
      : webStorage.session.get(keys);
  },
  async set(values) {
    if (hasChrome) return chrome.storage.session.set(values);
    return webStorage.session.set(values);
  },
  async remove(keys) {
    if (hasChrome) return chrome.storage.session.remove(keys);
    return webStorage.session.remove(keys);
  },
};

const state = {
  profileId: null, profiles: [], busy: 0, leaving: false, syncPacket: null,
  workspaceUpload: null,
  settings: null,
  root: null,
  currentPageId: null,
  path: [],
  items: [],
  query: "",
  layout: "grid",
  view: "files",
  uploadTasks: [],
  preview: null,
  previewController: null,
  previewDialogController: null,
  previewObjectUrl: null,
  mediaPreviewPlayer: null,
  previewMemorySource: null,
  previewMetaBase: "",
  previewNavigationId: null,
  meta: {},
  trash: [],
  indexReady: false,
  contextItem: null,
  renameItem: null,
  pendingEncryptedState: null,
  settingsUnlocked: false,
  selectedIds: new Set(),
  cutIds: new Set(),
  selectionMode: false,
  selectionAnchorId: null,
  pendingTrashItems: [],
  trashRunning: false,
  moving: false,
  indexedFolders: new Set(),
  backgroundIndexing: false,
  indexRun: 0,
  indexScanned: 0,
  vaultVerified: false,
  vmk: null,
  vaultConfigBlockId: null,
};
const indexScanPromises = new Map();
const uploadQueue = [];
const uploadNameReservations = new Set();
const downloadQueue = [];
let activeUploadWorkers = 0;
let activeDownloadWorkers = 0;
let apiGateTail = Promise.resolve();
let nextApiRequestAt = 0;
let apiPausedUntil = 0;
let persistTail = Promise.resolve();
let marqueeState = null;
const els = {
  grid: $("#fileGrid"),
  empty: $("#emptyState"),
  emptyTitle: $("#emptyTitle"),
  emptyText: $("#emptyText"),
  loading: $("#loadingState"),
  notice: $("#notice"),
  breadcrumbs: $("#breadcrumbs"),
  title: $("#viewTitle"),
  subtitle: $("#viewSubtitle"),
  search: $("#searchInput"),
  searchBox: $("#searchBox"),
  settingsDialog: $("#settingsDialog"),
  settingsStatus: $("#settingsStatus"),
  connectionCard: $("#connectionCard"),
  connectionTitle: $("#connectionTitle"),
  connectionText: $("#connectionText"),
  uploadPanel: $("#uploadPanel"),
  uploadList: $("#uploadList"),
  uploadSummary: $("#uploadSummary"),
  totalProgressText: $("#totalProgressText"),
  previewDialog: $("#previewDialog"),
  previewStage: $("#previewStage"),
  previewName: $("#previewName"),
  previewMeta: $("#previewMeta"),
  trashDialog: $("#trashDialog"),
  trashConfirmText: $("#trashConfirmText"),
  cancelTrashButton: $("#cancelTrashButton"),
  confirmTrashButton: $("#confirmTrashButton"),
  toastStack: $("#toastStack"),
  clearView: $("#clearViewButton"),
  newFolder: $("#newFolderButton"),
  refresh: $("#refreshButton"),
};

// Vault-local video frame previews. Never stored in IndexedDB, OPFS or Notion.
// The original file-icon DOM nodes are restored on eviction, locking or pagehide.
const previewThumbnails = new Map();
const thumbnailOriginalNodes = new WeakMap();
const PREVIEW_THUMBNAIL_LIMIT = 48;
function restoreThumbnailIcon(iconNode) {
  const children = thumbnailOriginalNodes.get(iconNode);
  if (children) { iconNode.replaceChildren(...children); thumbnailOriginalNodes.delete(iconNode); }
}
function restoreThumbnailForItem(itemId) {
  for (const card of els.grid.querySelectorAll('.file-card[data-item-id]')) {
    if (card.dataset.itemId !== itemId) continue;
    const iconNode = card.querySelector('.file-icon');
    if (iconNode) restoreThumbnailIcon(iconNode);
  }
}
function showPreviewThumbnail(card, itemId) {
  const value = state.vaultVerified && state.vmk ? previewThumbnails.get(itemId) : null;
  if (!value) return;
  const item = state.meta[itemId] || (state.preview?.id === itemId ? state.preview : null);
  // Page identity survives Safe Save. Invalidate on payload changes, not rename/move.
  if (!item || item.size !== value.size ||
      (item.contentId && String(item.contentId).toUpperCase() !== value.contentId) ||
      (item.rawVideoBlockId && item.rawVideoBlockId !== value.rawVideoBlockId)) {
    previewThumbnails.delete(itemId);
    restoreThumbnailForItem(itemId);
    return;
  }
  const iconNode = card.querySelector('.file-icon');
  if (!iconNode) return;
  if (!thumbnailOriginalNodes.has(iconNode))
    thumbnailOriginalNodes.set(iconNode, [...iconNode.childNodes]);
  const image = document.createElement('img');
  image.className = 'ndrive-thumbnail'; image.alt = '影片縮圖';
  image.src = value.dataUrl;
  Object.assign(image.style,{width:'100%',height:'100%',objectFit:'cover',borderRadius:'inherit'});
  iconNode.replaceChildren(image);
}
function recordPreviewThumbnail(itemId, dataUrl) {
  if (!state.vaultVerified || !state.vmk || typeof dataUrl !== 'string' ||
      !dataUrl.startsWith('data:image/') || dataUrl.length > 200000) return;
  const item = state.preview;
  if (item?.id !== itemId) return;
  const indexed = state.meta[itemId];
  if (indexed?.contentId && item.contentId &&
      String(indexed.contentId).toUpperCase() !== String(item.contentId).toUpperCase()) return;
  previewThumbnails.delete(itemId);
  previewThumbnails.set(itemId, {dataUrl,size:item.size,
    contentId:String(item.contentId || indexed?.contentId || '').toUpperCase(),
    rawVideoBlockId:item.rawVideoBlockId || ''});
  while (previewThumbnails.size > PREVIEW_THUMBNAIL_LIMIT) {
    const oldest = previewThumbnails.keys().next().value;
    previewThumbnails.delete(oldest);
    restoreThumbnailForItem(oldest);
  }
  for (const card of els.grid.querySelectorAll('.file-card[data-item-id]'))
    if (card.dataset.itemId === itemId) showPreviewThumbnail(card, itemId);
}
function clearPreviewThumbnails() {
  previewThumbnails.clear();
  for (const image of els.grid.querySelectorAll('.ndrive-thumbnail')) {
    const iconNode = image.closest('.file-icon');
    if (iconNode) restoreThumbnailIcon(iconNode);
  }
}
const previewMediaEnhancements = installPreviewMediaEnhancements({
  stage:els.previewStage,dialog:els.previewDialog,
  getItemId:()=>state.vaultVerified ? state.preview?.id : null,
  getSessionId:()=>state.previewController,
  onThumbnail:recordPreviewThumbnail,
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function throwIfAborted(signal) {
  if (signal?.aborted) throw new DOMException(t("cancelled"), "AbortError");
}
function abortableSleep(ms, signal) {
  if (!signal) return sleep(ms);
  throwIfAborted(signal);
  return new Promise((resolve, reject) => {
    const timer = setTimeout(done, ms);
    function done() {
      signal.removeEventListener("abort", cancelled);
      resolve();
    }
    function cancelled() {
      clearTimeout(timer);
      signal.removeEventListener("abort", cancelled);
      reject(new DOMException(t("cancelled"), "AbortError"));
    }
    signal.addEventListener("abort", cancelled, { once: true });
  });
}
function parseRetryAfter(value) {
  if (!value) return 0;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(0, seconds * 1000);
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) ? Math.max(0, timestamp - Date.now()) : 0;
}
function pauseApiGate(ms) {
  apiPausedUntil = Math.max(apiPausedUntil, Date.now() + ms);
}
async function enterApiGate(signal) {
  let release;
  const previous = apiGateTail;
  apiGateTail = new Promise((resolve) => {
    release = resolve;
  });
  await previous;
  try {
    throwIfAborted(signal);
    while (true) {
      const waitUntil = Math.max(nextApiRequestAt, apiPausedUntil),
        waitMs = waitUntil - Date.now();
      if (waitMs <= 0) break;
      await abortableSleep(waitMs, signal);
    }
    nextApiRequestAt = Date.now() + API_REQUEST_INTERVAL;
  } finally {
    release();
  }
}
function vaultAccessError() {
  const error = new Error(t("passwordOrDataDamaged"));
  error.code = "VAULT_VERIFICATION_FAILED";
  return error;
}
const uuid = () => crypto.randomUUID();
function fileSystemSafeName(value = "", fallback = t("unnamed")) {
  let name = value
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_")
    .replace(/[. ]+$/g, "")
    .trim();
  if (!name) name = fallback;
  if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i.test(name))
    name = `_${name}`;
  return name.slice(0, 180);
}
function ext(name = "") {
  const p = name.split(".");
  return p.length > 1 ? p.pop().toLowerCase() : "";
}
function formatBytes(bytes = 0) {
  if (!Number.isFinite(bytes) || bytes < 0) return t("unknownSize");
  if (bytes === 0) return "0 B";
  const u = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), 4);
  return `${(bytes / 1024 ** i).toFixed(i < 2 ? 0 : 1)} ${u[i]}`;
}
function formatDate(value) {
  return value ? new Date(value).toLocaleString(UI_LOCALE) : t("unknownDate");
}
function compactFileType(item) {
  const extension = ext(item.name);
  if (extension) return extension.toUpperCase();
  if (item.mime?.startsWith("video/")) return t("video");
  if (item.mime?.startsWith("image/")) return t("image");
  if (item.mime?.startsWith("audio/")) return t("audio");
  return t("file");
}
function pageTitleRich(value) {
  if (typeof value !== "string" || !value || value.length > 1900)
    throw new Error(t("encryptedPageNameTooLong"));
  return [{ type: "text", text: { content: value } }];
}
const MIME_BY_EXT = {
  aac: "audio/aac",
  adts: "audio/aac",
  mid: "audio/midi",
  midi: "audio/midi",
  mp3: "audio/mpeg",
  mpga: "audio/mpeg",
  m4a: "audio/mp4",
  m4b: "audio/mp4",
  oga: "audio/ogg",
  ogg: "audio/ogg",
  opus: "audio/ogg",
  wav: "audio/wav",
  wma: "audio/x-ms-wma",
  weba: "audio/webm",
  flac: "audio/x-flac",
  pdf: "application/pdf",
  txt: "text/plain",
  csv: "text/csv",
  json: "application/json",
  doc: "application/msword",
  dot: "application/msword",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  dotx: "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
  xls: "application/vnd.ms-excel",
  xlt: "application/vnd.ms-excel",
  xla: "application/vnd.ms-excel",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  xltx: "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
  ppt: "application/vnd.ms-powerpoint",
  pot: "application/vnd.ms-powerpoint",
  pps: "application/vnd.ms-powerpoint",
  ppa: "application/vnd.ms-powerpoint",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  potx: "application/vnd.openxmlformats-officedocument.presentationml.template",
  rtf: "application/rtf",
  md: "text/markdown",
  markdown: "text/markdown",
  html: "text/html",
  htm: "text/html",
  epub: "application/epub+zip",
  xml: "application/xml",
  css: "text/css",
  odt: "application/vnd.oasis.opendocument.text",
  ods: "application/vnd.oasis.opendocument.spreadsheet",
  odp: "application/vnd.oasis.opendocument.presentation",
  ics: "text/calendar",
  yaml: "text/yaml",
  yml: "text/yaml",
  tsv: "text/tab-separated-values",
  zip: "application/zip",
  gz: "application/gzip",
  gzip: "application/gzip",
  tar: "application/x-tar",
  "7z": "application/x-7z-compressed",
  bz2: "application/x-bzip2",
  rar: "application/vnd.rar",
  gif: "image/gif",
  heic: "image/heic",
  jpeg: "image/jpeg",
  jpg: "image/jpeg",
  png: "image/png",
  svg: "image/svg+xml",
  tif: "image/tiff",
  tiff: "image/tiff",
  webp: "image/webp",
  ico: "image/vnd.microsoft.icon",
  bmp: "image/bmp",
  avif: "image/avif",
  apng: "image/apng",
  amv: "video/x-amv",
  asf: "video/x-ms-asf",
  wmv: "video/x-ms-wmv",
  avi: "video/x-msvideo",
  f4v: "video/x-f4v",
  flv: "video/x-flv",
  gifv: "video/mp4",
  m4v: "video/mp4",
  mp4: "video/mp4",
  mkv: "video/x-matroska",
  webm: "video/webm",
  mov: "video/quicktime",
  qt: "video/quicktime",
  mpeg: "video/mpeg",
  ogv: "video/ogg",
  "3gp": "video/3gpp",
  "3g2": "video/3gpp2",
};
function mimeFromName(name) {
  return MIME_BY_EXT[ext(name)] || "application/octet-stream";
}
function relativeFilePath(file) {
  return droppedPaths.get(file) || file.webkitRelativePath || file.name;
}
function entryFile(entry) {
  return new Promise((resolve, reject) => entry.file(resolve, reject));
}
async function readDirectoryEntries(reader) {
  const entries = [];
  while (true) {
    const batch = await new Promise((resolve, reject) =>
      reader.readEntries(resolve, reject),
    );
    if (!batch.length) break;
    entries.push(...batch);
  }
  return entries;
}
async function walkDroppedEntry(entry, prefix, files, directories) {
  if (entry.isFile) {
    const file = await entryFile(entry),
      path = `${prefix}${entry.name}`;
    droppedPaths.set(file, path);
    files.push(file);
    return;
  }
  if (entry.isDirectory) {
    const folderPath = `${prefix}${entry.name}`;
    directories.add(folderPath);
    const children = await readDirectoryEntries(entry.createReader()),
      nextPrefix = `${folderPath}/`;
    for (const child of children)
      await walkDroppedEntry(child, nextPrefix, files, directories);
  }
}
async function collectDroppedItems(dataTransfer) {
  const files = [],
    directories = new Set(),
    entries = [...dataTransfer.items]
      .map((item) => item.webkitGetAsEntry?.())
      .filter(Boolean);
  if (entries.length) {
    for (const entry of entries)
      await walkDroppedEntry(entry, "", files, directories);
  } else {
    for (const file of dataTransfer.files) {
      droppedPaths.set(file, file.name);
      files.push(file);
    }
  }
  return { files, directories: [...directories] };
}
async function handleDrop(dataTransfer) {
  const overlay = $("#dropOverlay"),
    label = overlay.querySelector("strong");
  label.textContent = t("organizingDrop");
  try {
    const { files, directories } = await collectDroppedItems(dataTransfer);
    if (!files.length && !directories.length) {
      toast(t("noUploadableItems"), "error");
      return;
    }
    label.textContent = t("dropToUpload");
    overlay.classList.add("hidden");
    const hasFolders =
      directories.length > 0 ||
      files.some((file) => relativeFilePath(file).includes("/"));
    if (hasFolders) await uploadFolder(files, directories);
    else await uploadLoose(files);
  } catch (error) {
    toast(t("dropFailed", [String(error.message)]), "error");
  } finally {
    label.textContent = t("dropToUpload");
    overlay.classList.add("hidden");
  }
}
function blockPayload(block) {
  return block?.[block.type] || {};
}
function hostedUrl(payload) {
  return payload?.file?.url || payload?.external?.url || null;
}
function toast(message, type = "") {
  const n = document.createElement("div");
  n.className = `toast ${type}`;
  n.textContent = redactSecrets(message);
  els.toastStack.append(n);
  setTimeout(() => n.remove(), 4300);
}
function compactStatusToast(message) {
  const node = document.createElement("div");
  node.className = "toast operation-toast";
  node.setAttribute("role", "status");
  node.setAttribute("aria-live", "polite");
  node.textContent = message;
  els.toastStack.append(node);
  return {
    update(next, type = "") {
      node.className = `toast operation-toast ${type}`;
      node.textContent = next;
    },
    finish(next, type = "success", delay = 2200) {
      this.update(next, type);
      setTimeout(() => node.remove(), delay);
    },
  };
}
function setLoading(v) {
  els.loading.classList.toggle("hidden", !v);
  if (v) {
    els.grid.classList.add("hidden");
    els.empty.classList.add("hidden");
  }
}
function redactSecrets(message, extraSecrets = []) {
  let text = String(message ?? "");
  text = text.replace(/Bearer\s+[^\s,;]+/gi, "Bearer [redacted]");
  text = text.replace(/\b(?:secret|ntn)_[A-Za-z0-9_-]{8,}\b/g, "[redacted]");
  const secrets = new Set([
    state.settings?.notionToken,
    ...state.profiles.map((profile) => profile?.notionToken),
    ...extraSecrets,
  ].filter((value) => typeof value === "string" && value.length >= 6));
  for (const secret of [...secrets].sort((a, b) => b.length - a.length))
    text = text.split(secret).join("[redacted]");
  return text;
}
function safeErrorMessage(error, extraSecrets = []) {
  return redactSecrets(error?.message || String(error || ""), extraSecrets);
}
function showNotice(message) {
  const safe = redactSecrets(message);
  els.notice.textContent = safe;
  els.notice.classList.toggle("hidden", !safe);
}
function persistLocal() {
  if (!state.vmk || !state.profileId) return persistTail;
  // Capture NOW, not when the preceding write finishes.
  const key = profileKey("state"), vmk = state.vmk.slice();
  const snapshot = structuredClone({
    dataModel: DATA_MODEL, rootPageId: rootStateKey(),
    meta: state.meta, trash: state.trash.slice(0, 2000),
    indexReady: state.indexReady, indexedFolders: [...state.indexedFolders],
  });
  persistTail = persistTail.catch(() => {}).then(async () => {
    try {
      const encrypted = await encryptMetadata(snapshot, vmk, "local-state");
      await localStore.set({ [key]: encrypted });
    } finally { vmk.fill(0); }
  });
  return persistTail;
}

// IndexedDB stores a non-exportable CryptoKey; storage.local holds only a
// wrapped VMK. This is browser-local protection, not an OS/hardware keystore.
async function deviceKey(binding, action = "get", value) {
  const db = await new Promise((resolve, reject) => {
    const request = indexedDB.open("notion-drive-device-keys", 1);
    request.onupgradeneeded = () => request.result.createObjectStore("keys");
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction("keys", action === "get" ? "readonly" : "readwrite"),
        store = tx.objectStore("keys");
      let request = null;
      if (action === "deletePrefix") {
        request = store.openCursor();
        request.onsuccess = () => {
          const cursor = request.result;
          if (!cursor) return;
          if (String(cursor.key).startsWith(binding)) cursor.delete();
          cursor.continue();
        };
      } else request = action === "put" ? store.put(value, binding) : store[action](binding);
      tx.oncomplete = () => resolve(request?.result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error(t("rememberVmkFailed")));
    });
  } finally { db.close(); }
}
async function forgetLocalVmk(rootId, id = state.profileId) {
  // Disable the auto-unlock path first. Device-key cleanup is then best-effort
  // for every binding that belongs to this Profile only.
  await localStore.remove([profileKey("remembered", id)]);
  await deviceKey(`${id}:`, "deletePrefix");
}
async function rememberUnlockedVmk(rootId, vmk, rememberVmk) {
  const normalizedRoot = rootStateKey(rootId), binding = `${state.profileId}:${normalizedRoot}`;
  if (rememberVmk) {
    let key = await deviceKey(binding);
    if (!key) {
      key = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
      await deviceKey(binding, "put", key);
    }
    const wrapped = await sealLocalVmk(vmk, key, binding);
    await localStore.set({ [profileKey("remembered")]: { rootPageId: normalizedRoot, ...wrapped } });
  } else await forgetLocalVmk(rootId);
  await sessionStore.set({ [profileKey("vmk")]: { rootPageId: normalizedRoot, value: encodeVmk(vmk) } });
}
function applySavedState(saved) {
  if (saved?.dataModel !== DATA_MODEL || (saved.rootPageId && saved.rootPageId !== rootStateKey())) return;
  state.meta = saved.meta || {};
  state.trash = saved.trash || [];
  state.indexReady = Boolean(saved.indexReady);
  state.indexedFolders = new Set(saved.indexedFolders || []);
}
async function publishProfile(packet) {
  // Rebuild the allowlist even if local data has extra properties.
  const { v, profileId, name, salt, iv, cipher } = packet;
  if (!validSyncProfile(packet)) throw new Error(t("invalidSyncProfile"));
  if (!hasChrome || !chrome.storage.sync) throw new Error(t("syncUnavailable"));
  await chrome.storage.sync.set({ [`${SYNC_PREFIX}${profileId}`]: { v, profileId, name, salt, iv, cipher } });
  await localStore.remove([profileKey("pendingSync", profileId)]);
}
async function loadLocal() {
  if (hasChrome) {
    for (const area of [chrome.storage.local, chrome.storage.session, chrome.storage.sync])
      await area.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
  }
  const data = await localStore.get([PROFILE_IDS, ACTIVE_PROFILE]);
  let ids = Array.isArray(data[PROFILE_IDS]) ? data[PROFILE_IDS] : [];
  if (!ids.length) {
    const id = uuid();
    ids = [id];
    await localStore.set({
      [PROFILE_IDS]: ids,
      [ACTIVE_PROFILE]: id,
      [profileKey("settings", id)]: {
        profileId: id, name: "API A", notionToken: "", rootPageId: "", rememberVmk: true,
      },
    });
  }
  let remote = {};
  try { remote = hasChrome ? await chrome.storage.sync.get(null) : {}; }
  catch (error) { showNotice(t("syncPending", [error.message])); }
  for (const [key, packet] of Object.entries(remote)) {
    if (key !== `${SYNC_PREFIX}${packet?.profileId}` || !validSyncProfile(packet)) continue;
    if (!ids.includes(packet.profileId)) {
      ids.push(packet.profileId);
      await localStore.set({ [profileKey("settings", packet.profileId)]: {
        profileId: packet.profileId, name: packet.name, notionToken: "", rootPageId: "",
        rememberVmk: false, syncPacket: packet,
      } });
    }
  }
  await localStore.set({ [PROFILE_IDS]: ids });
  const settingKeys = ids.map(id => profileKey("settings", id));
  const saved = await localStore.get(settingKeys);
  const preferredProfileId = ids.includes(profileId)
    ? profileId
    : ids.includes(data[ACTIVE_PROFILE]) ? data[ACTIVE_PROFILE] : ids[0];
  const stale = {};
  for (const id of ids) {
    const key = profileKey("settings", id), settings = saved[key];
    if (!settings) continue;
    if (settings.rememberVmk === false && settings.rememberedCredentials) {
      const next = { ...settings, rememberedCredentials: null, notionToken: "" };
      stale[key] = next;
      saved[key] = next;
    }
  }
  if (Object.keys(stale).length) await localStore.set(stale);
  state.profiles = ids.map(id => saved[profileKey("settings", id)]).filter(Boolean);
  state.profileId = preferredProfileId;
  state.settings = { ...saved[profileKey("settings")] };
  const pending = (await localStore.get([profileKey("pendingSync")]))[profileKey("pendingSync")];
  const packet = remote[`${SYNC_PREFIX}${state.profileId}`];
  if (pending) {
    try { await publishProfile(pending); } catch (error) { showNotice(t("syncPending", [error.message])); }
  } else if (packet && validSyncProfile(packet) && ["v", "profileId", "name", "salt", "iv", "cipher"].some(field => packet[field] !== state.settings.syncPacket?.[field])) {
    // Keep current local credentials until the new packet is authenticated.
    // A remote root change must never pair old VMK/cache with the new root.
    state.syncPacket = packet;
  }
  const local = await localStore.get([profileKey("state"), profileKey("remembered")]);
  const session = await sessionStore.get([profileKey("token"), profileKey("vmk")]);
  state.settings.notionToken ||= session[profileKey("token")] || "";
  state.pendingEncryptedState = local[profileKey("state")] || null;
  let remembered = local[profileKey("remembered")];
  const rememberComplete = Boolean(state.settings.rememberVmk && rootStateKey() &&
    remembered?.rootPageId === rootStateKey() && state.settings.rememberedCredentials);
  if (state.settings.rememberVmk === false) {
    // Retry orphan Device Key cleanup on every startup while Remember is OFF.
    await forgetLocalVmk(remembered?.rootPageId || state.settings.rootPageId).catch(() => {});
    remembered = null;
  } else if ((rootStateKey() && !rememberComplete) ||
      (remembered && remembered.rootPageId !== rootStateKey())) {
    const token = state.settings.notionToken;
    state.settings = { ...state.settings, notionToken: token, rememberVmk: false, rememberedCredentials: null };
    await localStore.set({ [profileKey("settings")]: { ...state.settings, notionToken: "" } });
    await forgetLocalVmk(remembered?.rootPageId || state.settings.rootPageId).catch(() => {});
    remembered = null;
  }
  if (!state.syncPacket) {
    const record = session[profileKey("vmk")];
    try {
      if (record?.rootPageId === rootStateKey() && rootStateKey()) state.vmk = decodeVmk(record.value);
      else if (state.settings.rememberVmk && remembered?.rootPageId === rootStateKey() && rootStateKey()) {
        const binding = `${state.profileId}:${rootStateKey()}`, key = await deviceKey(binding);
        if (!key) throw vaultAccessError();
        state.vmk = await openLocalVmk(remembered, key, binding);
        await sessionStore.set({ [profileKey("vmk")]: { rootPageId: rootStateKey(), value: encodeVmk(state.vmk) } });
      }
    } catch {
      state.vmk = null;
      await sessionStore.remove([profileKey("vmk")]);
      state.settings = { ...state.settings, rememberVmk: false, rememberedCredentials: null };
      await localStore.set({ [profileKey("settings")]: { ...state.settings, notionToken: "" } }).catch(() => {});
      await forgetLocalVmk(state.settings.rootPageId).catch(() => {});
      showNotice(t("rememberVmkFailed"));
    }
  }
  if (state.vmk && state.settings.rememberedCredentials) {
    try {
      const credentials = await decryptMetadata(state.settings.rememberedCredentials, state.vmk, `profile-credentials:${state.profileId}:${rootStateKey()}`);
      if (!credentials.notionToken || credentials.rootPageId && rootStateKey(credentials.rootPageId) !== rootStateKey()) throw vaultAccessError();
      state.settings.notionToken = credentials.notionToken;
      await sessionStore.set({ [profileKey("token")]: credentials.notionToken });
    } catch {
      state.vmk = null;
      state.settings = { ...state.settings, rememberVmk: false, rememberedCredentials: null };
      await Promise.allSettled([
        sessionStore.remove([profileKey("vmk")]),
        localStore.set({ [profileKey("settings")]: { ...state.settings, notionToken: "" } }),
        forgetLocalVmk(state.settings.rootPageId),
      ]);
      showNotice(t("rememberVmkFailed"));
    }
  }
  if (state.vmk && state.pendingEncryptedState) {
    try { applySavedState(await decryptMetadata(state.pendingEncryptedState, state.vmk, "local-state")); }
    catch { showNotice(t("cacheRebuildNeeded")); }
    state.pendingEncryptedState = null;
  }
  if (state.settings?.provisional) {
    const url = new URL(location.href), explicitSetup = url.searchParams.get("setup") === "1";
    if (!explicitSetup) {
      await rollbackProvisionalProfile();
      return;
    }
    url.searchParams.delete("setup");
    globalThis.history?.replaceState?.(null, "", url.href);
  }
  renderProfiles();
}
function renderProfiles() {
  const list = $("#profileList");
  list.replaceChildren();
  for (const profile of state.profiles) {
    const button = document.createElement("button");
    button.className = `profile-item${profile.profileId === state.profileId ? " active" : ""}`;
    button.textContent = profile.name;
    button.onclick = () => switchProfile(profile.profileId).catch(error => toast(error.message, "error"));
    list.append(button);
  }
}
async function switchProfile(id) {
  if (id === state.profileId || state.leaving) return;
  if (activeOperations()) { toast(t("profileBusy"), "error"); return; }
  if (state.settings?.provisional) {
    if (id) await rollbackProvisionalProfile(id);
    return;
  }
  state.leaving = true;
  stopBackgroundIndex();
  state.previewController?.abort();
  try {
    await persistLocal();
    let setup = false;
    if (!id) {
      id = uuid(); setup = true;
      const data = await localStore.get([PROFILE_IDS]), ids = data[PROFILE_IDS] || [];
      await localStore.set({ [PROFILE_IDS]: [...ids, id], [profileKey("settings", id)]: {
        profileId: id, name: `API ${ids.length + 1}`, notionToken: "", rootPageId: "", rememberVmk: true,
        provisional: true, returnProfileId: state.profileId,
      } });
    }
    await localStore.set({ [ACTIVE_PROFILE]: id });
    // Destroy the entire document: no old promises, DOM, selection, queue or
    // object URL can run in the new Profile. Existing state never swaps in place.
    location.replace(`${location.pathname}?profile=${encodeURIComponent(id)}${setup ? "&setup=1" : ""}`);
  } catch (error) { state.leaving = false; throw error; }
}

async function removeProfileStorage(id, rootId = "", { removeSync = true } = {}) {
  // Remove Sync first so an offline/quota failure cannot silently leave a
  // remote Profile after its local recovery data has already been erased.
  if (removeSync && hasChrome && chrome.storage.sync) await chrome.storage.sync.remove(`${SYNC_PREFIX}${id}`);
  try { await forgetLocalVmk(rootId, id); }
  catch (error) { console.warn(safeErrorMessage(error)); }
  await Promise.all([
    localStore.remove([profileKey("settings", id), profileKey("state", id), profileKey("pendingSync", id)]),
    sessionStore.remove([profileKey("token", id), profileKey("vmk", id)]),
  ]);
  if (navigator.storage?.getDirectory) {
    try {
      const directory = await navigator.storage.getDirectory();
      await directory.removeEntry(`${DOWNLOAD_STAGING_DIRECTORY}-${id}`, { recursive: true });
    } catch (error) {
      if (error.name !== "NotFoundError") console.warn(safeErrorMessage(error));
    }
  }
}
async function rollbackProvisionalProfile(targetId = "") {
  if (!state.settings?.provisional || state.leaving || activeOperations()) return false;
  const id = state.profileId, returnId = state.settings.returnProfileId;
  const data = await localStore.get([PROFILE_IDS]);
  const ids = (data[PROFILE_IDS] || []).filter(candidate => candidate !== id);
  await removeProfileStorage(id, state.settings.rootPageId, { removeSync: false });
  const next = ids.includes(targetId) ? targetId : ids.includes(returnId) ? returnId : ids[0];
  if (next) {
    await localStore.set({ [PROFILE_IDS]: ids, [ACTIVE_PROFILE]: next });
    state.leaving = true;
    location.replace(`${location.pathname}?profile=${encodeURIComponent(next)}`);
  }
  return true;
}
async function deleteCurrentProfile() {
  if (!state.profileId || state.leaving) return;
  if (activeOperations()) { toast(t("profileBusy"), "error"); return; }
  if (!confirm(t("deleteProfileConfirm", [state.settings?.name || "API"]))) return;
  state.leaving = true;
  stopBackgroundIndex();
  state.previewController?.abort();
  try {
    await persistTail.catch(() => {});
    const id = state.profileId, currentRoot = state.settings?.rootPageId || "";
    const data = await localStore.get([PROFILE_IDS]);
    let ids = (data[PROFILE_IDS] || []).filter(candidate => candidate !== id);
    await removeProfileStorage(id, currentRoot);
    let next = ids[0];
    if (!next) {
      next = uuid();
      ids = [next];
      await localStore.set({ [profileKey("settings", next)]: {
        profileId: next, name: "API A", notionToken: "", rootPageId: "", rememberVmk: true,
      } });
    }
    await localStore.set({ [PROFILE_IDS]: ids, [ACTIVE_PROFILE]: next });
    location.replace(`${location.pathname}?profile=${encodeURIComponent(next)}`);
  } catch (error) {
    state.leaving = false;
    toast(safeErrorMessage(error), "error");
  }
}

function updateIndexStatus(message = "") {
  els.connectionCard.classList.toggle("indexing", state.backgroundIndexing);
  if (message) els.connectionText.textContent = message;
  else if (state.backgroundIndexing)
    els.connectionText.textContent = t("backgroundIndexingFolders", [String(state.indexScanned)]);
  else
    els.connectionText.textContent = state.indexReady
      ? t("indexComplete")
      : t("indexResumable");
}
function updateConnection(ok) {
  els.connectionCard.classList.toggle("connected", ok);
  els.connectionTitle.textContent = ok ? t("connected") : t("notConnected");
  if (ok) updateIndexStatus();
  else {
    els.connectionCard.classList.remove("indexing");
    els.connectionText.textContent = t("completeNotionSetup");
  }
}

async function notion(path, options = {}, tokenOverride = "") {
  if (!API) throw new Error("GitHub Pages 是純靜態網站；請先在 config.js 設定 CORS-enabled Notion API proxy。 ");
  const notionToken = tokenOverride || state.settings?.notionToken;
  if (!notionToken) throw new Error(t("notionTokenRequired"));
  if (state.leaving) throw new DOMException(t("cancelled"), "AbortError");
  const signal = options.signal;
  let attempt = 0;
  while (true) {
    await enterApiGate(signal);
    throwIfAborted(signal);
    const headers = new Headers(options.headers || {});
    headers.set("Authorization", `Bearer ${notionToken}`);
    headers.set("Notion-Version", API_VERSION);
    if (
      options.body &&
      !(options.body instanceof FormData) &&
      !headers.has("Content-Type")
    )
      headers.set("Content-Type", "application/json");
    const response = await fetch(`${API}${path}`, { ...options, headers });
    if (response.status === 429 || response.status === 529) {
      if(attempt >= 6) {
        await response.body?.cancel().catch(()=>{});
        throw new Error(t("notionApiError", [String(response.status)]));
      }
      const retryMs =
        parseRetryAfter(response.headers.get("Retry-After")) ||
        Math.min(60_000, 1000 * 2 ** Math.min(attempt, 6));
      pauseApiGate(retryMs);
      attempt++;
      try {
        await response.body?.cancel();
      } catch {}
      continue;
    }
    const raw = await response.text();
    let data = {};
    try {
      data = raw ? JSON.parse(raw) : {};
    } catch {
      data = { message: raw };
    }
    if (!response.ok)
      throw new Error(
        data.message || t("notionApiError", [String(response.status)]),
      );
    if (state.leaving) throw new DOMException(t("cancelled"), "AbortError");
    return data;
  }
}
async function getWorkspaceFileUploadLimit(signal) {
  const token = state.settings?.notionToken || "";
  if (!token) throw new Error(t("notionTokenRequired"));
  if (state.workspaceUpload?.token === token) return state.workspaceUpload.limit;
  const user = await notion("/users/me", { signal }, token),
    rawLimit = Number(user?.bot?.workspace_limits?.max_file_upload_size_in_bytes),
    limit = Number.isFinite(rawLimit) && rawLimit > 0 ? rawLimit : 5 * MiB;
  state.workspaceUpload = { token, limit };
  return limit;
}
async function lockPage(pageId, signal) {
  await notion(`/pages/${pageId}`, {
    method: "PATCH",
    body: JSON.stringify({ is_locked: true }),
    signal,
  });
}
function pageTitle(page) {
  const p = page.properties || {};
  return (
    p.title?.title?.[0]?.plain_text ||
    Object.values(p).find((x) => x.type === "title")?.title?.[0]?.plain_text ||
    "Notion Drive"
  );
}
async function listChildren(pageId, { signal } = {}) {
  const results = [];
  let cursor;
  do {
    const q = new URLSearchParams({ page_size: "100" });
    if (cursor) q.set("start_cursor", cursor);
    const data = await notion(`/blocks/${pageId}/children?${q}`, { signal });
    results.push(...data.results);
    cursor = data.has_more ? data.next_cursor : null;
  } while (cursor);
  return results;
}

function richTextValue(richText = []) {
  return richText
    .map((part) => part.plain_text || part.text?.content || "")
    .join("");
}
function cryptoTokenFromBlock(block, prefix) {
  const text = richTextValue(blockPayload(block)?.rich_text || []);
  return text.startsWith(prefix) ? text.slice(prefix.length) : null;
}
async function findRootCryptoConfig(rootId) {
  const inspectedBlocks = [];
  let vaultConfig = null, cursor;
  do {
    const query = new URLSearchParams({ page_size: "100" });
    if (cursor) query.set("start_cursor", cursor);
    const data = await notion(`/blocks/${rootId}/children?${query}`);
    for (const block of data.results || []) {
      inspectedBlocks.push(block);
      const vaultToken = cryptoTokenFromBlock(block, VAULT_CONFIG_PREFIX);
      if (vaultToken) vaultConfig = { blockId: block.id, token: vaultToken };
    }
    cursor = data.has_more ? data.next_cursor : null;
  } while (cursor);
  return { vaultConfig, inspectedBlocks };
}
async function createVaultConfig(rootId, vmk, password) {
  const token = await wrapVmk(vmk, password);
  const result = await notion(`/blocks/${rootId}/children`, {
    method: "PATCH",
    body: JSON.stringify({
      children: [
        {
          object: "block",
          type: "paragraph",
          paragraph: {
            rich_text: pageTitleRich(`${VAULT_CONFIG_PREFIX}${token}`),
          },
        },
      ],
    }),
  });
  return result.results?.[0]?.id || null;
}
async function updateVaultConfig(blockId, vmk, password) {
  const token = await wrapVmk(vmk, password);
  await notion(`/blocks/${blockId}`, {
    method: "PATCH",
    body: JSON.stringify({
      paragraph: {
        rich_text: pageTitleRich(`${VAULT_CONFIG_PREFIX}${token}`),
      },
    }),
  });
}
async function unlockRootVmk(rootId, password, { newRoot = false } = {}) {
  const found = await findRootCryptoConfig(rootId);
  if (found.vaultConfig) {
    try {
      return {
        vmk: await unwrapVmk(found.vaultConfig.token, password),
        blockId: found.vaultConfig.blockId,
      };
    } catch {
      throw vaultAccessError();
    }
  }
  const hasEncryptedChildren = found.inspectedBlocks.some(
    (block) =>
      block.type === "child_page" &&
      (block.child_page?.title || "").startsWith("NDP1."),
  );
  if (hasEncryptedChildren || (!newRoot && state.pendingEncryptedState))
    throw vaultAccessError();

  const vmk = createVmk(),
    blockId = await createVaultConfig(rootId, vmk, password);
  return { vmk, blockId };
}
async function rewrapRootVmk(rootId, vmk, password) {
  const found = await findRootCryptoConfig(rootId);
  if (found.vaultConfig) {
    await updateVaultConfig(found.vaultConfig.blockId, vmk, password);
    return found.vaultConfig.blockId;
  }
  return createVaultConfig(rootId, vmk, password);
}
async function validateRootPage(rootInput, tokenOverride = "") {
  const rootId = parseNotionPageId(rootInput);
  if (!rootId) throw new Error(t("rootPageInvalid"));
  const page = await notion(`/pages/${rootId}`, {}, tokenOverride);
  if (page.object !== "page" || page.in_trash)
    throw new Error(t("rootPageUnavailable"));
  return page;
}
async function verifyRootVmk(rootId, vmk) {
  const found = await findRootCryptoConfig(rootId);
  if (!found.vaultConfig) throw vaultAccessError();
  const encryptedPage = found.inspectedBlocks.find(
    (block) =>
      block.type === "child_page" &&
      (block.child_page?.title || "").startsWith("NDP1."),
  );
  if (encryptedPage) {
    try {
      await decryptMetadata(
        encryptedPage.child_page.title.slice(5),
        vmk,
        "page-metadata",
      );
    } catch {
      throw vaultAccessError();
    }
  }
  return found.vaultConfig.blockId;
}

async function normalizeBlock(
  block,
  parentId = state.currentPageId,
  savedOverride,
) {
  if (block.type !== "child_page" || block.in_trash) return null;
  const saved = savedOverride || state.meta[block.id] || {},
    title = block.child_page?.title || "";
  let data, kind;
  if (!title.startsWith("NDP1.")) return null;
  try {
    data = await decryptMetadata(
      title.slice(5),
      state.vmk,
      "page-metadata",
    );
    if (data?.kind === "folder") kind = "Folder";
    else if (data?.kind === "file" && (data?.format === "ndrv1-gcm" || data?.format === RAW_VIDEO_FORMAT))
      kind = "File";
    else return null;
    // v0.19.3 permanent NDP1/v1 metadata uses only optional contentId.
    // NDP0 pending pages are hidden earlier because only NDP1 is enumerated.
  } catch {
    throw vaultAccessError();
  }
  const base = {
    id: block.id,
    kind,
    parentId,
    favorite: Boolean(saved.favorite),
    trashed: false,
    uploadedAt: saved.uploadedAt || block.created_time || null,
    modifiedAt: block.last_edited_time || saved.modifiedAt || null,
  };
  const item =
    kind === "Folder"
      ? { ...base, name: data.name || t("encryptedFolderDefault") }
      : {
          ...base,
          name: data.name || t("encryptedFileDefault"),
          mime: data.mime || mimeFromName(data.name),
          size: data.size || 0,
          encrypted: data.format === "ndrv1-gcm",
          encryptionVersion: data.format === "ndrv1-gcm" ? 4 : 0,
          archiveFormat: data.format,
          volumeCount: data.format === RAW_VIDEO_FORMAT ? 1 : (data.volumes || 1),
          rawVideoBlockId: data.format === RAW_VIDEO_FORMAT ? data.rawVideoBlockId : undefined,
          contentId: normalizeContentId(data.contentId || ""),
        };
  if (state.leaving) throw new DOMException(t("cancelled"), "AbortError");
  state.meta[item.id] = item;
  return item;
}

function refreshCurrent() {
  state.items = Object.values(state.meta).filter(
    (item) => item.parentId === state.currentPageId && !item.trashed,
  );
  showNotice("");
  render();
}
function subtreeIds(rootId) {
  const children = new Map();
  for (const item of Object.values(state.meta)) {
    if (!children.has(item.parentId)) children.set(item.parentId, []);
    children.get(item.parentId).push(item.id);
  }
  const result = [],
    queue = [rootId],
    seen = new Set();
  for (let index = 0; index < queue.length; index++) {
    const id = queue[index];
    if (seen.has(id)) continue;
    seen.add(id);
    result.push(id);
    queue.push(...(children.get(id) || []));
  }
  return result;
}
function removeMetaSubtree(rootId) {
  for (const id of subtreeIds(rootId)) {
    delete state.meta[id];
    state.indexedFolders.delete(id);
    state.selectedIds.delete(id);
    state.cutIds.delete(id);
  }
}
async function scanFolderIntoIndex(parentId) {
  if (!ensureVaultVerified(false)) throw vaultAccessError();
  if (indexScanPromises.has(parentId)) return indexScanPromises.get(parentId);
  const promise = (async () => {
    const previous = Object.values(state.meta).filter(
        (item) => item.parentId === parentId && !item.trashed,
      ),
      blocks = await listChildren(parentId),
      found = new Set(),
      folders = [];
    let discoveredUnindexedFolder = false;
    for (const block of blocks) {
      const item = await normalizeBlock(block, parentId);
      if (item) {
        found.add(item.id);
        if (item.kind === "Folder") {
          folders.push(item.id);
          if (!state.indexedFolders.has(item.id))
            discoveredUnindexedFolder = true;
        }
      }
    }
    for (const item of previous)
      if (!found.has(item.id)) removeMetaSubtree(item.id);
    state.indexedFolders.add(parentId);
    if (discoveredUnindexedFolder) state.indexReady = false;
    return folders;
  })();
  indexScanPromises.set(parentId, promise);
  try {
    return await promise;
  } finally {
    indexScanPromises.delete(parentId);
  }
}
function stopBackgroundIndex() {
  state.indexRun++;
  state.backgroundIndexing = false;
  updateIndexStatus();
}
function pendingIndexFolders() {
  return Object.values(state.meta)
    .filter(
      (item) =>
        item.kind === "Folder" &&
        !item.trashed &&
        !state.indexedFolders.has(item.id),
    )
    .sort((a, b) =>
      a.id === state.root?.id ? -1 : b.id === state.root?.id ? 1 : 0,
    );
}
function startBackgroundIndex() {
  if (
    !ensureConfigured(false) ||
    !ensureVaultVerified(false) ||
    !state.root ||
    state.backgroundIndexing || state.busy || state.leaving ||
    state.indexReady
  )
    return;
  const token = ++state.indexRun;
  state.backgroundIndexing = true;
  state.indexScanned = 0;
  updateIndexStatus();
  setTimeout(() => runBackgroundIndex(token), 100);
}
async function runBackgroundIndex(token) {
  let sinceSave = 0;
  try {
    while (token === state.indexRun) {
      if (state.busy || state.trashRunning || hasActiveTransfers() || state.moving) {
        await sleep(900);
        continue;
      }
      const next = pendingIndexFolders()[0];
      if (!next) {
        state.indexReady = true;
        state.backgroundIndexing = false;
        await persistLocal();
        updateIndexStatus();
        toast(t("permanentIndexComplete"), "success");
        return;
      }
      await scanFolderIntoIndex(next.id);
      if (token !== state.indexRun || state.leaving) return;
      state.indexScanned++;
      sinceSave++;
      if (state.currentPageId === next.id) refreshCurrent();
      updateIndexStatus();
      if (sinceSave >= 20) {
        await persistLocal();
        sinceSave = 0;
      }
    }
  } catch (error) {
    if (token !== state.indexRun) return;
    state.backgroundIndexing = false;
    state.indexReady = false;
    if (error.code === "VAULT_VERIFICATION_FAILED") {
      lockVault(error);
      return;
    }
    await persistLocal();
    updateIndexStatus(t("backgroundIndexPaused"));
    toast(t("backgroundIndexPausedError", [String(error.message)]), "error");
  }
}
async function syncCurrentFolder({ silent = false } = {}) {
  if (!ensureConfigured(false) || !ensureVaultVerified(false)) return;
  setLoading(true);
  showNotice("");
  try {
    await scanFolderIntoIndex(state.currentPageId);
    await persistLocal();
    updateConnection(true);
    refreshCurrent();
    if (!silent) toast(t("currentFolderSynced"), "success");
    startBackgroundIndex();
  } catch (error) {
    if (error.code === "VAULT_VERIFICATION_FAILED") {
      lockVault(error);
      render();
      return;
    }
    updateConnection(false);
    showNotice(error.message);
    render();
  } finally {
    setLoading(false);
  }
}
async function rebuildIndex() {
  if (!ensureConfigured(false) || !ensureVaultVerified() || !state.root) return;
  stopBackgroundIndex();
  state.indexedFolders.clear();
  state.indexReady = false;
  await persistLocal();
  updateConnection(true);
  startBackgroundIndex();
  toast(t("indexRebuildStarted"), "success");
}
function recordsForView() {
  if (state.view === "files")
    return Object.values(state.meta).filter(
      (item) => item.parentId === state.currentPageId && !item.trashed,
    );
  if (state.view === "favorites")
    return Object.values(state.meta).filter((i) => i.favorite && !i.trashed);
  if (state.view === "trash") return state.trash;
  return [];
}
function filteredItems() {
  const q = state.query.toLocaleLowerCase(UI_LOCALE);
  return recordsForView()
    .filter((i) => !q || i.name?.toLocaleLowerCase(UI_LOCALE).includes(q))
    .sort((a, b) => {
      if (state.view === "trash")
        return (
          new Date(b.timestamp || b.deletedAt) -
          new Date(a.timestamp || a.deletedAt)
        );
      return a.kind === b.kind
        ? a.name.localeCompare(b.name, UI_LOCALE)
        : a.kind === "Folder"
          ? -1
          : 1;
    });
}
function icon(item) {
  if (item.kind === "Folder") return "📁";
  if (item.mime?.startsWith("image/")) return "🖼";
  if (item.mime?.startsWith("video/")) return "▶";
  if (item.mime?.startsWith("audio/")) return "♫";
  if (item.mime === "application/pdf") return "PDF";
  return "▤";
}
function configureView() {
  const cfg = {
    files: [
      t("myFiles"),
      t("filesViewSubtitle"),
      t("emptyPageTitle"),
      t("emptyPageText"),
    ],
    favorites: [
      t("favorites"),
      t("favoritesSubtitle"),
      t("noFavoritesTitle"),
      t("noFavoritesText"),
    ],
    trash: [
      t("trash"),
      t("trashSubtitle"),
      t("emptyTrashTitle"),
      t("emptyTrashText"),
    ],
  }[state.view];
  els.title.textContent =
    state.view === "files" ? state.path.at(-1)?.name || cfg[0] : cfg[0];
  els.subtitle.textContent = cfg[1];
  els.emptyTitle.textContent = cfg[2];
  els.emptyText.textContent = cfg[3];
  const files = state.view === "files";
  els.breadcrumbs.classList.toggle("hidden", !files);
  els.searchBox.classList.toggle("hidden", !files);
  els.newFolder.classList.toggle("hidden", !files);
  els.refresh.classList.toggle("hidden", !files);
  $("#emptyUploadButton").classList.toggle("hidden", !files);
  els.clearView.classList.toggle("hidden", state.view !== "trash");
  els.clearView.textContent = t("clearTrashRecords");
  const parent = files ? state.path.at(-2) : null,
    up = $("#moveUpTarget");
  up.classList.toggle("unavailable", !parent);
  up.textContent = parent ? t("moveUpTo", [String(parent.name)]) : t("atRoot");
}
function isFolderWithin(folderId, possibleAncestorId) {
  let current = state.meta[folderId];
  const seen = new Set();
  while (current && !seen.has(current.id)) {
    if (current.id === possibleAncestorId) return true;
    seen.add(current.id);
    current = current.parentId ? state.meta[current.parentId] : null;
  }
  return false;
}
function selectedMoveItems() {
  return [...state.selectedIds].map((id) => state.meta[id]).filter(Boolean);
}
function selectedActionItems() {
  const visibleIds = new Set(recordsForView().map((item) => item.id));
  return [...state.selectedIds]
    .filter((id) => visibleIds.has(id))
    .map(
      (id) =>
        state.meta[id] || state.trash.find((candidate) => candidate.id === id),
    )
    .filter(Boolean);
}
function moveTargetIssue(targetId, items = selectedMoveItems()) {
  if (!targetId) return t("targetFolderMissing");
  if (!items.length) return t("noMoveSelection");
  if (items.every((item) => item.parentId === targetId))
    return t("alreadyInFolder");
  for (const item of items) {
    if (item.id === state.root?.id) return t("rootCannotMove");
    if (item.kind === "Folder" && targetId === item.id)
      return t("folderCannotMoveIntoSelf");
    if (item.kind === "Folder" && isFolderWithin(targetId, item.id))
      return t("folderCannotMoveIntoDescendant");
  }
  return "";
}
function cutItems() {
  return [...state.cutIds].map((id) => state.meta[id]).filter(Boolean);
}
function toggleSelection(item) {
  if (state.selectedIds.has(item.id)) state.selectedIds.delete(item.id);
  else state.selectedIds.add(item.id);
  state.selectionMode = state.selectedIds.size > 0;
  state.selectionAnchorId = state.selectedIds.size ? item.id : null;
  render();
}
function selectRange(item, additive = false) {
  const items = filteredItems();
  const targetIndex = items.findIndex((candidate) => candidate.id === item.id);
  if (targetIndex < 0) return;
  const fallbackAnchor = [...state.selectedIds].at(-1) || item.id;
  const anchorId = state.selectionAnchorId || fallbackAnchor;
  let anchorIndex = items.findIndex((candidate) => candidate.id === anchorId);
  if (anchorIndex < 0) anchorIndex = targetIndex;
  if (!additive) state.selectedIds.clear();
  const from = Math.min(anchorIndex, targetIndex),
    to = Math.max(anchorIndex, targetIndex);
  for (let index = from; index <= to; index++)
    state.selectedIds.add(items[index].id);
  state.selectionMode = state.selectedIds.size > 0;
  state.selectionAnchorId = items[anchorIndex]?.id || item.id;
  render();
}
function syncSelectionClasses() {
  els.grid.querySelectorAll(".file-card[data-item-id]").forEach((card) => {
    card.classList.toggle(
      "selected",
      state.selectedIds.has(card.dataset.itemId),
    );
    card.classList.toggle("cut", state.cutIds.has(card.dataset.itemId));
  });
}
function cutSelection(item = null) {
  if (state.view !== "files") return;
  if (item && !state.selectedIds.has(item.id)) {
    state.selectedIds.clear();
    state.selectedIds.add(item.id);
  }
  const ids = [...state.selectedIds].filter(
    (id) => id !== state.root?.id && state.meta[id] && !state.meta[id].trashed,
  );
  if (!ids.length) {
    toast(t("selectItemsToCut"));
    return;
  }
  state.cutIds = new Set(ids);
  state.selectedIds.clear();
  state.selectionMode = false;
  closeContextMenu();
  render();
  toast(t("cutItemsReady", [String(ids.length)]), "success");
}
function cancelSelectionState() {
  if (state.selectionMode || state.selectedIds.size) {
    state.selectedIds.clear();
    state.selectionMode = false;
    state.selectionAnchorId = null;
  } else if (state.cutIds.size) {
    state.cutIds.clear();
    toast(t("cutCancelled"));
  }
  render();
}
async function pasteCutItems(targetId = state.currentPageId) {
  const items = cutItems();
  if (!items.length) {
    toast(t("clipboardEmpty"));
    return;
  }
  const issue = moveTargetIssue(targetId, items);
  if (issue) {
    toast(issue);
    return;
  }
  state.selectedIds = new Set(items.map((item) => item.id));
  await moveSelectedItems(targetId);
  for (const item of items)
    if (state.meta[item.id]?.parentId === targetId)
      state.cutIds.delete(item.id);
  render();
}
function clearDragStyles() {
  document
    .querySelectorAll(".dragging,.drop-target,.drop-invalid")
    .forEach((node) =>
      node.classList.remove("dragging", "drop-target", "drop-invalid"),
    );
  document.body.classList.remove("internal-drag");
}
function comparableName(value) {
  return String(value || "").normalize("NFKC").toLocaleLowerCase();
}
async function findRemoteNameCollision(parentId, name, excludingId = null) {
  const wanted = comparableName(name);
  const blocks = await listChildren(parentId);
  for (const block of blocks) {
    const candidate = await normalizeBlock(block, parentId);
    if (!candidate || candidate.id === excludingId) continue;
    if (comparableName(candidate.name) === wanted) return candidate;
  }
  return null;
}
async function ensureNoNameCollision(parentId, name, excludingId = null) {
  const collision = await findRemoteNameCollision(parentId, name, excludingId);
  if (collision) throw new Error(t("nameAlreadyExists", [name]));
}

async function moveItem(item, targetId) {
  if (!ensureVaultVerified()) return false;
  if (item.parentId === targetId) return false;
  if (item.id === state.root?.id) throw new Error(t("rootCannotMove"));
  if (
    item.kind === "Folder" &&
    (targetId === item.id || isFolderWithin(targetId, item.id))
  )
    throw new Error(t("folderCannotMoveSelfOrChild"));
  await ensureNoNameCollision(targetId, item.name, item.id);
  await lockPage(targetId);
  await notion(`/pages/${item.id}/move`, {
    method: "POST",
    body: JSON.stringify({ parent: { type: "page_id", page_id: targetId } }),
  });
  state.meta[item.id] = {
    ...item,
    parentId: targetId,
    modifiedAt: new Date().toISOString(),
  };
  return true;
}
async function moveSelectedItems(targetId) {
  if (state.moving) return false;
  const items = selectedMoveItems(),
    issue = moveTargetIssue(targetId, items);
  if (issue) {
    clearDragStyles();
    toast(issue);
    return false;
  }
  state.moving = true;
  clearDragStyles();
  let moved = 0,
    success = false;
  try {
    for (const item of items) if (await moveItem(item, targetId)) moved++;
    state.path = buildFolderPath(state.currentPageId);
    for (const item of items)
      if (state.meta[item.id]?.parentId === targetId)
        state.cutIds.delete(item.id);
    await persistLocal();
    await refreshCurrent();
    toast(t("movedItems", [String(moved)]), "success");
    success = true;
  } catch (error) {
    await persistLocal();
    await refreshCurrent();
    toast(t("moveFailed", [String(error.message)]), "error");
  } finally {
    state.selectedIds.clear();
    state.selectionMode = false;
    state.selectionAnchorId = null;
    state.moving = false;
    clearDragStyles();
    render();
  }
  return success;
}
function bindMoveDropTarget(node, target) {
  const resolve = () => (typeof target === "function" ? target() : target);
  node.addEventListener("dragover", (event) => {
    if (
      ![...(event.dataTransfer?.types || [])].includes(
        "application/x-ndrive-items",
      )
    )
      return;
    event.preventDefault();
    event.stopPropagation();
    const issue = moveTargetIssue(resolve());
    node.classList.toggle("drop-invalid", Boolean(issue));
    node.classList.toggle("drop-target", !issue);
    event.dataTransfer.dropEffect = issue ? "none" : "move";
  });
  node.addEventListener("dragleave", () =>
    node.classList.remove("drop-target", "drop-invalid"),
  );
  node.addEventListener("drop", async (event) => {
    if (
      ![...(event.dataTransfer?.types || [])].includes(
        "application/x-ndrive-items",
      )
    )
      return;
    event.preventDefault();
    event.stopPropagation();
    const targetId = resolve(),
      issue = moveTargetIssue(targetId);
    node.classList.remove("drop-target", "drop-invalid");
    if (issue) {
      toast(issue);
      return;
    }
    await moveSelectedItems(targetId);
  });
}

function render() {
  configureView();
  const items = filteredItems();
  els.grid.innerHTML = "";
  els.grid.className = `file-grid ${state.layout === "list" ? "list" : ""}`;
  els.grid.classList.toggle("hidden", !items.length);
  els.empty.classList.toggle("hidden", Boolean(items.length));
  if (state.view === "files")
    els.subtitle.textContent = t("directChildPages", [String(items.length)]);
  for (const item of items) {
    const card = document.createElement("article");
    card.className = `file-card ${item.kind === "Folder" ? "folder" : "file"}`;
    card.tabIndex = 0;
    card.dataset.itemId = item.id;
    card.classList.toggle("selected", state.selectedIds.has(item.id));
    card.classList.toggle("cut", state.cutIds.has(item.id));
    if (state.cutIds.has(item.id)) card.dataset.cutLabel = ` · ${t("cut")}`;
    const secondary =
      state.view === "trash"
        ? t("deletedAt", [formatDate(item.deletedAt)])
        : item.kind === "Folder"
          ? t("folder")
          : `${compactFileType(item)}・${formatBytes(item.size)}`;
    card.innerHTML = `<div class="file-icon">${icon(item)}</div><p class="file-name"></p><span class="file-meta file-kind"></span><span class="file-meta file-date">${item.modifiedAt ? formatDate(item.modifiedAt) : ""}</span><div class="card-actions"></div>`;
    card.querySelector(".file-name").textContent = item.name || t("unnamed");
    if (item.kind === "File") showPreviewThumbnail(card,item.id);
    const meta = card.querySelector(".file-kind");
    meta.textContent = secondary;
    meta.title = item.mime || secondary;
    const actions = card.querySelector(".card-actions");
    if (state.view === "trash") {
      actions.append(actionButton("↶", t("restore"), () => restoreItem(item)));
    } else {
      actions.append(
        actionButton(item.favorite ? "★" : "☆", t("favorites"), () =>
          toggleFavorite(item),
        ),
      );
      card.addEventListener("click", (event) => {
        if (event.shiftKey) {
          event.preventDefault();
          selectRange(item, event.ctrlKey || event.metaKey);
          return;
        }
        if (
          state.selectionMode ||
          event.ctrlKey ||
          event.metaKey ||
          state.selectedIds.size
        ) {
          event.preventDefault();
          toggleSelection(item);
          return;
        }
        openItem(item);
      });
      card.addEventListener("keydown", (e) => {
        if (e.key === "Enter") openItem(item);
      });
      card.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        openContextMenu(item, e.clientX, e.clientY);
      });
      if (state.view === "files") {
        card.draggable = true;
        card.addEventListener("dragstart", (event) => {
          if (!state.selectedIds.has(item.id)) {
            state.selectedIds.clear();
            state.selectedIds.add(item.id);
            state.selectionAnchorId = item.id;
            card.classList.add("selected");
          }
          event.dataTransfer.effectAllowed = "move";
          event.dataTransfer.setData(
            "application/x-ndrive-items",
            JSON.stringify([...state.selectedIds]),
          );
          document.body.classList.add("internal-drag");
          requestAnimationFrame(() => card.classList.add("dragging"));
        });
        card.addEventListener("dragend", () => {
          clearDragStyles();
          if (!state.moving) {
            state.selectedIds.clear();
            state.selectionAnchorId = null;
            render();
          }
        });
        if (item.kind === "Folder") bindMoveDropTarget(card, item.id);
      }
    }
    els.grid.append(card);
  }
  renderBreadcrumbs();
}
function actionButton(label, title, handler) {
  const b = document.createElement("button");
  b.className = `favorite-button ${label === "★" ? "on" : ""}`;
  b.textContent = label;
  b.title = title;
  b.onclick = (e) => {
    e.stopPropagation();
    handler();
  };
  return b;
}
function renderBreadcrumbs() {
  els.breadcrumbs.innerHTML = "";
  state.path.forEach((p, index) => {
    const b = document.createElement("button");
    b.textContent = p.name;
    b.onclick = async () => {
      state.selectedIds.clear();
      state.selectionMode = false;
      state.selectionAnchorId = null;
      state.path = state.path.slice(0, index + 1);
      state.currentPageId = p.id;
      state.query = "";
      els.search.value = "";
      await refreshCurrent();
    };
    if (index < state.path.length - 1) bindMoveDropTarget(b, p.id);
    els.breadcrumbs.append(b);
  });
}
function buildFolderPath(folderId) {
  const result = [],
    seen = new Set();
  let current =
    state.meta[folderId] || (state.root?.id === folderId ? state.root : null);
  while (current && !seen.has(current.id)) {
    seen.add(current.id);
    result.push({ id: current.id, name: current.name || t("unnamedFolder") });
    current = current.parentId ? state.meta[current.parentId] : null;
  }
  return result.reverse();
}
function closeContextMenu() {
  $("#contextMenu").classList.add("hidden");
  state.contextItem = null;
}
function openContextMenu(item, x, y) {
  const background = !item;
  if (background && state.view !== "files") return;
  if (!background && !state.selectedIds.has(item.id)) {
    state.selectedIds.clear();
    state.selectedIds.add(item.id);
    state.selectionMode = true;
    state.selectionAnchorId = item.id;
    syncSelectionClasses();
  }
  state.contextItem = item;
  const menu = $("#contextMenu"),
    newFolder = $("#newFolderContextButton"),
    download = $("#downloadContextButton"),
    rename = $("#renameContextButton"),
    cut = $("#cutContextButton"),
    paste = $("#pasteIntoContextButton"),
    actionItems = selectedActionItems(),
    single = actionItems.length === 1 ? actionItems[0] : null;
  newFolder.classList.toggle("hidden", !background);
  download.classList.toggle("hidden", background);
  download.disabled = !actionItems.length;
  download.title = download.disabled ? t("noDownloadableItems") : "";
  rename.classList.toggle(
    "hidden",
    background || !single || state.view === "trash",
  );
  cut.classList.toggle("hidden", background || state.view !== "files");
  paste.textContent = background ? t("paste") : t("pasteIntoFolder");
  paste.classList.toggle(
    "hidden",
    state.view !== "files" ||
      !state.cutIds.size ||
      (!background && item.kind !== "Folder"),
  );
  $("#trashContextButton").classList.toggle("hidden", background);
  menu.classList.remove("hidden");
  const width = menu.offsetWidth,
    height = menu.offsetHeight;
  menu.style.left = `${Math.min(x, window.innerWidth - width - 12)}px`;
  menu.style.top = `${Math.min(y, window.innerHeight - height - 12)}px`;
}
function openNewFolderDialog() {
  if (ensureConfigured() && ensureVaultVerified()) {
    $("#folderNameInput").value = "";
    $("#folderDialog").showModal();
  }
}
function openRenameDialog(item) {
  if (!item || !["Folder", "File"].includes(item.kind)) return;
  state.renameItem = item;
  $("#renameInput").value = item.name;
  $("#renameDialog").showModal();
  $("#renameInput").select();
}
async function renameItem(item, newName) {
  if (!ensureVaultVerified()) return;
  if (!newName || newName === item.name) return;
  await ensureNoNameCollision(item.parentId, newName, item.id);

  let metadata;
  if (item.kind === "Folder") {
    metadata = { v: 1, kind: "folder", name: newName };
  } else if (item.kind === "File") {
    // Resolve the currently committed generation first. This also safely upgrades
    // a legacy v0.19.2 file with one unambiguous payload set to v0.19.3 contentId.
    const fresh = await resolveFreshFile(item);
    const contentId = normalizeContentId(fresh.contentId || "");
    if (!contentId) throw new Error(t("volumeIncomplete"));
    metadata = {
      v: 1,
      kind: "file",
      name: newName,
      mime: fresh.mime || mimeFromName(newName),
      size: fresh.size || 0,
      format: fresh.archiveFormat,
      volumes: fresh.volumeCount || 1,
      contentId,
      ...(fresh.archiveFormat === RAW_VIDEO_FORMAT ? {rawVideoBlockId: fresh.rawVideoBlockId} : {}),
    };
  } else return;

  const token = await encryptMetadata(metadata, state.vmk, "page-metadata");
  await notion(`/pages/${item.id}`, {
    method: "PATCH",
    body: JSON.stringify({
      properties: {
        title: { type: "title", title: pageTitleRich(`NDP1.${token}`) },
      },
    }),
  });
  state.meta[item.id] = {
    ...state.meta[item.id],
    name: newName,
    ...(metadata.contentId ? { contentId: metadata.contentId } : {}),
    modifiedAt: new Date().toISOString(),
  };
  if (state.root?.id === item.id) state.root.name = newName;
  state.path = buildFolderPath(state.currentPageId);
  await persistLocal();
  render();
  toast(t("itemRenamed"), "success");
}

const SHARD_NAME = /^ND-([A-F0-9]{32})\.V(\d{4})-(\d{4})\.S(\d{6})-(\d{6})\.ndrive\.zip$/i;
const VOLUME_NAME = /^ND-([A-F0-9]{32})(?:\.V(\d{4})-(\d{4}))?\.ndrive\.zip$/i;
function normalizeContentId(value) {
  const id = String(value || "").replaceAll("-", "").toUpperCase();
  return /^[A-F0-9]{32}$/.test(id) ? id : null;
}
function shardName(baseId, volumeIndex, volumeCount, index, count) {
  return `ND-${baseId}.V${String(volumeIndex).padStart(4, "0")}-${String(volumeCount).padStart(4, "0")}.S${String(index).padStart(6, "0")}-${String(count).padStart(6, "0")}.ndrive.zip`;
}
function parsePayloadName(name) {
  let match = String(name || "").match(SHARD_NAME);
  if (match) {
    return {
      type: "shard",
      contentId: match[1].toUpperCase(),
      volumeIndex: Number(match[2]),
      volumeCount: Number(match[3]),
      shardIndex: Number(match[4]),
      shardCount: Number(match[5]),
    };
  }
  match = String(name || "").match(VOLUME_NAME);
  if (!match) return null;
  return {
    type: "volume",
    contentId: match[1].toUpperCase(),
    volumeIndex: match[2] ? Number(match[2]) : 1,
    volumeCount: match[3] ? Number(match[3]) : 1,
  };
}
function payloadDescriptors(blocks) {
  return blocks.map((block) => {
    if (!["file", "image", "video", "audio", "pdf"].includes(block.type)) return null;
    const payload = blockPayload(block), storedName = payload.name || "", parsed = parsePayloadName(storedName), url = hostedUrl(payload);
    if (!parsed || !url) return null;
    return { ...parsed, blockId: block.id, storedName, url };
  }).filter(Boolean);
}
function resolveNativeVideoPayload(blocks, item) {
  const expectedId = String(item.rawVideoBlockId || "");
  if (!/^[0-9a-f-]{32,36}$/i.test(expectedId)) throw new Error("原生影片的 Block ID 無效，拒絕猜測檔案。");
  const matching = blocks.filter(b => b.id?.replaceAll("-", "") === expectedId.replaceAll("-", "")
    && ["file", "video"].includes(b.type) && !b.in_trash);
  if (matching.length !== 1 || !hostedUrl(blockPayload(matching[0])))
    throw new Error("找不到完整的原生影片 Block，請重新整理 Notion Drive。");
  const block = matching[0];
  return {...item, encrypted: false, archiveFormat: RAW_VIDEO_FORMAT,
    rawVideoBlockId: block.id, url: hostedUrl(blockPayload(block)),
    blockId: block.id, blockIds: [block.id], volumes: [], volumeCount: 1};
}
function resolvePayloadSet(blocks, item) {
  if (item.archiveFormat === RAW_VIDEO_FORMAT) return resolveNativeVideoPayload(blocks, item);
  const descriptors = payloadDescriptors(blocks);
  if (!descriptors.length) throw new Error(t("encryptedFileBlockMissing"));
  const knownIds = [...new Set(descriptors.map((entry) => entry.contentId))];
  const requested = normalizeContentId(item.contentId || "");
  // Old v0.19.2 metadata has no contentId. It stays readable only when exactly
  // one payload generation exists, so the new client never guesses between two.
  const contentId = requested || (knownIds.length === 1 ? knownIds[0] : null);
  if (!contentId || !knownIds.includes(contentId)) throw new Error(t("volumeIncomplete"));
  const selected = descriptors.filter((entry) => entry.contentId === contentId),
    shards = selected.filter((entry) => entry.type === "shard"),
    volumes = selected.filter((entry) => entry.type === "volume");
  if (shards.length && volumes.length) throw new Error(t("volumeIncomplete"));

  if (shards.length) {
    const expectedVolumeCount = shards[0].volumeCount;
    if (expectedVolumeCount !== Number(item.volumeCount || expectedVolumeCount) ||
        shards.some((entry) => entry.volumeCount !== expectedVolumeCount))
      throw new Error(t("volumeIncomplete"));
    const groups = new Map();
    for (const entry of shards) {
      if (entry.volumeIndex < 1 || entry.volumeIndex > expectedVolumeCount ||
          entry.shardIndex < 1 || entry.shardIndex > entry.shardCount)
        throw new Error(t("volumeIncomplete"));
      if (!groups.has(entry.volumeIndex)) groups.set(entry.volumeIndex, []);
      groups.get(entry.volumeIndex).push(entry);
    }
    if (groups.size !== expectedVolumeCount) throw new Error(t("volumeIncomplete"));
    const resolved = [];
    for (let volumeIndex = 1; volumeIndex <= expectedVolumeCount; volumeIndex++) {
      const parts = (groups.get(volumeIndex) || []).sort((a,b) => a.shardIndex - b.shardIndex),
        expectedShardCount = parts[0]?.shardCount || 0;
      if (!expectedShardCount || parts.length !== expectedShardCount ||
          parts.some((part,index) => part.shardIndex !== index + 1 || part.shardCount !== expectedShardCount))
        throw new Error(t("volumeIncomplete"));
      resolved.push({
        volumeIndex,
        volumeCount: expectedVolumeCount,
        shards: parts.map((part) => ({ index: part.shardIndex, count: part.shardCount, url: part.url, blockId: part.blockId })),
        url: parts[0].url,
      });
    }
    return { ...item, contentId, volumes: resolved, volumeCount: expectedVolumeCount, sharded: true,
      blockIds: shards.map((entry) => entry.blockId), blockId: shards[0].blockId };
  }

  const sorted = [...volumes].sort((a,b) => a.volumeIndex - b.volumeIndex),
    expectedVolumeCount = sorted[0]?.volumeCount || 0;
  if (!expectedVolumeCount || expectedVolumeCount !== Number(item.volumeCount || expectedVolumeCount) ||
      sorted.length !== expectedVolumeCount ||
      sorted.some((entry,index) => entry.volumeIndex !== index + 1 || entry.volumeCount !== expectedVolumeCount))
    throw new Error(t("volumeIncomplete"));
  return {
    ...item,
    contentId,
    url: sorted[0].url,
    urls: sorted.map((entry) => entry.url),
    volumes: sorted,
    blockId: sorted[0].blockId,
    blockIds: sorted.map((entry) => entry.blockId),
    storedName: sorted[0].storedName,
    volumeCount: expectedVolumeCount,
  };
}
// At most one ~4 MiB shard is buffered here. This stream has exactly the same
// bytes as the original encrypted volume; GCM chunks may cross shard borders.
/**
 * Only authenticated ciphertext is read from Notion, never the full FLV.
 * Old signed URLs may expire. Resolve a fresh set from the same file page and
 * refuse to mix shards/volumes when the block identity has changed.
 */
async function encryptedFlvSourceForItem(item, signal) {
  const expected = [...(item.volumes || [])].sort((a,b)=>a.volumeIndex-b.volumeIndex);
  if(!expected.length)throw new Error(t("downloadUrlMissing"));
  let freshVolumes=expected;
  const physical = (index,shardIndex) => {
    const volume=freshVolumes[index-1];
    if(!volume)throw new Error("Volume 對應失敗");
    return shardIndex===null?volume:volume.shards?.[shardIndex];
  };
  const fetchBytes = createRefreshingRangeReader({signal,
    load: async (index,shardIndex,from,to,requestSignal) => {
      throwIfAborted(signal);throwIfAborted(requestSignal);
      const target=physical(index,shardIndex);
      if(!target?.url)throw new Error("影片 Shard 網址缺失");
      const combined=new AbortController();
      const cancel=()=>combined.abort();
      signal?.addEventListener("abort",cancel,{once:true});
      requestSignal?.addEventListener("abort",cancel,{once:true});
      try {
        return await readExactHttpRange(remoteFetchUrl(target.url),from,to,{signal:combined.signal});
      } finally {
        signal?.removeEventListener("abort",cancel);
        requestSignal?.removeEventListener("abort",cancel);
      }
    },
    refresh: async () => {
      const latest=await resolveFreshFile(item,signal);
      const next=[...(latest.volumes||[])].sort((a,b)=>a.volumeIndex-b.volumeIndex);
      const same=next.length===expected.length && next.every((v,i)=>
        v.volumeIndex===expected[i].volumeIndex &&
        (v.shards?.length||0)===(expected[i].shards?.length||0) &&
        (v.shards?.length? v.shards.every((z,j)=>z.blockId===expected[i].shards[j].blockId): v.blockId===expected[i].blockId));
      if(!same)throw new Error("Notion 遠端影片分片已變更，為安全起見已停止播放");
      freshVolumes=next;
    }
  });
  return cachePreviewSource(createEncryptedFlvSource({volumes:expected,vmk:state.vmk,readPhysical:fetchBytes,shardSize:SHARD_SIZE,signal}),signal);
}

function setPreviewMeta(message) {
  state.previewMetaBase = String(message);
  renderPreviewMeta();
}
function renderPreviewMeta() {
  const stats = state.previewMemorySource?.stats;
  const progress = stats && !stats.closed && stats.total
    ? ` · 記憶體下載 ${formatBytes(stats.loaded)} / ${formatBytes(stats.total)}${stats.complete ? '（100%）' : stats.error ? `（已中斷：${stats.error}）` : ''}`
    : '';
  els.previewMeta.textContent = state.previewMetaBase + progress;
}
function cachePreviewSource(source, signal) {
  const cached = createMemoryMediaSource(source,{signal,onProgress:()=>{
    if(state.previewMemorySource===cached && !signal?.aborted)renderPreviewMeta();
  }});
  state.previewMemorySource?.close();
  state.previewMemorySource=cached;
  // 6B: retry transient failures while this SAME preview is alive. Never evict RAM pages.
  // Consecutive failure counter resets only when the verified sequential scan advances.
  void (async()=>{
    let failures=0, lastProgress=0;
    while(!cached.closed && !signal?.aborted && state.previewMemorySource===cached){
      try { await cached.preload(); return; }
      catch(error){
        if(cached.closed || signal?.aborted || error?.name==='AbortError')return;
        const message=String(error?.message||'');
        if(/GCM 驗證失敗|媒體大小無效|不合法|長度不符|不安全|不支援/.test(message))return;
        if(cached.stats.scanned > lastProgress) failures=0;
        lastProgress=cached.stats.scanned;
        if(++failures>12)return;
        try {
          await abortableSleep(Math.min(30000,500*Math.pow(2,Math.min(6,failures-1))),signal);
        } catch(error){ if(error?.name==='AbortError')return; throw error; }
      }
    }
  })().catch(error=>console.warn('[NotionDrive] preview preload',safeErrorMessage(error)));
  return cached;
}
function releasePreviewResources() {
  state.previewController?.abort();
  state.previewController=null;
  state.previewDialogController=null;
  try { state.mediaPreviewPlayer?.destroy(); } catch(error) { console.warn(safeErrorMessage(error)); }
  state.mediaPreviewPlayer=null;
  state.previewMemorySource?.close();state.previewMemorySource=null;
  state.preview=null;state.previewNavigationId=null;state.previewMetaBase="";
  for(const media of els.previewStage.querySelectorAll("video,audio")) {
    media.pause();media.removeAttribute("src");media.load();
  }
  if(state.previewObjectUrl)URL.revokeObjectURL(state.previewObjectUrl);
  state.previewObjectUrl=null;
  els.previewStage.classList.remove("image-preview-stage");
  els.previewStage.replaceChildren();
}

function volumeSource(volume, signal) {
  if (!volume.shards) return volume.url;
  let index = 0;
  return new ReadableStream({
    async pull(controller) {
      try {
        throwIfAborted(signal);
        if (index === volume.shards.length) { controller.close(); return; }
        const response = await fetch(remoteFetchUrl(volume.shards[index].url), { signal });
        if (!response.ok) { const error = new Error(t("downloadFailed")); error.status = response.status; throw error; }
        const bytes = new Uint8Array(await response.arrayBuffer());
        throwIfAborted(signal);
        if (!bytes.length || bytes.length > SHARD_SIZE || (index < volume.shards.length - 1 && bytes.length !== SHARD_SIZE)) throw new Error(t("volumeIncomplete"));
        index++;
        controller.enqueue(bytes);
      } catch (error) { controller.error(error); }
    },
    cancel() { index = volume.shards.length; },
  }, { highWaterMark: 0 });
}
async function resolveFreshFile(item, signal) {
  if (!ensureVaultVerified()) throw vaultAccessError();
  const blocks = await listChildren(item.id, { signal });
  return resolvePayloadSet(blocks, item);
}
async function openItem(item) {
  if (item.kind === "Folder") {
    state.path = buildFolderPath(item.id);
    state.currentPageId = item.id;
    state.view = "files";
    state.query = "";
    els.search.value = "";
    syncNav();
    if (state.indexedFolders.has(item.id)) refreshCurrent();
    else await syncCurrentFolder({ silent: true });
    startBackgroundIndex();
    return;
  }
  releasePreviewResources();
  state.previewNavigationId = item.id;
  const controller = new AbortController();
  state.previewController = controller;
  state.previewDialogController = els.previewDialog.open ? controller : null;
  try {
    const fresh = await resolveFreshFile(item, controller.signal);
    if (controller.signal.aborted || state.previewController !== controller)
      return;
    state.preview = fresh;
    state.previewNavigationId = fresh.id;
    await showPreview(fresh, controller);
  } catch (e) {
    if (state.previewController === controller && e.name !== "AbortError")
      state.previewNavigationId = state.preview?.id || null;
    if (state.previewController === controller && e.name !== "AbortError") toast(e.message, "error");
  }
}

function navigateImagePreview(direction) {
  if (!els.previewDialog.open) return false;
  const currentId = state.previewNavigationId || state.preview?.id,
    ordered = filteredItems(),
    current = ordered.find((item) => item.id === currentId);
  if (
    !current ||
    current.kind !== "File" ||
    !current.mime?.startsWith("image/")
  )
    return false;
  focusPreviewStage();
  const images = ordered.filter(
      (item) =>
        item.kind === "File" &&
        item.mime?.startsWith("image/") &&
        item.parentId === current.parentId,
    ),
    index = images.findIndex((item) => item.id === current.id),
    next = images[index + direction];
  if (next) void openItem(next);
  return true;
}
async function downloadItem(item, { quiet = false } = {}) {
  if (!ensureVmk() || !ensureVaultVerified()) return;
  if (!navigator.storage?.getDirectory || (!WEB_MODE && !globalThis.chrome?.downloads?.download)) {
    toast(t("downloadsDirectoryUnsupported"), "error");
    return false;
  }
  const downloadPath = fileSystemSafeName(item.name, t("downloadFallbackName"));
  let webFileHandle = null;
  if (WEB_MODE && window.showSaveFilePicker) {
    try {
      webFileHandle = await window.showSaveFilePicker({ suggestedName: downloadPath });
    } catch (error) {
      if (error?.name === "AbortError") return false;
      throw error;
    }
  }
  const task = addTransferTask({
    name: item.name,
    path: downloadPath,
    type: "download",
    detail: t("waitingDownload"),
  });
  Object.assign(task, { item, downloadPath, quiet, webFileHandle });
  enqueueDownloadTasks([task], { showSummary: false });
  return task.completion;
}
function compactDownloadSelection(items) {
  const selectedIds = new Set(items.map((item) => item.id));
  return items.filter((item) => {
    let parent = item.parentId ? state.meta[item.parentId] : null;
    const seen = new Set();
    while (parent && !seen.has(parent.id)) {
      if (selectedIds.has(parent.id) && parent.kind === "Folder") return false;
      seen.add(parent.id);
      parent = parent.parentId ? state.meta[parent.parentId] : null;
    }
    return true;
  });
}
async function collectDirectoryExport(items, signal) {
  const directories = [],
    files = [],
    queue = [],
    usedByParent = new Map();
  const reserveName = (parentPath, item) => {
    const key = parentPath.join("\u0001"),
      used = usedByParent.get(key) || new Set(),
      original = fileSystemSafeName(
        item.name,
        item.kind === "Folder" ? t("folder") : t("file"),
      );
    usedByParent.set(key, used);
    let stem = original,
      extension = "";
    if (item.kind === "File") {
      const dot = original.lastIndexOf(".");
      if (dot > 0) {
        stem = original.slice(0, dot);
        extension = original.slice(dot);
      }
    }
    let candidate = original,
      suffix = 2;
    while (used.has(candidate.toLocaleLowerCase(UI_LOCALE))) {
      candidate = `${stem.slice(0, 150)} (${suffix++})${extension}`;
    }
    used.add(candidate.toLocaleLowerCase(UI_LOCALE));
    return candidate;
  };
  for (const item of compactDownloadSelection(items)) {
    const name = reserveName([], item);
    if (item.kind === "Folder") queue.push({ item, path: [name] });
    else files.push({ item, path: [], name });
  }
  for (let index = 0; index < queue.length; index++) {
    throwIfAborted(signal);
    const current = queue[index];
    directories.push(current.path);
    await scanFolderIntoIndex(current.item.id);
    throwIfAborted(signal);
    const children = Object.values(state.meta)
      .filter((item) => item.parentId === current.item.id && !item.trashed)
      .sort((a, b) =>
        a.kind === b.kind
          ? a.name.localeCompare(b.name, UI_LOCALE)
          : a.kind === "Folder"
            ? -1
            : 1,
      );
    for (const child of children) {
      const name = reserveName(current.path, child);
      if (child.kind === "Folder")
        queue.push({ item: child, path: [...current.path, name] });
      else files.push({ item: child, path: current.path, name });
    }
  }
  return { directories, files };
}
function pathStartsWith(path, prefix) {
  return (
    path.length >= prefix.length &&
    prefix.every((segment, index) => path[index] === segment)
  );
}
async function downloadItemsToDirectory(items) {
  if (!ensureVmk() || !ensureVaultVerified()) return;
  if (!navigator.storage?.getDirectory || (!WEB_MODE && !globalThis.chrome?.downloads?.download)) {
    toast(t("downloadsDirectoryUnsupported"), "error");
    return false;
  }
  let webDirectoryHandle = null;
  if (WEB_MODE && window.showDirectoryPicker) {
    try {
      webDirectoryHandle = await window.showDirectoryPicker({ mode: "readwrite" });
    } catch (error) {
      if (error?.name === "AbortError") return false;
      throw error;
    }
  }
  const planningTask = addTransferTask({
    name: items.length === 1 ? items[0].name : t("selectedItems", [String(items.length)]),
    type: "download",
    detail: t("scanningFolders"),
  });
  patchTask(planningTask, { status: "preparing", progress: 1 });
  try {
    const plan = await collectDirectoryExport(
      items,
      planningTask.controller.signal,
    );
    throwIfCancelled(planningTask);
    const emptyDirectoryCount = plan.directories.filter(
      (directory) =>
        !plan.files.some((file) => pathStartsWith(file.path, directory)),
    ).length;
    patchTask(planningTask, {
      status: "preparing",
      progress: 3,
      detail: t("exportPlan", [String(plan.directories.length), String(plan.files.length)]),
    });
    if (WEB_MODE && !webDirectoryHandle)
      return await downloadPlanAsZip(plan, items, planningTask);
    const tasks = [];
    for (const entry of plan.files) {
      throwIfCancelled(planningTask);
      const downloadPath = [...entry.path, entry.name].join("/"),
        task = addTransferTask({
          name: entry.name,
          path: downloadPath,
          type: "download",
          detail: t("waitingDownload"),
        });
      Object.assign(task, {
        item: entry.item,
        downloadPath,
        quiet: true,
        webDirectoryHandle,
      });
      tasks.push(task);
    }
    state.uploadTasks = state.uploadTasks.filter(
      (task) => task.id !== planningTask.id,
    );
    renderUploads();
    if (!tasks.length) {
      toast(t("emptyFoldersCannotDownload"), "error");
      return false;
    }
    if (emptyDirectoryCount)
      toast(t("emptyFoldersSkipped", [String(emptyDirectoryCount)]), "info");
    return enqueueDownloadTasks(tasks, {
      showSummary: true,
      summaryLabel: t("folderDownload"),
    });
  } catch (error) {
    patchTask(
      planningTask,
      error.name === "AbortError"
        ? { status: "cancelled", detail: t("cancelled") }
        : { status: "failed", detail: safeErrorMessage(error) },
    );
    if (error.name !== "AbortError") toast(error.message, "error");
    return false;
  }
}
async function streamRawVideoToWritable(fresh, writable, signal, onProgress) {
  const response = await fetch(remoteFetchUrl(fresh.url), {signal});
  if (!response.ok) throw Object.assign(new Error(`原生影片下載失敗：HTTP ${response.status}`), {status: response.status});
  if (!response.body) throw new Error("瀏覽器不提供串流回應，為防止大型影片載入記憶體而取消。");
  const reader = response.body.getReader();
  let doneBytes = 0;
  try {
    while (true) {
      throwIfAborted(signal);
      const {done, value} = await reader.read();
      if (done) break;
      await writable.write(value);
      doneBytes += value.byteLength;
      onProgress?.(doneBytes, fresh.size);
    }
  } finally { reader.releaseLock(); }
  if (Number.isFinite(fresh.size) && fresh.size > 0 && doneBytes !== fresh.size)
    throw new Error(`下載尺寸不符：預期 ${fresh.size}，實際 ${doneBytes} bytes`);
  return doneBytes;
}
async function decryptFreshItemToWritable(item, writable, signal, onProgress) {
  const fresh = await resolveFreshFile(item, signal);
  if (fresh.archiveFormat === RAW_VIDEO_FORMAT)
    return streamRawVideoToWritable(fresh, writable, signal, onProgress);
  if (fresh.archiveFormat !== "ndrv1-gcm") throw new Error(t("unsupportedEncryption"));
  const volumes = [...(fresh.volumes || [])].sort((a, b) => a.volumeIndex - b.volumeIndex);
  if (!volumes.length) throw new Error(t("downloadUrlMissing"));
  let completedBefore = 0;
  for (const volume of volumes) {
    const info = await decryptToWritable(
      volumeSource(volume, signal),
      state.vmk,
      writable,
      {
        signal,
        onProgress: (done) => onProgress?.(completedBefore + done, fresh.size),
      },
    );
    completedBefore += info.originalSize;
  }
  return completedBefore;
}

function triggerBrowserDownload(file, name) {
  const url = URL.createObjectURL(file);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileSystemSafeName(name, t("downloadFallbackName"));
  anchor.style.display = "none";
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

async function downloadPlanAsZip(plan, items, planningTask) {
  let staging = null, zip = null;
  try {
    const selected = compactDownloadSelection(items);
    const zipName = selected.length === 1 && selected[0].kind === "Folder"
      ? `${fileSystemSafeName(selected[0].name, "Notion Drive")}.zip`
      : "Notion Drive export.zip";
    staging = await createDownloadStagingFile();
    zip = new Zip64StoreWriter(await staging.handle.createWritable());
    for (const directory of plan.directories) {
      throwIfCancelled(planningTask);
      await zip.addFile(`${directory.join("/")}/`, async () => {}, { retry: 0 });
    }
    const totalBytes = Math.max(1, plan.files.reduce((sum, entry) => sum + Number(entry.item.size || 0), 0));
    let completedBefore = 0;
    for (let index = 0; index < plan.files.length; index++) {
      throwIfCancelled(planningTask);
      const entry = plan.files[index];
      const path = [...entry.path, entry.name].join("/");
      await zip.addFile(path, async (sink) => {
        await decryptFreshItemToWritable(entry.item, sink, planningTask.controller.signal, (done) => {
          patchTask(planningTask, {
            status: "downloading",
            progress: 3 + ((completedBefore + done) / totalBytes) * 94,
            detail: t("downloadProgress", [formatBytes(completedBefore + done), formatBytes(totalBytes)]),
          });
        });
      }, { modifiedAt: entry.item.modifiedAt ? Date.parse(entry.item.modifiedAt) : Date.now(), retry: 1 });
      completedBefore += Number(entry.item.size || 0);
    }
    await zip.close();
    zip = null;
    const file = await staging.handle.getFile();
    triggerBrowserDownload(file, zipName);
    patchTask(planningTask, { status: "done", progress: 100, detail: t("downloadComplete") });
    toast(t("fileDownloaded"), "success");
    return true;
  } catch (error) {
    if (zip) await zip.abort();
    patchTask(planningTask, error.name === "AbortError"
      ? { status: "cancelled", detail: t("cancelled") }
      : { status: "failed", detail: safeErrorMessage(error) });
    if (error.name !== "AbortError") toast(error.message, "error");
    return false;
  } finally {
    await removeDownloadStagingFile(staging);
  }
}

async function downloadSelectedItems(items) {
  const selected = compactDownloadSelection(items);
  if (!selected.length) return;
  if (selected.length === 1 && selected[0].kind === "File")
    return downloadItem(selected[0]);
  return downloadItemsToDirectory(selected);
}
function focusPreviewStage() {
  if (!els.previewDialog.open) return;
  els.previewStage.focus({ preventScroll: true });
}

function openPreviewDialog() {
  state.previewDialogController = state.previewController;
  if (!els.previewDialog.open) els.previewDialog.showModal();
  focusPreviewStage();
}

// Explicit ahead-buffer policy.  These affect mpegts.js, not NDRVENC1 encryption.
// RAM preloading is independent. Keep the MSE decode buffer bounded.
const FLV_BUFFER_BEHIND_MAX_SECONDS = 90;
const FLV_BUFFER_BEHIND_KEEP_SECONDS = 40;
function mpegtsPlaybackConfig(extra = {}) {
  return {
    seekType: "range", accurateSeek: true, enableWorker: false, enableWorkerForMSE: false,
    lazyLoad: true,
    lazyLoadMaxDuration: 45,
    lazyLoadRecoverDuration: 15,
    autoCleanupSourceBuffer: true,
    autoCleanupMaxBackwardDuration: FLV_BUFFER_BEHIND_MAX_SECONDS,
    autoCleanupMinBackwardDuration: FLV_BUFFER_BEHIND_KEEP_SECONDS,
    ...extra,
  };
}
function mpegtsBufferedAhead(video) {
  const current = video.currentTime;
  for (let i = 0; i < video.buffered.length; i++) {
    if (video.buffered.start(i) <= current && current < video.buffered.end(i)) {
      return Math.max(0, video.buffered.end(i) - current);
    }
  }
  return 0;
}

// The full mpegts.js 1.8.2 browser bundle is loaded from app.html BEFORE this module.
// Avoid HEAD probing a chrome-extension:// URL; a failed probe is not evidence
// that the script is missing.  Keep missing-file and unsupported-MSE distinct.
function mpegtsLibraryProblem() {
  const lib = globalThis.mpegts;
  if (!lib || typeof lib.createPlayer !== "function")
    return "內建 mpegts.js 未載入。請重新載入擴充功能，並確認安裝目錄內的 vendor/mpegts.js 完整。";
  if (typeof lib.getFeatureList !== "function" || !lib.getFeatureList()?.msePlayback)
    return "mpegts.js 已載入，但目前 Chrome 環境不支援必要的 MediaSource／MSE 播放能力。";
  return "";
}
async function bundledMpegtsLibrary() {
  const problem = mpegtsLibraryProblem();
  if (problem) {
    console.warn("[NotionDrive FLV]", problem);
    return null;
  }
  return globalThis.mpegts;
}

async function showPreview(item, controller) {
  const isCurrent=()=>!controller.signal.aborted && state.previewController===controller && state.preview?.id===item.id;
  if(!isCurrent())return;
  // Release the last player's SourceBuffers before replacing the original stage.
  state.mediaPreviewPlayer?.destroy();
  state.mediaPreviewPlayer = null;
  state.previewMemorySource?.close();state.previewMemorySource=null;
  els.previewName.textContent = item.name;
  setPreviewMeta(t("encryptedPreviewMeta", [formatBytes(item.size), formatDate(item.modifiedAt)]));
  els.previewStage.classList.remove("image-preview-stage");
  els.previewStage.innerHTML = "";
  let node;
  if (item.archiveFormat === RAW_VIDEO_FORMAT) {
    const video = document.createElement("video");
    video.controls = true; video.playsInline = true; video.preload = "auto";
    els.previewStage.replaceChildren(video);
    $("#favoritePreviewButton").textContent = item.favorite ? t("favoritedButton") : t("favoriteButton");
    setPreviewMeta(`${formatBytes(item.size)} · 原始影片（未加密） · ${formatDate(item.modifiedAt)}`);
    openPreviewDialog();
    if (ext(item.name) !== "flv" && item.mime !== "video/x-flv") {
      // Chrome natively handles supported containers; preload=auto is a hint, not a guarantee of full download.
      video.src = remoteFetchUrl(item.url);
      video.play().catch(() => {});
      return;
    }
    let player = null;
    try {
      const mpegLib = await bundledMpegtsLibrary();
      if (controller.signal.aborted) return;
      if (mpegLib) {
        // Range seeking is attempted only in plaintext FLV mode. No attempt to
        // reuse encrypted NDRVENC1's sequential volume reader for arbitrary seek.
        let currentUrl=item.url,closed=false;
        const read=createRefreshingRangeReader({signal:controller.signal,
          load:(from,to,signal)=>readExactHttpRange(remoteFetchUrl(currentUrl),from,to,{signal}),
          refresh:async()=>{
            const latest=await resolveFreshFile(item,controller.signal);
            if(latest.blockId!==item.blockId||latest.size!==item.size)throw Error('原始影片已變更，已停止讀取');
            currentUrl=latest.url;
          },
        });
        const rawSource=cachePreviewSource({ready:async()=>({total:item.size}),
          readRange:async(from,to,signal)=>{if(closed)throw new DOMException('預覽已關閉','AbortError');return read(from,to,signal);},
          close(){closed=true;},
        },controller.signal);
        player = mpegLib.createPlayer({type: "flv", isLive: false, url: "ndrive-memory://local", filesize: item.size}, {
          ...mpegtsPlaybackConfig({customLoader:encryptedFlvLoader(rawSource),enableStashBuffer:false}),
        });
        state.mediaPreviewPlayer = player;
        player.attachMediaElement(video);
        // FLV can play without keyframe metadata but that DOES NOT guarantee remote time seeking.
        let embeddedKeyframeIndex = false;
        player.on(mpegLib.Events.METADATA_ARRIVED, (meta) => {
          embeddedKeyframeIndex = !!(Array.isArray(meta?.keyframes?.times) && meta.keyframes.times.length);
          if (state.mediaPreviewPlayer === player)
            setPreviewMeta(`${formatBytes(item.size)} · 原始 FLV · ${embeddedKeyframeIndex ? "內建 keyframes 索引可用，Range 待實測" : "沒有內建 keyframes 索引，遠端任意快轉未就緒"}`);
        });
        player.on(mpegLib.Events.ERROR, (kind, detail) => {
          if (state.mediaPreviewPlayer === player)
            setPreviewMeta(`FLV 播放錯誤：${String(kind)} · ${String(detail)} · Range/CORS/索引可能不足`);
        });
        // 使用者提出的實測：Range 206、162 筆索引、4:18 可直接定位。
        // 「seeked」事件單獨出現不代表遠端影像已恢復；需要有解碼畫面
        // 並且播放時間真的開始前進，才回報已恢復。
        let requestedSeek = null;
        const clock = seconds => {
          if (!Number.isFinite(seconds)) return "--:--";
          const total = Math.max(0, Math.floor(seconds));
          return `${String(Math.floor(total / 3600)).padStart(2, "0")}:${String(Math.floor(total % 3600 / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
        };
        const report = msg => {
          if (state.mediaPreviewPlayer === player) setPreviewMeta(`${formatBytes(item.size)} · 原始 FLV · mpegts.js 1.8.2 · ${msg}`);
        };
        const eventActive = () => state.mediaPreviewPlayer === player && !controller.signal.aborted;
        video.addEventListener("seeking", () => {
          if (!eventActive()) return;
          requestedSeek = { target: video.currentTime, firstPlayingAt: null, firstWallAt: 0 };
          console.info("[NotionDrive FLV] seek requested", {seconds: requestedSeek.target});
          report(`要求快轉 ${clock(requestedSeek.target)}，等待遠端資料`);
        });
        video.addEventListener("seeked", () => {
          if (eventActive() && requestedSeek) report(`已定位 ${clock(requestedSeek.target)}，等待畫面恢復`);
        });
        video.addEventListener("timeupdate", () => {
          if (!eventActive() || !requestedSeek || video.paused || video.readyState < 2) return;
          // 只看 currentTime 跳轉不足以證明解碼成功，需要播放位置實際向前推進。
          if (Math.abs(video.currentTime - requestedSeek.target) > 4) return;
          if (requestedSeek.firstPlayingAt === null) {
            requestedSeek.firstPlayingAt = video.currentTime;
            requestedSeek.firstWallAt = Date.now();
          }
          if (video.currentTime - requestedSeek.firstPlayingAt >= 0.25) {
            console.info("[NotionDrive FLV] seek playback resumed", {targetSeconds: requestedSeek.target, playingSeconds: video.currentTime});
            report(`已從 ${clock(requestedSeek.target)} 恢復播放（請在 Network 確認 206）`);
            requestedSeek = null;
          }
        });
        video.addEventListener("waiting", () => {
          if (eventActive() && requestedSeek) report(`快轉 ${clock(requestedSeek.target)}，正在等候遠端緩衝`);
        });
        video.addEventListener("progress", () => {
          if (eventActive() && !requestedSeek) {
            report(`播放緩衝約 ${Math.floor(mpegtsBufferedAhead(video))} 秒`);
          }
        });
        player.on(mpegLib.Events.ERROR, (kind, detail, info) => {
          if (eventActive()) console.warn("[NotionDrive FLV] player error", String(kind), String(detail), String(info?.msg || ""));
        });
        player.load();
        video.play().catch(()=>{});
        report("mpegts.js 已載入，可以嘗試 Range 快轉");
        return;
      }
      // Original v0.19.3 does not contain a home-built FLV MSE player.
      // Refuse to downgrade: without mpegts.js we must show a clear error.
      throw new Error(mpegtsLibraryProblem() || "FLV 播放器初始化失敗。");
    } catch (error) {
      if (!controller.signal.aborted && error.name !== "AbortError") {
        player?.destroy(); state.mediaPreviewPlayer = null;
        state.previewMemorySource?.close();
        const errorNode = document.createElement("div");
        errorNode.className = "unsupported-preview encrypted-preview";
        errorNode.textContent = `原始 FLV 播放失敗：${safeErrorMessage(error)}`;
        els.previewStage.replaceChildren(errorNode);
      }
    }
    return;
  }
  if (item.archiveFormat !== "ndrv1-gcm") {
    node = document.createElement("div");
    node.className = "unsupported-preview encrypted-preview";
    node.innerHTML =
      `<strong>${t("unsupportedEncryptedFormatTitle")}</strong><span>${t("unsupportedEncryptedFormatText")}</span>`;
    els.previewStage.append(node);
    openPreviewDialog();
    return;
  }
  const extension = ext(item.name),
    textExt = [
      "txt",
      "json",
      "csv",
      "md",
      "markdown",
      "xml",
      "yaml",
      "yml",
      "log",
      "js",
      "ts",
      "css",
      "html",
      "htm",
    ].includes(extension),
    isMedia =
      item.mime?.startsWith("video/") || item.mime?.startsWith("audio/") || ["flac", "fla"].includes(extension),
    previewable =
      item.mime?.startsWith("image/") ||
      isMedia ||
      item.mime?.startsWith("text/") ||
      item.mime === "application/pdf" ||
      textExt;
  if (!previewable) {
    node = document.createElement("div");
    node.className = "unsupported-preview encrypted-preview";
    node.innerHTML =
      `<strong>${t("noBrowserPreviewTitle")}</strong><span>${t("noBrowserPreviewText")}</span>`;
    els.previewStage.append(node);
    $("#favoritePreviewButton").textContent = item.favorite
      ? t("favoritedButton")
      : t("favoriteButton");
    openPreviewDialog();
    return;
  }
  node = document.createElement("div");
  node.className = "unsupported-preview encrypted-preview";
  node.innerHTML = `<strong>${t("localDecryptPreview")}</strong><span>${isMedia ? t("mediaPreviewPrivacy") : t("filePreviewPrivacy")}</span>`;
  els.previewStage.append(node);
  $("#favoritePreviewButton").textContent = item.favorite
    ? t("favoritedButton")
    : t("favoriteButton");
  openPreviewDialog();
  // FLV encryption stays NDRVENC1. mpegts.js receives only authenticated
  // plaintext through a custom loader; ciphertext, keys and the original
  // format are unchanged. This is an opt-in preview branch, not a migration.
  if (extension === "flv" || item.mime === "video/x-flv") {
    let encryptedSource=null, encryptedPlayer=null;
    const mpegLib=await bundledMpegtsLibrary();
    if(!isCurrent())return;
    if(mpegLib){
      try{
        const video=document.createElement("video");
        video.controls=true;video.playsInline=true;video.preload="auto";
        els.previewStage.replaceChildren(video);
        encryptedSource=await encryptedFlvSourceForItem(item,controller.signal);
        controller.signal.addEventListener("abort",()=>{encryptedSource?.close();},{once:true});
        const {total}=await encryptedSource.ready();
        if(!isCurrent())return;
        if(total!==item.size)throw new Error(`影片解密大小不符：${total} != ${item.size}`);
        // The FLV itself must have a usable onMetaData.keyframes index.
        // mpegts.js can read the index from authenticated plaintext beginning
        // at offset zero; it will request target byte ranges on seeking.
        const CustomLoader=encryptedFlvLoader(encryptedSource);
        const player=mpegLib.createPlayer({type:"flv",isLive:false,url:"ndrive-encrypted://local",filesize:total}, {
          ...mpegtsPlaybackConfig({
            customLoader:CustomLoader,
            enableWorker:false,enableStashBuffer:false
          })
        });
        encryptedPlayer=player;
        state.mediaPreviewPlayer=player;
        const report=text=>{if(state.mediaPreviewPlayer===player)setPreviewMeta(`${formatBytes(item.size)} · 加密 FLV · mpegts.js · ${text}`);};
        player.on(mpegLib.Events.METADATA_ARRIVED,meta=>{
          if(!Array.isArray(meta?.keyframes?.times)||!meta.keyframes.times.length)
            report('缺少內建關鍵影格索引；可循序播放與在已緩衝範圍尋找，任意時間快轉可能不可用');
        });
        let seekingTarget=null,at=null;
        video.addEventListener("seeking",()=>{seekingTarget=video.currentTime;at=null;report(`快轉到 ${seekingTarget.toFixed(1)} 秒，驗證解密中`);});
        video.addEventListener("timeupdate",()=>{
          if(seekingTarget===null||video.paused||video.readyState<2)return;
          if(Math.abs(video.currentTime-seekingTarget)>4)return;
          if(at===null){at=video.currentTime;return;}
          if(video.currentTime-at>=0.25){report(`已在 ${seekingTarget.toFixed(1)} 秒附近恢復播放`);seekingTarget=null;}
        });
        video.addEventListener("progress",()=>{
          if(seekingTarget===null&&state.mediaPreviewPlayer===player&&!controller.signal.aborted)
            report(`播放緩衝約 ${Math.floor(mpegtsBufferedAhead(video))} 秒`);
        });
        player.on(mpegLib.Events.ERROR,(type,detail,info)=>report(`播放錯誤：${String(type)} ${String(detail)} ${String(info?.msg||"")}`));
        player.attachMediaElement(video);
        player.load();
        video.play().catch(()=>{});
        report("分段驗證解密已啟用；可嘗試時間軸快轉");
        return;
      }catch(e){
        encryptedSource?.close();
        try{encryptedPlayer?.destroy();}catch{}
        if(state.mediaPreviewPlayer===encryptedPlayer)state.mediaPreviewPlayer=null;
        if(controller.signal.aborted)return;
        console.warn("[NotionDrive] 加密 FLV 快轉初始化失敗",e);
        // No silent downgrade: the user can still use the original sequential
        // path, but the preview must explain why fast seek is unavailable.
        setPreviewMeta(`加密 FLV Range 無法啟動：${safeErrorMessage(e)}；已停止播放（不切換其他 FLV 引擎）`);
      }
    }else{
      setPreviewMeta(mpegtsLibraryProblem());
    }
    // No self-built FLV MSE fallback: preserve ciphertext, Safe Save and the
    // original 19.3 data model, and fail visibly if mpegts.js is unavailable.
    const fallbackNode = document.createElement("div");
    fallbackNode.className = "unsupported-preview encrypted-preview";
    const heading = document.createElement("strong");
    heading.textContent = "加密 FLV 無法開始播放";
    const details = document.createElement("span");
    details.textContent = mpegLib
      ? "mpegts.js 加密 Range 啟動失敗；已停用舊的循序播放器，請查看預覽狀態或開發者主控台。"
      : mpegtsLibraryProblem();
    fallbackNode.append(heading, details);
    els.previewStage.replaceChildren(fallbackNode);
    state.mediaPreviewPlayer = null;
    return;
  }
  // Native lossless FLAC, remuxed to fMP4 MSE without re-encoding.
  // Only authenticated plaintext from the original NDRVENC1 Range reader
  // reaches the player's memory; encrypted Notion objects are unchanged.
  if (extension === "flac" || extension === "fla" ||
      ["audio/flac", "audio/x-flac"].includes(item.mime)) {
    let source=null,player=null;
    try {
      source=await encryptedFlvSourceForItem(item,controller.signal);
      controller.signal.addEventListener('abort',()=>source?.close(),{once:true});
      const {total}=await source.ready();
      if(!isCurrent())return;
      if(total!==item.size)throw Error('FLAC 明文大小與索引不符');
      const audio=document.createElement('audio');audio.controls=true;audio.preload='auto';
      els.previewStage.replaceChildren(audio);
      const report=msg=>{if(state.mediaPreviewPlayer===player&&!controller.signal.aborted)
        setPreviewMeta(`${formatBytes(item.size)} · 加密 FLAC · ${msg}`);};
      player=new ProgressiveFlacPlayer(audio,source,{signal:controller.signal,onStatus:report});
      state.mediaPreviewPlayer=player;
      await player.start();
      if(controller.signal.aborted)return;
      audio.play().catch(()=>{});
      report('無損 FLAC 分段播放已啟用，不需等到下載 100%');
      return;
    }catch(error){
      try{player?.destroy();}catch{}source?.close();
      if(controller.signal.aborted)return;
      console.warn('[NotionDrive] FLAC 串流初始化失敗，退回 19.3 原版預覽',error);
      setPreviewMeta(`FLAC 串流不可用（${safeErrorMessage(error)}），改用完整解密預覽`);
    }
  }
  // Progressive encrypted MP3: Chrome's own MPEG Audio MSE decoder.
  // Notion ciphertext is still authenticated by the shared NDRVENC1 Range reader.
  if(extension === "mp3" || item.mime === "audio/mpeg"){
    let audioSource=null, audioPlayer=null;
    try{
      if(!globalThis.MediaSource?.isTypeSupported?.('audio/mpeg'))throw Error('MSE audio/mpeg 不支援');
      audioSource=await encryptedFlvSourceForItem(item,controller.signal);
      if(!isCurrent())return;
      controller.signal.addEventListener('abort',()=>audioSource?.close(),{once:true});
      const audio=document.createElement('audio');audio.controls=true;audio.preload='auto';
      els.previewStage.replaceChildren(audio);
      const report=msg=>{if(state.mediaPreviewPlayer===audioPlayer&&!controller.signal.aborted)setPreviewMeta(`${formatBytes(item.size)} · 加密 MP3 · ${msg}`);};
      audioPlayer=new EncryptedMp3Player(audio,audioSource,{signal:controller.signal,onStatus:report});
      state.mediaPreviewPlayer=audioPlayer;
      await audioPlayer.start();
      audio.play().catch(()=>{});
      report('使用加密 Range 串流，無需先解密整首');
      return;
    }catch(error){
      try{audioPlayer?.destroy();}catch{}audioSource?.close();
      if(controller.signal.aborted)return;
      console.warn('[NotionDrive] 加密 MP3 串流初始化失敗，原版預覽回退',error);
      setPreviewMeta(`MP3 串流無法啟用（${safeErrorMessage(error)}），改用原版完整解密預覽`);
    }
  }
  // Audio: avoid the original 100%-download Blob fallback wherever Chrome
  // provides a real MSE byte stream or our sparse MP4 remux works.
  if (["aac", "adts", "m4a", "m4b", "weba"].includes(extension) ||
      ["audio/aac", "audio/mp4", "audio/webm"].includes(item.mime)) {
    let source=null,player=null;
    try {
      source=await encryptedFlvSourceForItem(item,controller.signal);
      controller.signal.addEventListener('abort',()=>source?.close(),{once:true});
      const {total}=await source.ready();
      if(!isCurrent())return;
      if(total!==item.size)throw Error('加密音訊明文大小不符');
      const isMp4=['m4a','m4b'].includes(extension)||item.mime==='audio/mp4';
      const isWebm=extension==='weba'||item.mime==='audio/webm';
      const mime=isWebm?detectWebmMseType(await source.readRange(0,Math.min(256*1024,total),controller.signal),true):'audio/aac';
      if(!isCurrent())return;
      if(!isMp4&&!mime)throw Error('音訊封裝／編碼未通過 MSE 相容性偵測');
      const audio=document.createElement('audio');audio.controls=true;audio.preload='auto';
      els.previewStage.replaceChildren(audio);
      const report=msg=>{if(state.mediaPreviewPlayer===player&&!controller.signal.aborted)setPreviewMeta(`${formatBytes(item.size)} · 加密音訊 · ${msg}`);};
      player=isMp4?new ProgressiveMp4Player(audio,source,{signal:controller.signal,onStatus:report}):
        isWebm?new EncryptedMseVideo(audio,{signal:controller.signal,onStatus:report}):
        new EncryptedMp3Player(audio,source,{signal:controller.signal,onStatus:report,mime:'audio/aac',label:'AAC'});
      state.mediaPreviewPlayer=player;
      if(isMp4)await player.start();
      else if(isWebm)await player.start(source,total,mime);
      else await player.start();
      if(controller.signal.aborted)return;
      audio.play().catch(()=>{});
      report('按需解密線上播放，不必等待整首下載完成');
      return;
    }catch(error){
      try{player?.destroy();}catch{}source?.close();
      if(controller.signal.aborted)return;
      console.warn('[NotionDrive] audio streaming failed, preserving original preview',error);
      setPreviewMeta(`音訊串流不可用（${safeErrorMessage(error)}），改用 19.3 原版完整解密預覽`);
    }
  }
  // Video preview: fMP4 uses direct MSE; ordinary H.264/AAC MP4 is remuxed
  // from authenticated sparse ranges. Unsupported formats retain original 19.3 Blob preview.
  if (item.mime?.startsWith("video/") || ["mp4","webm","m4v","mov","mkv","avi"].includes(extension)) {
    let videoSource = null, progressivePlayer = null;
    try {
      videoSource = await encryptedFlvSourceForItem(item, controller.signal);
      controller.signal.addEventListener("abort", () => videoSource?.close(), {once:true});
      const {total} = await videoSource.ready();
      if (total !== item.size) throw new Error("加密影片明文長度與索引不一致");
      // Only read the header when deciding to use MSE, never download whole media.
      const signature = await videoSource.readRange(0, Math.min(total, 256 * 1024), controller.signal);
      if(!isCurrent())return;
      const mseType = detectMseVideoType(signature, item.mime || mimeFromName(item.name));
      if (mseType && globalThis.MediaSource?.isTypeSupported?.(mseType)) {
        const video = document.createElement("video");
        video.controls=true; video.playsInline=true; video.preload="auto";
        els.previewStage.replaceChildren(video);
        const report = msg => {
          if (state.mediaPreviewPlayer === progressivePlayer && !controller.signal.aborted)
            setPreviewMeta(`${formatBytes(item.size)} · 加密影片 · ${msg}`);
        };
        progressivePlayer = new EncryptedMseVideo(video,{signal:controller.signal,onStatus:report});
        state.mediaPreviewPlayer = progressivePlayer;
        await progressivePlayer.start(videoSource,total,mseType);
        video.play().catch(()=>{});
        // starts network loading immediately; does not wait for the whole media file
        report("持續下載、驗證解密中（目前格式只支援循序播放）");
        return;
      }
      // Ordinary MP4 has no mvex; directly appending its bytes to MSE is invalid.
      // Parse the original moov once and remux a short GOP (no re-encoding).
      // This works with both faststart files and files whose moov is at EOF.
      const ordinaryMp4 = ["mp4", "m4v"].includes(extension) || item.mime === "video/mp4";
      if (ordinaryMp4) {
        const video = document.createElement("video");
        video.controls = true; video.playsInline = true; video.preload = "auto";
        els.previewStage.replaceChildren(video);
        const report = msg => {
          if (state.mediaPreviewPlayer === progressivePlayer && !controller.signal.aborted)
            setPreviewMeta(`${formatBytes(item.size)} · 加密 MP4 · ${msg}`);
        };
        progressivePlayer = new ProgressiveMp4Player(video, videoSource, {signal:controller.signal,onStatus:report});
        state.mediaPreviewPlayer = progressivePlayer;
        await progressivePlayer.start();
        if (controller.signal.aborted) return;
        video.play().catch(() => {});
        report("MP4 索引已讀取；開始按需解密播放，不必等檔案 100%");
        return;
      }
      videoSource.close();
      console.info("[NotionDrive] encrypted video MSE not available: retaining original full-Blob preview", item.name);
      setPreviewMeta(`${formatBytes(item.size)} · 此封裝無法直接 MSE 逐段播放；改用 19.3 原版完整解密預覽`);
    } catch(error) {
      try{progressivePlayer?.destroy();}catch{}
      videoSource?.close();
      if(controller.signal.aborted)return;
      console.warn("[NotionDrive] encrypted video MSE initialization failed, original preview fallback", error);
      setPreviewMeta(`逐段播放初始化失敗（${safeErrorMessage(error)}），改用 19.3 原版解密預覽`);
    }
  }
  if(controller.signal.aborted)return;
  // Restore the status node if a streaming attempt replaced it before failing.
  els.previewStage.replaceChildren(node);
  try {
    const statusText = node.querySelector("span"),
      blob = await decryptToBlob(
        item.volumes.map(volume => volumeSource(volume, controller.signal)),
        state.vmk,
        item.mime || mimeFromName(item.name),
        {
          signal: controller.signal,
          totalSize: item.size,
          onProgress: (done, total) => {
            if (statusText)
              statusText.textContent = t("decryptedProgress", [formatBytes(done), formatBytes(total)]);
          },
        },
      );
    if (
      controller.signal.aborted ||
      state.previewController !== controller ||
      state.preview?.id !== item.id
    )
      return;
    if (state.previewObjectUrl) URL.revokeObjectURL(state.previewObjectUrl);
    let preview;
    if (item.mime?.startsWith("image/")) {
      state.previewObjectUrl = URL.createObjectURL(blob);
      preview = document.createElement("img");
      preview.className = "image-preview";
      preview.alt = item.name;
      preview.src = state.previewObjectUrl;
      els.previewStage.classList.add("image-preview-stage");
    } else if (item.mime?.startsWith("video/")) {
      state.previewObjectUrl = URL.createObjectURL(blob);
      preview = document.createElement("video");
      preview.controls = true;
      preview.playsInline = true;
      preview.autoplay = true;
      preview.preload = "auto";
      preview.src = state.previewObjectUrl;
    } else if (item.mime?.startsWith("audio/") || ["flac","fla"].includes(extension)) {
      state.previewObjectUrl = URL.createObjectURL(blob);
      preview = document.createElement("audio");
      preview.controls = true;
      preview.preload = "metadata";
      preview.src = state.previewObjectUrl;
    } else if (item.mime === "application/pdf") {
      state.previewObjectUrl = URL.createObjectURL(blob);
      preview = document.createElement("iframe");
      preview.title = item.name;
      preview.src = state.previewObjectUrl;
    } else {
      preview = document.createElement("pre");
      preview.className = "text-preview";
      preview.textContent = await blob.slice(0, 2 * MiB).text();
      if(!isCurrent())return;
      if (blob.size > 2 * MiB)
        preview.textContent += `\n\n${t("previewTruncated")}`;
    }
    els.previewStage.replaceChildren(preview);
    if (preview.tagName === "VIDEO") {
      try {
        await preview.play();
      } catch {
        if(!isCurrent())return;
        preview.muted = true;
        try {
          await preview.play();
          if(!isCurrent())return;
          toast(t("autoplayMuted"), "success");
        } catch {}
      }
    }
  } catch (error) {
    if (!isCurrent() || error.name === "AbortError") return;
    const title = document.createElement("strong"),
      message = document.createElement("span");
    title.textContent = t("previewDecryptFailed");
    message.textContent = safeErrorMessage(error);
    node.replaceChildren(title, message);
  }
}

async function toggleFavorite(item) {
  const current = state.meta[item.id] || item;
  current.favorite = !current.favorite;
  state.meta[item.id] = { ...current, url: undefined };
  if (state.preview?.id === item.id) {
    state.preview.favorite = current.favorite;
    $("#favoritePreviewButton").textContent = current.favorite
      ? t("favoritedButton")
      : t("favoriteButton");
  }
  render();
  await persistLocal();
}
async function trashPage(item) {
  const ids = subtreeIds(item.id),
    previouslyTrashedIds = item.kind === "Folder"
      ? ids.filter((id) => id !== item.id && state.meta[id]?.trashed)
      : [],
    source = state.meta[item.id] || item,
    { deletedAt: _deletedAt, previouslyTrashedIds: _previouslyTrashedIds, ...baseRecord } = source;
  await notion(`/pages/${item.id}`, { method: "PATCH", body: JSON.stringify({ in_trash: true }) });
  const record = {
    ...baseRecord,
    url: undefined,
    trashed: true,
    deletedAt: new Date().toISOString(),
    ...(previouslyTrashedIds.length ? { previouslyTrashedIds } : {}),
  };
  for (const id of ids)
    if (state.meta[id])
      state.meta[id] = { ...state.meta[id], url: undefined, trashed: true };
  state.meta[item.id] = { ...record };
  state.trash = [record, ...state.trash.filter((x) => x.id !== item.id)];
  if (item.kind === "Folder") {
    state.indexedFolders.delete(item.id);
    state.indexReady = false;
  }
  if (state.preview?.id === item.id) els.previewDialog.close();
}
function openTrashConfirmation(items) {
  if (!ensureVaultVerified() || !items.length) return;
  if (state.trashRunning) {
    toast(t("deleteAlreadyRunning"));
    return;
  }
  state.pendingTrashItems = [...items];
  els.trashConfirmText.textContent = t("deleteItemsConfirm", [String(items.length)]);
  els.trashConfirmText.classList.remove("hidden");
  els.cancelTrashButton.textContent = t("cancel");
  els.cancelTrashButton.disabled = false;
  els.confirmTrashButton.disabled = false;
  if (!els.trashDialog.open) els.trashDialog.showModal();
}
function closeTrashConfirmation() {
  if (state.trashRunning) return;
  state.pendingTrashItems = [];
  if (els.trashDialog.open) els.trashDialog.close();
}
async function trashSelectedItemsSequentially() {
  if (state.trashRunning || !ensureVaultVerified()) return;
  const items = [...state.pendingTrashItems];
  if (!items.length) return;
  state.trashRunning = true;
  state.pendingTrashItems = [];
  if (els.trashDialog.open) els.trashDialog.close();
  const status = compactStatusToast(t("deletingProgress", ["0", String(items.length)]));
  let completed = 0;
  const failures = [];
  for (let index = 0; index < items.length; index++) {
    try {
      // 故意逐頁等待，避免多個 Notion PATCH 請求並行。
      await trashPage(items[index]);
      completed++;
    } catch (error) {
      failures.push({ item: items[index], error });
    }
    const processed = index + 1;
    status.update(t("deletingProgress", [String(processed), String(items.length)]));
  }
  try {
    await persistLocal();
  } catch (error) {
    failures.push({ item: null, error });
  }
  state.selectedIds.clear();
  state.selectionMode = false;
  state.selectionAnchorId = null;
  render();
  state.trashRunning = false;
  if (!failures.length) {
    status.finish(t("movedToTrash"));
  } else {
    status.finish(
      t("deleteSummary", [String(completed), String(items.length), String(failures.length)]),
      "error",
      4300,
    );
  }
}
async function restoreItem(item) {
  if (!ensureVaultVerified()) return;
  try {
    await notion(`/pages/${item.id}`, {
      method: "PATCH",
      body: JSON.stringify({ in_trash: false }),
    });
    const restoredIds = new Set(subtreeIds(item.id));
    state.trash = state.trash
      .filter((x) => x.id !== item.id)
      .map((record) => {
        if (!record.previouslyTrashedIds?.length) return record;
        const remaining = record.previouslyTrashedIds.filter((id) => !restoredIds.has(id));
        if (remaining.length === record.previouslyTrashedIds.length) return record;
        const updated = { ...record };
        if (remaining.length) updated.previouslyTrashedIds = remaining;
        else delete updated.previouslyTrashedIds;
        return updated;
      });
    const keepTrashed = new Set(item.previouslyTrashedIds || []);
    for (const id of restoredIds)
      if (state.meta[id] && !keepTrashed.has(id))
        state.meta[id] = { ...state.meta[id], trashed: false };
    const { deletedAt, previouslyTrashedIds, ...restored } = item,
      current = state.meta[item.id] || {};
    state.meta[item.id] = { ...current, ...restored, trashed: false };
    delete state.meta[item.id].deletedAt;
    delete state.meta[item.id].previouslyTrashedIds;
    if (item.kind === "Folder") {
      state.indexedFolders.delete(item.id);
      state.indexReady = false;
    }
    await persistLocal();
    render();
    toast(t("restored"), "success");
  } catch (e) {
    toast(t("restoreFailed", [String(e.message)]), "error");
  }
}

async function createChildPage(parentId, name) {
  if (!ensureVaultVerified()) throw vaultAccessError();
  await ensureNoNameCollision(parentId, name);
  await lockPage(parentId);
  const token = await encryptMetadata(
      { v: 1, kind: "folder", name },
      state.vmk,
      "page-metadata",
    ),
    body = {
      parent: { type: "page_id", page_id: parentId },
      properties: {
        title: { type: "title", title: pageTitleRich(`NDP1.${token}`) },
      },
      icon: { type: "emoji", emoji: "🔒" },
    };
  const page = await notion("/pages", {
    method: "POST",
    body: JSON.stringify(body),
  });
  await lockPage(page.id);
  state.meta[page.id] = {
    id: page.id,
    kind: "Folder",
    name,
    parentId,
    favorite: false,
    trashed: false,
    uploadedAt: new Date().toISOString(),
  };
  state.indexedFolders.add(page.id);
  await persistLocal();
  return page;
}
async function findOrCreateFolder(parentId, name) {
  const found = Object.values(state.meta).find(
    (item) =>
      item.kind === "Folder" &&
      item.parentId === parentId &&
      !item.trashed &&
      item.name === name,
  );
  if (found) return { id: found.id };
  const remote = await findRemoteNameCollision(parentId, name);
  if (remote) {
    if (remote.kind !== "Folder") throw new Error(t("nameAlreadyExists", [name]));
    return { id: remote.id };
  }
  return createChildPage(parentId, name);
}
function shortStoredName(baseId, volumeIndex, volumeCount) {
  if (volumeCount === 1) return `ND-${baseId}.ndrive.zip`;
  const index = String(volumeIndex).padStart(4, "0"),
    count = String(volumeCount).padStart(4, "0");
  return `ND-${baseId}.V${index}-${count}.ndrive.zip`;
}
async function createFileUpload(descriptor) {
  if (!Number.isFinite(descriptor.totalSize) || descriptor.totalSize <= 0)
    throw new Error(t("invalidEncryptedSize"));
  if (descriptor.totalSize > VOLUME_SIZE)
    throw new Error(t("volumeTooLarge"));
  const payload = {
    filename: descriptor.storedName,
    content_type: descriptor.contentType || "application/octet-stream",
  };
  if (descriptor.totalSize > DIRECT_LIMIT) {
    const parts = Math.ceil(descriptor.totalSize / PART_SIZE);
    if (parts > VOLUME_PARTS)
      throw new Error(t("partsTooMany"));
    payload.mode = "multi_part";
    payload.number_of_parts = parts;
  }
  return notion("/file_uploads", {
    method: "POST",
    body: JSON.stringify(payload),
    signal: descriptor.signal,
  });
}
function addTransferTask({
  file = null,
  name,
  path = "",
  type = "upload",
  detail = t("waiting"),
  destinationId = null,
}) {
  const task = {
    id: uuid(),
    file,
    name,
    path,
    type,
    status: "queued",
    progress: 0,
    detail,
    destinationId,
    offset: 0,
    controller: new AbortController(),
    cancelRequested: false,
  };
  state.uploadTasks.push(task);
  renderUploads();
  return task;
}
function addTask(file, path, destinationId) {
  return addTransferTask({
    file,
    name: file.name,
    path,
    type: "upload",
    destinationId,
  });
}
function isFinalTask(task) {
  return ["done", "failed", "cancelled"].includes(task.status);
}
function hasActiveTransfers() {
  return state.uploadTasks.some((task) => !isFinalTask(task));
}
function throwIfCancelled(task) {
  if (task.cancelRequested || task.controller.signal.aborted)
    throw new DOMException(t("cancelled"), "AbortError");
}
function cancelTask(task) {
  if (isFinalTask(task)) return;
  task.cancelRequested = true;
  task.controller.abort();
  task.status = "cancelled";
  task.detail = t("cancelled");
  renderUploads();
}
function requestCancelTask(task) {
  if (
    confirm(
      t("cancelTransferConfirm", [
        task.type === "download" ? t("downloadAction") : t("uploadAction"),
        String(task.name),
      ]),
    )
  )
    cancelTask(task);
}
function cancelAllTransfers() {
  const active = state.uploadTasks.filter((task) => !isFinalTask(task));
  if (
    active.length &&
    confirm(t("cancelAllConfirm", [String(active.length)]))
  )
    active.forEach(cancelTask);
}
function patchTask(task, patch) {
  Object.assign(task, patch);
  renderUploads();
}
function renderUploads() {
  els.uploadList.innerHTML = "";
  const total = state.uploadTasks.length,
    done = state.uploadTasks.filter((t) => t.status === "done").length,
    failed = state.uploadTasks.filter((t) => t.status === "failed").length,
    queued = state.uploadTasks.filter((t) => t.status === "queued").length,
    active = state.uploadTasks.filter((t) =>
      ["preparing", "uploading", "downloading"].includes(t.status),
    ).length;
  els.uploadSummary.textContent = total
    ? t("completedSummary", [String(done), String(total)])
    : t("noActiveWork");
  els.totalProgressText.textContent = total
    ? t("transferStatusSummary", [String(active), String(queued), String(failed)])
    : t("zeroWork");
  for (const task of state.uploadTasks) {
    const node = document.createElement("div");
    node.className = `upload-item ${task.status}`;
    const main = document.createElement("div");
    main.className = "transfer-main";
    const title = document.createElement("strong");
    title.textContent = `${task.type === "download" ? "↓" : "↑"} ${task.name}`;
    title.title = task.name;
    main.append(title);
    if (!isFinalTask(task)) {
      const cancel = document.createElement("button");
      cancel.className = "task-cancel";
      cancel.textContent = t("cancel");
      cancel.onclick = () => requestCancelTask(task);
      main.append(cancel);
    }
    const detail = document.createElement("span");
    detail.className = "transfer-detail";
    detail.textContent = task.detail;
    const track = document.createElement("div");
    track.className = "progress-track";
    const bar = document.createElement("div");
    bar.className = "progress-bar";
    bar.style.width = `${Math.round(task.progress)}%`;
    track.append(bar);
    node.append(main, detail, track);
    els.uploadList.append(node);
  }
  if (total) els.uploadPanel.classList.add("open");
  $("#cancelAllTransfers").disabled = !hasActiveTransfers();
}
function createDownloadBatch(tasks, { showSummary, summaryLabel }) {
  let resolve;
  const completion = new Promise((done) => {
      resolve = done;
    }),
    batch = {
      total: tasks.length,
      finished: 0,
      succeeded: 0,
      showSummary,
      summaryLabel,
      resolve,
      completion,
    };
  for (const task of tasks) {
    task.downloadBatch = batch;
    task.completion = new Promise((done) => {
      task.resolveCompletion = done;
    });
  }
  return batch;
}
function finishDownloadTask(task, succeeded) {
  task.resolveCompletion?.(succeeded);
  const batch = task.downloadBatch;
  if (!batch || task.downloadBatchFinished) return;
  task.downloadBatchFinished = true;
  batch.finished++;
  if (succeeded) batch.succeeded++;
  if (batch.finished !== batch.total) return;
  if (batch.showSummary)
    toast(
      t("batchCompleted", [String(batch.succeeded), String(batch.total), String(batch.summaryLabel)]),
      batch.succeeded === batch.total ? "success" : "error",
    );
  batch.resolve({ total: batch.total, succeeded: batch.succeeded });
}
function enqueueDownloadTasks(
  tasks,
  { showSummary = false, summaryLabel = t("download") } = {},
) {
  if (!tasks.length) return Promise.resolve({ total: 0, succeeded: 0 });
  const batch = createDownloadBatch(tasks, { showSummary, summaryLabel });
  downloadQueue.push(...tasks);
  startDownloadWorkers();
  return batch.completion;
}
function startDownloadWorkers() {
  while (
    activeDownloadWorkers < DOWNLOAD_WORKER_COUNT &&
    downloadQueue.length
  ) {
    activeDownloadWorkers++;
    void downloadWorker();
  }
}
async function downloadWorker() {
  try {
    while (downloadQueue.length) {
      const task = downloadQueue.shift();
      if (!task) break;
      if (task.cancelRequested || task.controller.signal.aborted) {
        if (!isFinalTask(task))
          patchTask(task, { status: "cancelled", detail: t("cancelled") });
        finishDownloadTask(task, false);
        continue;
      }
      const succeeded = await downloadOne(task);
      finishDownloadTask(task, succeeded);
    }
  } finally {
    activeDownloadWorkers--;
    if (downloadQueue.length) startDownloadWorkers();
  }
}
async function getDownloadStagingDirectory() {
  const root = await navigator.storage.getDirectory();
  return root.getDirectoryHandle(`${DOWNLOAD_STAGING_DIRECTORY}-${state.profileId}`, { create: true });
}
function stagingLockName(name) {
  return `${DOWNLOAD_STAGING_DIRECTORY}:${state.profileId}:${name}`;
}
async function holdStagingLock(name) {
  if (!navigator.locks?.request) return () => {};
  let releaseLock;
  const acquired = new Promise((resolve, reject) => {
    void navigator.locks
      .request(stagingLockName(name), async () => {
        await new Promise((release) => {
          releaseLock = release;
          resolve();
        });
      })
      .catch(reject);
  });
  await acquired;
  return () => releaseLock?.();
}
async function createDownloadStagingFile() {
  const directory = await getDownloadStagingDirectory(),
    name = `${Date.now()}-${crypto.randomUUID()}.tmp`,
    releaseLock = await holdStagingLock(name);
  try {
    const handle = await directory.getFileHandle(name, { create: true });
    return { directory, name, handle, releaseLock };
  } catch (error) {
    releaseLock();
    throw error;
  }
}
async function removeDownloadStagingFile(staging) {
  if (!staging) return;
  try {
    await staging.directory.removeEntry(staging.name);
  } catch (error) {
    if (error.name !== "NotFoundError") console.warn(safeErrorMessage(error));
  } finally {
    staging.releaseLock?.();
  }
}
async function cleanupStaleDownloadStaging() {
  if (!navigator.storage?.getDirectory) return;
  try {
    const directory = await getDownloadStagingDirectory(),
      cutoff = Date.now() - DOWNLOAD_STAGING_MAX_AGE;
    for await (const [name, handle] of directory.entries()) {
      if (handle.kind !== "file") continue;
      if (navigator.locks?.request) {
        await navigator.locks.request(
          stagingLockName(name),
          { ifAvailable: true },
          async (lock) => {
            if (!lock) return;
            try {
              await directory.removeEntry(name);
            } catch (error) {
              if (error.name !== "NotFoundError") console.warn(safeErrorMessage(error));
            }
          },
        );
        continue;
      }
      try {
        const file = await handle.getFile();
        if (file.lastModified < cutoff) await directory.removeEntry(name);
      } catch (error) {
        if (error.name !== "NotFoundError") console.warn(safeErrorMessage(error));
      }
    }
  } catch (error) {
    console.warn(safeErrorMessage(error));
  }
}

function downloadInterruptedError(reason) {
  const error = new Error(
    t("downloadsWriteFailed", [String(reason || t("unknownError"))]),
  );
  error.code = reason || "DOWNLOAD_INTERRUPTED";
  return error;
}
function waitForChromeDownload(downloadId, signal) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      chrome.downloads.onChanged.removeListener(onChanged);
      signal?.removeEventListener("abort", onAbort);
      callback(value);
    };
    const onChanged = (delta) => {
      if (delta.id !== downloadId || !delta.state?.current) return;
      if (delta.state.current === "complete") finish(resolve);
      else if (delta.state.current === "interrupted")
        finish(reject, downloadInterruptedError(delta.error?.current));
    };
    const onAbort = () => {
      void chrome.downloads.cancel(downloadId).catch(() => {});
      finish(reject, new DOMException(t("cancelled"), "AbortError"));
    };
    chrome.downloads.onChanged.addListener(onChanged);
    signal?.addEventListener("abort", onAbort, { once: true });
    if (signal?.aborted) {
      onAbort();
      return;
    }
    void chrome.downloads
      .search({ id: downloadId })
      .then(([item]) => {
        if (settled || !item) return;
        if (item.state === "complete") finish(resolve);
        else if (item.state === "interrupted")
          finish(reject, downloadInterruptedError(item.error));
      })
      .catch((error) => finish(reject, error));
  });
}
async function saveStagedFileToDownloads(task, staging) {
  throwIfCancelled(task);
  const file = await staging.handle.getFile();
  patchTask(task, {
    status: "downloading",
    progress: 99,
    detail: t("savingToDownloads"),
  });
  if (WEB_MODE) {
    if (task.webFileHandle) {
      const target = await task.webFileHandle.createWritable();
      await file.stream().pipeTo(target);
      return;
    }
    if (task.webDirectoryHandle) {
      const parts = task.downloadPath.split("/").filter(Boolean);
      const filename = parts.pop() || t("downloadFallbackName");
      let directory = task.webDirectoryHandle;
      for (const part of parts) directory = await directory.getDirectoryHandle(part, { create: true });
      const handle = await directory.getFileHandle(filename, { create: true });
      const target = await handle.createWritable();
      await file.stream().pipeTo(target);
      return;
    }
    triggerBrowserDownload(file, task.downloadPath);
    return;
  }
  const objectUrl = URL.createObjectURL(file);
  try {
    const downloadId = await chrome.downloads.download({
      url: objectUrl,
      filename: task.downloadPath,
      conflictAction: "overwrite",
      saveAs: false,
    });
    task.chromeDownloadId = downloadId;
    await waitForChromeDownload(downloadId, task.controller.signal);
  } finally {
    URL.revokeObjectURL(objectUrl);
    task.chromeDownloadId = null;
  }
}

function volumeByIndex(fresh, volumeIndex) {
  return (fresh.volumes || []).find(
    (volume) => volume.volumeIndex === volumeIndex,
  );
}
async function downloadOne(task) {
  let writable = null,
    staging = null;
  try {
    if (!ensureVaultVerified(false)) throw vaultAccessError();
    throwIfCancelled(task);
    patchTask(task, {
      status: "preparing",
      progress: 1,
      detail: t("preparingDownload"),
    });
    let fresh = await resolveFreshFile(task.item, task.controller.signal);
    throwIfCancelled(task);
    if (fresh.archiveFormat === RAW_VIDEO_FORMAT) {
      if (!task.downloadPath) throw new Error(t("downloadPathMissing"));
      staging = await createDownloadStagingFile();
      writable = await staging.handle.createWritable();
      try {
        await streamRawVideoToWritable(fresh, writable, task.controller.signal, (done) =>
          patchTask(task, { status: "downloading", progress: 1 + done / Math.max(fresh.size, 1) * 94,
            detail: t("downloadProgress", [formatBytes(done), formatBytes(fresh.size)]) }));
      } catch (error) {
        if (error.status !== 401 && error.status !== 403) throw error;
        // An expiring signed URL can be refreshed; reset the partial staging file.
        await writable.truncate(0); await writable.seek(0);
        fresh = await resolveFreshFile(task.item, task.controller.signal);
        await streamRawVideoToWritable(fresh, writable, task.controller.signal, (done) =>
          patchTask(task, {status: "downloading", progress: 1 + done / Math.max(fresh.size, 1) * 94}));
      }
      await writable.close(); writable = null;
      await saveStagedFileToDownloads(task, staging);
      patchTask(task, {status: "done", progress: 100, detail: t("downloadComplete")});
      return true;
    }
    if (fresh.archiveFormat !== "ndrv1-gcm")
      throw new Error(t("unsupportedEncryption"));
    const volumes = [...(fresh.volumes || [])].sort(
      (a, b) => a.volumeIndex - b.volumeIndex,
    );
    if (!volumes.length) throw new Error(t("downloadUrlMissing"));
    if (!task.downloadPath) throw new Error(t("downloadPathMissing"));
    staging = await createDownloadStagingFile();
    writable = await staging.handle.createWritable();
    let completedBefore = 0;
    for (let index = 0; index < volumes.length; index++) {
      throwIfCancelled(task);
      const volumeIndex = volumes[index].volumeIndex;
      let volume = volumeByIndex(fresh, volumeIndex),
        retried = false;
      while (true) {
        if (!volume?.url) throw new Error(t("downloadUrlMissing"));
        patchTask(task, {
          status: "downloading",
          progress:
            1 +
            (completedBefore / Math.max(fresh.size, 1)) *
              94,
          detail: t("downloadingVolume", [String(volumeIndex), String(volumes.length)]),
        });
        try {
          const info = await decryptToWritable(
            volumeSource(volume, task.controller.signal),
            state.vmk,
            writable,
            {
              signal: task.controller.signal,
              onProgress: (done) =>
                patchTask(task, {
                  progress:
                    1 +
                    ((completedBefore + done) / Math.max(fresh.size, 1)) *
                      94,
                  detail: t("downloadProgress", [formatBytes(completedBefore + done), formatBytes(fresh.size)]),
                }),
            },
          );
          completedBefore += info.originalSize;
          break;
        } catch (error) {
          if (!retried && (error.status === 401 || error.status === 403)) {
            retried = true;
            await writable.truncate(completedBefore);
            await writable.seek(completedBefore);
            fresh = await resolveFreshFile(task.item, task.controller.signal);
            volume = volumeByIndex(fresh, volumeIndex);
            continue;
          }
          throw error;
        }
      }
    }
    await writable.close();
    writable = null;
    if (staging) await saveStagedFileToDownloads(task, staging);
    patchTask(task, { status: "done", progress: 100, detail: t("downloadComplete") });
    if (!task.quiet) toast(t("fileDownloaded"), "success");
    return true;
  } catch (error) {
    if (writable) {
      try {
        await writable.abort();
      } catch {}
    }
    patchTask(
      task,
      error.name === "AbortError"
        ? { status: "cancelled", detail: t("cancelled") }
        : { status: "failed", detail: safeErrorMessage(error) },
    );
    if (task.chromeDownloadId) {
      try {
        await chrome.downloads.cancel(task.chromeDownloadId);
      } catch {}
      task.chromeDownloadId = null;
    }
    if (error.name !== "AbortError" && !task.quiet)
      toast(error.message, "error");
    return false;
  } finally {
    await removeDownloadStagingFile(staging);
  }
}

async function sendUpload(
  task,
  upload,
  descriptor,
  { volumeIndex, volumeCount, sourceOffset, sourceLength },
) {
  const signal = task.controller.signal,
    partSize =
      descriptor.totalSize > DIRECT_LIMIT ? PART_SIZE : descriptor.totalSize,
    totalParts = Math.ceil(descriptor.totalSize / partSize),
    progress = (done) => {
      throwIfCancelled(task);
      const overallDone = sourceOffset + done;
      patchTask(task, {
        status: "uploading",
        progress: 5 + (overallDone / Math.max(task.file.size, 1)) * 70,
        detail: t("encryptingVolume", [String(volumeIndex), String(volumeCount)]),
      });
    },
    stream = encryptedParts(descriptor, partSize, progress, signal);
  let partNumber = 0;
  for await (const bytes of stream) {
    throwIfCancelled(task);
    partNumber++;
    const form = new FormData();
    form.append(
      "file",
      new Blob([bytes], {
        type: descriptor.contentType || "application/octet-stream",
      }),
      descriptor.storedName,
    );
    if (totalParts > 1) form.append("part_number", String(partNumber));
    await notion(`/file_uploads/${upload.id}/send`, {
      method: "POST",
      body: form,
      signal,
    });
    const uploadedInVolume = (partNumber / totalParts) * sourceLength,
      overallUploaded = sourceOffset + uploadedInVolume;
    patchTask(task, {
      status: "uploading",
      progress: 5 + (overallUploaded / Math.max(task.file.size, 1)) * 88,
      detail: t("uploadingPart", [String(volumeIndex), String(volumeCount), String(partNumber), String(totalParts)]),
    });
  }
  if (totalParts > 1) {
    throwIfCancelled(task);
    await notion(`/file_uploads/${upload.id}/complete`, {
      method: "POST",
      body: "{}",
      signal,
    });
  }
}
async function sendShards(task, pageId, descriptor, { baseId, volumeIndex, volumeCount, sourceOffset, sourceLength }) {
  const signal = task.controller.signal, count = Math.ceil(descriptor.totalSize / SHARD_SIZE);
  let index = 0, pendingUploadIds = [];
  for await (const bytes of encryptedParts(descriptor, SHARD_SIZE, null, signal)) {
    throwIfCancelled(task);
    const storedName = shardName(baseId, volumeIndex, volumeCount, ++index, count);
    const upload = await createFileUpload({ storedName, totalSize: bytes.length, contentType: "application/zip", signal });
    const form = new FormData();
    form.append("file", new Blob([bytes], { type: "application/zip" }), storedName);
    await notion(`/file_uploads/${upload.id}/send`, { method: "POST", body: form, signal });
    pendingUploadIds.push(upload.id);
    // Notion allows up to 100 appended children per request. Keep a smaller
    // batch so temporary uploads are attached well before their expiry window.
    if (pendingUploadIds.length >= SHARD_ATTACH_BATCH) {
      await attachFiles(pageId, pendingUploadIds, signal);
      pendingUploadIds = [];
    }
    patchTask(task, { status: "uploading", progress: 5 + ((sourceOffset + sourceLength * index / count) / Math.max(task.file.size, 1)) * 88,
      detail: t("uploadingShard", [String(volumeIndex), String(volumeCount), String(index), String(count)]) });
  }
  if (pendingUploadIds.length) await attachFiles(pageId, pendingUploadIds, signal);
}
function mediaBlock(uploadId) {
  return {
    object: "block",
    type: "file",
    file: { type: "file_upload", file_upload: { id: uploadId } },
  };
}
async function attachFiles(pageId, uploadIds, signal) {
  const results = [];
  for (let index = 0; index < uploadIds.length; index += 100) {
    const attached = await notion(`/blocks/${pageId}/children`, {
      method: "PATCH",
      body: JSON.stringify({
        children: uploadIds.slice(index, index + 100).map(mediaBlock),
      }),
      signal,
    });
    results.push(...(attached.results || []));
  }
  return results;
}
async function encryptedPageTitle(metadata, prefix = "NDP1.") {
  const token = await encryptMetadata(metadata, state.vmk, "page-metadata");
  return `${prefix}${token}`;
}
async function findPendingFilePage(parentId, createId, signal) {
  const blocks = await listChildren(parentId, { signal }), matches = [];
  for (const block of blocks) {
    if (block.type !== "child_page" || block.in_trash) continue;
    const title = block.child_page?.title || "";
    if (!title.startsWith("NDP0.")) continue;
    try {
      const metadata = await decryptMetadata(title.slice(5), state.vmk, "page-metadata");
      if (metadata?.kind === "pending-file" && metadata?.createId === createId) matches.push(block);
    } catch {}
  }
  if (matches.length > 1) throw new Error(t("volumeIncomplete"));
  return matches[0] || null;
}
async function createFilePage(parentId, pendingMetadata, signal, pageIcon = "🔒") {
  await lockPage(parentId, signal);
  const title = await encryptedPageTitle(pendingMetadata, "NDP0.");
  try {
    const page = await notion("/pages", {
      method: "POST",
      body: JSON.stringify({
        parent: { type: "page_id", page_id: parentId },
        properties: { title: { type: "title", title: pageTitleRich(title) } },
        icon: { type: "emoji", emoji: pageIcon },
      }),
      signal,
    });
    await lockPage(page.id, signal);
    return page;
  } catch (error) {
    // If Notion created the Page but the response was lost, adopt the same
    // hidden pending Page instead of creating a duplicate.
    const adopted = await findPendingFilePage(parentId, pendingMetadata.createId, signal).catch(() => null);
    if (!adopted) throw error;
    await lockPage(adopted.id, signal);
    return adopted;
  }
}
async function commitFilePage(pageId, metadata, signal) {
  const title = await encryptedPageTitle(metadata, "NDP1.");
  await notion(`/pages/${pageId}`, {
    method: "PATCH",
    body: JSON.stringify({ properties: { title: { type: "title", title: pageTitleRich(title) } } }),
    signal,
  });
}
async function readFilePageMetadata(pageId, signal) {
  const page = await notion(`/pages/${pageId}`, { signal }), title = pageTitle(page);
  if (!title.startsWith("NDP1.")) return null;
  try { return await decryptMetadata(title.slice(5), state.vmk, "page-metadata"); }
  catch { return null; }
}
function createUploadBatch(tasks, label) {
  let resolve;
  const completion = new Promise((done) => {
      resolve = done;
    }),
    batch = {
      label,
      total: tasks.length,
      finished: 0,
      succeeded: 0,
      resolve,
      completion,
    };
  for (const task of tasks) task.batch = batch;
  return batch;
}
function finishUploadTask(task, succeeded) {
  if (!task.batch || task.batchFinished) return;
  task.batchFinished = true;
  task.batch.finished++;
  if (succeeded) task.batch.succeeded++;
  if (task.batch.finished === task.batch.total) {
    const batch = task.batch;
    if (state.vaultVerified && state.currentPageId) refreshCurrent();
    else render();
    toast(
      t("batchCompleted", [String(batch.succeeded), String(batch.total), String(batch.label)]),
      batch.succeeded === batch.total ? "success" : "error",
    );
    batch.resolve({
      total: batch.total,
      succeeded: batch.succeeded,
    });
  }
}
function enqueueUploadBatch(tasks, label) {
  if (!tasks.length) return Promise.resolve({ total: 0, succeeded: 0 });
  const batch = createUploadBatch(tasks, label);
  uploadQueue.push(...tasks);
  startUploadWorkers();
  return batch.completion;
}
function startUploadWorkers() {
  while (activeUploadWorkers < UPLOAD_WORKER_COUNT && uploadQueue.length) {
    activeUploadWorkers++;
    void uploadWorker();
  }
}
async function uploadWorker() {
  try {
    while (uploadQueue.length) {
      const task = uploadQueue.shift();
      if (!task) break;
      if (task.cancelRequested || task.controller.signal.aborted) {
        if (!isFinalTask(task))
          patchTask(task, { status: "cancelled", detail: t("cancelled") });
        finishUploadTask(task, false);
        continue;
      }
      const succeeded = await uploadOne(task);
      finishUploadTask(task, succeeded);
    }
  } finally {
    activeUploadWorkers--;
    if (uploadQueue.length) startUploadWorkers();
  }
}
async function uploadOne(task) {
  let filePage = null, committed = false, reservationKey = null;
  let reservationOwned = false, commitAttempted = false;
  const signal = task.controller.signal;
  try {
    if (!ensureVaultVerified(false)) throw vaultAccessError();
    throwIfCancelled(task);
    patchTask(task, { status: "preparing", progress: 2, detail: t("preparingFilePage") });

    const workspaceFileUploadLimit = await getWorkspaceFileUploadLimit(signal),
      mime = task.file.type || mimeFromName(task.file.name),
      volumeCount = Math.max(1, Math.ceil(task.file.size / VOLUME_SOURCE_SIZE)),
      contentId = uuid().replaceAll("-", "").toUpperCase(),
      createId = task.id,
      pendingMetadata = { v: 1, kind: "pending-file", createId };

    // Finder cannot safely represent duplicate sibling names. Keep Chrome from
    // creating a state that macOS would have to guess how to reconcile. Reserve
    // the sibling name locally too, so parallel upload workers cannot race each
    // other between the remote collision check and NDP0 creation.
    reservationKey = `${task.destinationId}:${comparableName(task.file.name)}`;
    if (uploadNameReservations.has(reservationKey))
      throw new Error(t("nameAlreadyExists", [task.file.name]));
    uploadNameReservations.add(reservationKey);
    reservationOwned = true;
    await ensureNoNameCollision(task.destinationId, task.file.name);

    // NDP0 is intentionally invisible to v0.19.2 and v0.19.3 listings.
    // Only after every payload is attached and verified do we publish NDP1.
    filePage = await createFilePage(task.destinationId, pendingMetadata, signal);
    const uploadIds = [];
    task.offset = 0;
    for (let volumeIndex = 1; volumeIndex <= volumeCount; volumeIndex++) {
      throwIfCancelled(task);
      const sourceOffset = task.offset,
        end = Math.min(sourceOffset + VOLUME_SOURCE_SIZE, task.file.size),
        sourceLength = end - sourceOffset,
        recoveryName = volumeCount === 1
          ? task.file.name
          : `${task.file.name}.volume-${String(volumeIndex).padStart(4, "0")}-of-${String(volumeCount).padStart(4, "0")}`,
        headerMetadata = await encryptMetadata({
          name: recoveryName,
          originalName: task.file.name,
          mime,
          size: task.file.size,
          volumeIndex,
          volumeCount,
          offset: sourceOffset,
          length: sourceLength,
        }, state.vmk, "file-metadata"),
        source = task.file.slice(sourceOffset, end, mime),
        storedName = shortStoredName(contentId, volumeIndex, volumeCount),
        descriptor = await createEncryptedDescriptor(source, state.vmk, storedName, true, headerMetadata);
      descriptor.contentType = "application/zip";
      descriptor.signal = signal;
      if (descriptor.totalSize > VOLUME_SIZE) throw new Error(t("uploadVolumeTooLarge"));
      if (descriptor.totalSize > workspaceFileUploadLimit) {
        await sendShards(task, filePage.id, descriptor, {
          baseId: contentId, volumeIndex, volumeCount, sourceOffset, sourceLength,
        });
      } else {
        const upload = await createFileUpload(descriptor);
        await sendUpload(task, upload, descriptor, { volumeIndex, volumeCount, sourceOffset, sourceLength });
        uploadIds.push(upload.id);
      }
      task.offset = end;
    }

    throwIfCancelled(task);
    await attachFiles(filePage.id, uploadIds, signal);
    const stagedBlocks = await listChildren(filePage.id, { signal }),
      verified = resolvePayloadSet(stagedBlocks, { contentId, volumeCount });

    const committedMetadata = {
      v: 1,
      kind: "file",
      name: task.file.name,
      mime,
      size: task.file.size,
      format: "ndrv1-gcm",
      volumes: volumeCount,
      contentId,
    };
    try {
      commitAttempted = true;
      await commitFilePage(filePage.id, committedMetadata, signal);
      committed = true;
    } catch (error) {
      // A lost PATCH response must not trash a Page that Notion already committed.
      const current = await readFilePageMetadata(filePage.id).catch(() => null);
      if (normalizeContentId(current?.contentId || "") === contentId) committed = true;
      else throw error;
    }

    const record = {
      id: filePage.id,
      kind: "File",
      name: task.file.name,
      parentId: task.destinationId,
      mime,
      size: task.file.size,
      uploadedAt: filePage.created_time || new Date().toISOString(),
      modifiedAt: new Date(task.file.lastModified).toISOString(),
      favorite: false,
      trashed: false,
      encrypted: true,
      encryptionVersion: 4,
      archiveFormat: "ndrv1-gcm",
      volumeCount,
      contentId,
      blockId: verified.blockId,
      blockIds: verified.blockIds,
    };
    state.meta[filePage.id] = record;
    patchTask(task, { status: "done", progress: 100, detail: t("uploadComplete") });
    await persistLocal();
    if (reservationOwned) uploadNameReservations.delete(reservationKey);
    return true;
  } catch (error) {
    if (filePage?.id && !committed) {
      try {
        const current = await readFilePageMetadata(filePage.id).catch(() => null);
        if (normalizeContentId(current?.contentId || "")) committed = true;
      } catch {}
    }
    // After publication was attempted, a lost response is an unknown outcome.
    // Never trash that page just because reconciliation is also unavailable.
    if (filePage?.id && !committed && !commitAttempted) {
      try {
        await notion(`/pages/${filePage.id}`, { method: "PATCH", body: JSON.stringify({ in_trash: true }) });
      } catch (cleanup) {
        error.message += `; ${t("shardCleanupFailed", [cleanup.message])}`;
      }
    }
    if (filePage?.id && !committed && commitAttempted)
      error = new Error(`${safeErrorMessage(error)}；${t("uploadCommitUncertain")}`);
    patchTask(task, error.name === "AbortError"
      ? { status: "cancelled", detail: t("cancelled") }
      : { status: "failed", detail: safeErrorMessage(error) });
    if (reservationOwned) uploadNameReservations.delete(reservationKey);
    return false;
  }
}
async function uploadLoose(files) {
  if (
    !ensureConfigured() ||
    !ensureVmk() ||
    !ensureVaultVerified()
  )
    return;
  const destinationId = state.currentPageId,
    tasks = Array.from(files || []).map((file) =>
      addTask(file, file.name, destinationId),
    );
  return enqueueUploadBatch(tasks, t("upload"));
}
async function uploadFolder(files, extraPaths = []) {
  if (
    !ensureConfigured() ||
    !ensureVmk() ||
    !ensureVaultVerified()
  )
    return;
  const destinationId = state.currentPageId,
    list = [...files];
  if (!list.length && !extraPaths.length) return;
  const tasks = list.map((file) =>
      addTask(file, relativeFilePath(file), destinationId),
    ),
    paths = new Set(extraPaths);
  list.forEach((file) => {
    const segments = relativeFilePath(file).split("/").slice(0, -1);
    for (let index = 1; index <= segments.length; index++)
      paths.add(segments.slice(0, index).join("/"));
  });
  const map = new Map();
  try {
    for (const path of [...paths].sort(
      (a, b) => a.split("/").length - b.split("/").length,
    )) {
      if (tasks.length && tasks.every((task) => task.cancelRequested)) break;
      const segments = path.split("/"),
        parentPath = segments.slice(0, -1).join("/"),
        parentId = parentPath ? map.get(parentPath) : destinationId,
        page = await findOrCreateFolder(parentId, segments.at(-1));
      map.set(path, page.id);
    }
    for (const task of tasks) {
      const parentPath = task.path.split("/").slice(0, -1).join("/");
      task.destinationId = map.get(parentPath) || destinationId;
    }
    if (!tasks.length) {
      refreshCurrent();
      toast(t("foldersCreated", [String(paths.size)]), "success");
      return;
    }
    // The choice is made once, not inside concurrently running workers.
      return enqueueUploadBatch(tasks, t("folderFilesUpload"));
  } catch (error) {
    for (const task of tasks)
      if (!isFinalTask(task))
        patchTask(
          task,
          task.cancelRequested
            ? { status: "cancelled", detail: t("cancelled") }
            : { status: "failed", detail: safeErrorMessage(error) },
        );
    toast(t("folderUploadFailed", [String(error.message)]), "error");
  }
}

function ensureConfigured(open = true) {
  const ok = !state.leaving && Boolean(state.settings?.notionToken && state.settings?.rootPageId);
  if (!ok && open) {
    toast(t("configureConnectionFirst"), "error");
    openSettings();
  }
  return ok;
}
function ensureVmk(open = true) {
  const ok = state.vmk instanceof Uint8Array && state.vmk.byteLength === 32;
  if (!ok && open) {
    toast(t("encryptionPasswordRequired"), "error");
    openSettings();
  }
  return ok;
}
function ensureVaultVerified(open = true) {
  const ok = Boolean(
    !state.leaving && state.vaultVerified &&
    state.settings?.rootPageId &&
    state.vmk instanceof Uint8Array &&
    state.vmk.byteLength === 32,
  );
  if (!ok && open) {
    toast(t("passwordOrDataDamaged"), "error");
    openSettings();
  }
  return ok;
}
function lockVault(error = vaultAccessError()) {
  releasePreviewResources();
  clearPreviewThumbnails();
  if(els.previewDialog.open)els.previewDialog.close();
  state.vaultVerified = false;
  state.backgroundIndexing = false;
  state.indexRun++;
  state.root = null;
  state.currentPageId = null;
  state.path = [];
  state.items = [];
  state.meta = {}; state.trash = []; state.indexedFolders.clear();
  state.vmk?.fill(0); state.vmk = null;
  void sessionStore.remove([profileKey("vmk")]);
  updateConnection(false);
  showNotice(safeErrorMessage(error) || t("passwordOrDataDamaged"));
}
function updateSettingsSaveState() {
  const password = $("#encryptionPasswordInput").value;
  const next = $("#newPasswordInput").value;
  const confirmation = $("#confirmEncryptionPasswordInput").value;
  const remote = state.syncPacket || (!state.settings?.notionToken && state.settings?.syncPacket);
  const credentials = remote || ($("#tokenInput").value.trim() && parseNotionPageId($("#rootPageInput").value));
  const changed = $("#profileNameInput").value.trim() !== state.settings?.name ||
    $("#tokenInput").value.trim() !== state.settings?.notionToken ||
    rootStateKey($("#rootPageInput").value) !== rootStateKey();
  const needsPassword = !state.vmk || remote || changed || !state.settings?.syncPacket || next;
  $("#saveSettingsButton").disabled = Boolean(!state.settingsUnlocked || !credentials ||
    (needsPassword && password.length < 8) || (next && (next.length < 8 || next !== confirmation)));
  $("#confirmPasswordLabel").classList.toggle("hidden", !next);
}
function setSettingsEditMode(unlocked) {
  state.settingsUnlocked = unlocked;
  for (const id of ["profileNameInput", "tokenInput", "rootPageInput", "encryptionPasswordInput", "newPasswordInput"])
    $(`#${id}`).readOnly = !unlocked;
  $("#rememberVmkInput").disabled = !unlocked;
  $("#settingsLockBar").classList.toggle("hidden", !state.settings?.rootPageId);
  $("#unlockSettingsButton").classList.toggle("hidden", unlocked);
  $("#settingsLockText").textContent = t(unlocked ? "settingsUnlocked" : "settingsLockedStatus");
  updateSettingsSaveState();
}
function openSettings() {
  if (els.settingsDialog.open) return;
  $("#profileNameInput").value = (state.syncPacket || state.settings)?.name || "API";
  $("#tokenInput").value = state.settings?.notionToken || "";
  $("#rootPageInput").value = state.settings?.rootPageId || "";
  for (const id of ["encryptionPasswordInput", "newPasswordInput", "confirmEncryptionPasswordInput"]) $(`#${id}`).value = "";
  $("#rememberVmkInput").checked = state.settings?.rememberVmk ?? true;
  els.settingsStatus.textContent = state.syncPacket || !state.settings?.notionToken && state.settings?.syncPacket ? t("unlockSyncedProfile") : "";
  setSettingsEditMode(!state.vmk);
  els.settingsDialog.showModal();
}
async function saveSettings(e) {
  e.preventDefault();
  if (hasActiveTransfers() || activeUploadWorkers || activeDownloadWorkers || state.busy > 1) {
    els.settingsStatus.textContent = t("profileBusy"); return;
  }
  const previous = state.settings, previousVmk = state.vmk, previousConfigBlockId = state.vaultConfigBlockId;
  let password = $("#encryptionPasswordInput").value, newPassword = $("#newPasswordInput").value;
  const confirmation = $("#confirmEncryptionPasswordInput").value;
  const name = $("#profileNameInput").value.trim().slice(0, 80) || "API";
  const rememberVmk = $("#rememberVmkInput").checked;
  let notionToken = $("#tokenInput").value.trim(), rootPageId = parseNotionPageId($("#rootPageInput").value);
  let committed = false;
  $("#saveSettingsButton").disabled = true;
  stopBackgroundIndex();
  state.previewController?.abort();
  await Promise.allSettled([...indexScanPromises.values()]);
  await persistTail.catch(() => {});
  try {
    if (newPassword && (newPassword.length < 8 || newPassword !== confirmation)) throw new Error(t("passwordMismatchNoChanges"));
    const incoming = state.syncPacket || (!notionToken && previous.syncPacket);
    if (incoming) ({ notionToken, rootPageId } = await decryptSyncProfile(incoming, password));
    if (!notionToken || !rootStateKey(rootPageId)) throw new Error(t("rootPageInvalid"));
    const duplicate = state.profiles.find(p => p.profileId !== state.profileId && rootStateKey(p.rootPageId) === rootStateKey(rootPageId));
    if (duplicate) throw new Error(t("duplicateRoot", [duplicate.name]));
    const rootChanged = rootStateKey(rootPageId) !== rootStateKey(previous.rootPageId);
    const changed = rootChanged || name !== previous.name || notionToken !== previous.notionToken;
    const needsPassword = !state.vmk || incoming || changed || !previous.syncPacket || newPassword;
    if (needsPassword && password.length < 8) throw new Error(t("encryptionPasswordMin"));
    state.settings = { ...previous, notionToken, rootPageId };
    const page = await validateRootPage(rootPageId);
    let vmk = previousVmk;
    if (password) {
      const unlocked = await unlockRootVmk(page.id, password, { newRoot: !previous.rootPageId || rootChanged });
      vmk = unlocked.vmk;
      if (!rootChanged && previousVmk && encodeVmk(previousVmk) !== encodeVmk(vmk)) throw vaultAccessError();
      state.vaultConfigBlockId = unlocked.blockId;
    }
    if (!vmk) throw vaultAccessError();
    // Unlocking an unchanged profile must not republish random ciphertext and
    // force every other remembered device to unlock again.
    const mustPublish = Boolean(newPassword || (incoming ? name !== incoming.name : changed || !previous.syncPacket));
    const packet = mustPublish
      ? await encryptSyncProfile({ profileId: state.profileId, name, notionToken, rootPageId: page.id }, newPassword || password)
      : incoming || previous.syncPacket;
    const rememberedCredentials = rememberVmk
      ? await encryptMetadata({ notionToken, rootPageId: page.id }, vmk, `profile-credentials:${state.profileId}:${rootStateKey(page.id)}`)
      : null;
    let passwordRewrapped = false;
    if (newPassword) {
      await rewrapRootVmk(page.id, vmk, newPassword);
      passwordRewrapped = true;
    }
    // Commit a password-recoverable, Remember-OFF state before touching local
    // Device Key data. If Remember later fails, the new password still unlocks
    // the same VMK through the encrypted Sync packet.
    const safeSettings = {
      profileId: state.profileId, name, notionToken: "", rootPageId: page.id,
      rememberVmk: false, rememberedCredentials: null, syncPacket: packet,
    };
    try {
      await localStore.set({ [profileKey("settings")]: safeSettings,
        ...(mustPublish ? { [profileKey("pendingSync")]: packet } : {}) });
    } catch (error) {
      if (passwordRewrapped) {
        try { await rewrapRootVmk(page.id, vmk, password); }
        catch (rollbackError) { error.message += `; ${safeErrorMessage(rollbackError)}`; }
      }
      throw error;
    }
    committed = true;
    state.vmk = vmk;
    state.settings = { ...safeSettings, notionToken };
    if (rootChanged) {
      // The durable preference is already OFF, so the old Root can no longer
      // auto-unlock even if IndexedDB cleanup itself has trouble.
      await forgetLocalVmk(previous.rootPageId);
      state.meta = {}; state.trash = []; state.indexReady = false; state.indexedFolders.clear();
      state.selectedIds.clear(); state.cutIds.clear(); state.selectionAnchorId = null;
      state.contextItem = null; state.renameItem = null; state.pendingTrashItems = [];
      state.query = ""; state.view = "files"; els.search.value = "";
      state.uploadTasks = []; state.preview = null; state.previewNavigationId = null;
      if (state.previewObjectUrl) URL.revokeObjectURL(state.previewObjectUrl);
      state.previewObjectUrl = null; els.previewStage.replaceChildren();
      state.pendingEncryptedState = null;
      await localStore.remove([profileKey("state")]);
    }
    if (state.pendingEncryptedState) {
      try { applySavedState(await decryptMetadata(state.pendingEncryptedState, vmk, "local-state")); }
      catch { state.meta = {}; state.trash = []; state.indexedFolders.clear(); state.indexReady = false; }
      state.pendingEncryptedState = null;
    }
    await sessionStore.set({ [profileKey("token")]: notionToken });
    if (rememberVmk) {
      try {
        await rememberUnlockedVmk(page.id, vmk, true);
        await localStore.set({ [profileKey("settings")]: {
          ...safeSettings, rememberVmk: true, rememberedCredentials,
        } });
        state.settings = { ...safeSettings, notionToken, rememberVmk: true, rememberedCredentials };
      } catch (error) {
        await forgetLocalVmk(page.id).catch(() => {});
        throw error;
      }
    } else {
      // safeSettings was persisted first, so startup cannot auto-unlock before
      // these old local Remember records are removed.
      await rememberUnlockedVmk(page.id, vmk, false);
    }
    await persistLocal();
    state.profiles = state.profiles.map(profile => profile.profileId === state.profileId ? { ...state.settings, notionToken: "" } : profile);
    renderProfiles();
    let syncError = null;
    if (mustPublish) { try { await publishProfile(packet); } catch (error) { syncError = error; } }
    if (syncError) {
      state.syncPacket = null;
      state.vaultVerified = true;
      await activateRoot(page);
      els.settingsStatus.textContent = redactSecrets(t("syncPending", [safeErrorMessage(syncError)]));
      toast(t("syncPending", [syncError.message]), "error");
    } else {
      state.leaving = true;
      location.replace(`${location.pathname}?profile=${encodeURIComponent(state.profileId)}`);
    }
  } catch (error) {
    if (!committed) {
      state.settings = previous; state.vmk = previousVmk; state.vaultConfigBlockId = previousConfigBlockId;
    } else {
      const saved = (await localStore.get([profileKey("settings")]))[profileKey("settings")];
      if (saved) {
        state.settings = { ...saved, notionToken };
        state.profiles = state.profiles.map(profile => profile.profileId === state.profileId ? saved : profile);
        $("#rememberVmkInput").checked = Boolean(saved.rememberVmk);
            }
    }
    els.settingsStatus.className = "settings-status error";
    els.settingsStatus.textContent = redactSecrets(committed ? t("savePartiallyCompleted", [safeErrorMessage(error)]) : safeErrorMessage(error));
  } finally {
    password = ""; newPassword = "";
    for (const id of ["encryptionPasswordInput", "newPasswordInput", "confirmEncryptionPasswordInput"]) $(`#${id}`).value = "";
    updateSettingsSaveState();
  }
}

async function testConnection(token, rootInput) {
  await notion("/users/me", {}, token);
  const page = await validateRootPage(rootInput, token);
  return t("connectionTestSucceeded", [pageTitle(page)]);
}

function syncNav() {
  $$(".nav-item[data-view]").forEach((b) =>
    b.classList.toggle("active", b.dataset.view === state.view),
  );
}

function isMainContentBlankTarget(target) {
  return (
    target instanceof Element &&
    Boolean(target.closest(".main-content")) &&
    !target.closest(
      ".file-card,button,input,textarea,select,label,a,.topbar,.section-heading,.notice,.loading-state,dialog",
    )
  );
}

function clearSelectionAndCutSilently() {
  const cards = [
    ...els.grid.querySelectorAll(".file-card.selected,.file-card.cut"),
  ];
  cards.forEach((card) => (card.style.transition = "none"));
  state.selectedIds.clear();
  state.cutIds.clear();
  state.selectionMode = false;
  state.selectionAnchorId = null;
  closeContextMenu();
  syncSelectionClasses();
  void els.grid.offsetWidth;
  cards.forEach((card) => card.style.removeProperty("transition"));
}

function bindMarqueeSelection() {
  const surface = $(".main-content");
  let suppressBlankClick = false;
  const suppressFollowupBlankClick = () => {
    suppressBlankClick = true;
    setTimeout(() => (suppressBlankClick = false), 0);
  };
  const finish = (event) => {
    if (!marqueeState || marqueeState.pointerId !== event.pointerId) return;
    const { box, moved } = marqueeState;
    box.remove();
    document.body.classList.remove("marquee-selecting");
    marqueeState = null;
    state.selectionMode = state.selectedIds.size > 0;
    if (moved) {
      suppressFollowupBlankClick();
      const lastSelected = filteredItems()
        .filter((item) => state.selectedIds.has(item.id))
        .at(-1);
      state.selectionAnchorId = lastSelected?.id || null;
      syncSelectionClasses();
    } else if (state.view === "files") {
      suppressFollowupBlankClick();
      clearSelectionAndCutSilently();
    } else {
      if (!state.selectedIds.size) state.selectionAnchorId = null;
      syncSelectionClasses();
    }
  };
  surface.addEventListener("click", (event) => {
    if (state.view !== "files" || !isMainContentBlankTarget(event.target))
      return;
    if (suppressBlankClick || marqueeState) return;
    clearSelectionAndCutSilently();
  });
  surface.addEventListener("contextmenu", (event) => {
    if (state.view !== "files" || !isMainContentBlankTarget(event.target))
      return;
    event.preventDefault();
    openContextMenu(null, event.clientX, event.clientY);
  });
  surface.addEventListener("pointerdown", (event) => {
    if (
      marqueeState ||
      event.button !== 0 ||
      event.pointerType === "touch" ||
      state.view === "trash" ||
      els.grid.classList.contains("hidden") ||
      !filteredItems().length
    )
      return;
    const target = event.target;
    if (!isMainContentBlankTarget(target)) return;
    closeContextMenu();
    const additive = event.ctrlKey || event.metaKey;
    if (!additive) state.selectedIds.clear();
    const box = document.createElement("div");
    box.className = "selection-marquee";
    box.hidden = true;
    document.body.append(box);
    marqueeState = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      baseIds: new Set(state.selectedIds),
      box,
      moved: false,
    };
    document.body.classList.add("marquee-selecting");
    event.preventDefault();
  });
  window.addEventListener("pointermove", (event) => {
    if (!marqueeState || marqueeState.pointerId !== event.pointerId) return;
    const left = Math.min(marqueeState.startX, event.clientX),
      top = Math.min(marqueeState.startY, event.clientY),
      right = Math.max(marqueeState.startX, event.clientX),
      bottom = Math.max(marqueeState.startY, event.clientY),
      width = right - left,
      height = bottom - top;
    if (!marqueeState.moved && Math.hypot(width, height) < 4) return;
    marqueeState.moved = true;
    marqueeState.box.hidden = false;
    Object.assign(marqueeState.box.style, {
      left: `${left}px`,
      top: `${top}px`,
      width: `${width}px`,
      height: `${height}px`,
    });
    const next = new Set(marqueeState.baseIds);
    els.grid.querySelectorAll(".file-card[data-item-id]").forEach((card) => {
      const rect = card.getBoundingClientRect();
      if (
        rect.left <= right &&
        rect.right >= left &&
        rect.top <= bottom &&
        rect.bottom >= top
      )
        next.add(card.dataset.itemId);
    });
    state.selectedIds = next;
    state.selectionMode = next.size > 0;
    syncSelectionClasses();
    event.preventDefault();
  });
  window.addEventListener("pointerup", finish);
  window.addEventListener("pointercancel", finish);
}

function bind() {
  $("#addProfileButton").onclick = () => switchProfile(null).catch(error => toast(safeErrorMessage(error), "error"));
  $("#deleteProfileButton").onclick = deleteCurrentProfile;
  // Small, existing mutations must finish before the document can switch.
  createChildPage = busyOperation(createChildPage);
  renameItem = busyOperation(renameItem);
  toggleFavorite = busyOperation(toggleFavorite);
  restoreItem = busyOperation(restoreItem);
  moveSelectedItems = busyOperation(moveSelectedItems);
  trashSelectedItemsSequentially = busyOperation(trashSelectedItemsSequentially);
  uploadFolder = busyOperation(uploadFolder);
  handleDrop = busyOperation(handleDrop);
  bindMarqueeSelection();
  bindMoveDropTarget($("#moveUpTarget"), () => state.path.at(-2)?.id || null);
  $("#settingsButton").onclick = openSettings;
  [
    "#profileNameInput",
    "#newPasswordInput",
    "#tokenInput",
    "#rootPageInput",
    "#encryptionPasswordInput",
    "#confirmEncryptionPasswordInput",
  ].forEach((selector) =>
    $(selector).addEventListener("input", updateSettingsSaveState),
  );
  $("#rememberVmkInput").addEventListener("input", () => {
      updateSettingsSaveState();
  });
  $("#unlockSettingsButton").onclick = () => {
    if (
      confirm(t("unlockSettingsConfirm"))
    ) {
      setSettingsEditMode(true);
      $("#tokenInput").focus();
    }
  };
  $("#uploadButton").onclick = () => $("#fileInput").click();
  $("#emptyUploadButton").onclick = () => $("#fileInput").click();
  $("#uploadFolderButton").onclick = () => $("#folderInput").click();
  $("#fileInput").onchange = async (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = "";
    await uploadLoose(files);
  };
  $("#folderInput").onchange = async (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = "";
    await uploadFolder(files);
  };
  els.refresh.onclick = syncCurrentFolder;
  els.newFolder.onclick = openNewFolderDialog;
  $("#folderForm").onsubmit = async (e) => {
    e.preventDefault();
    const name = $("#folderNameInput").value.trim();
    if (!name) return;
    try {
      await createChildPage(state.currentPageId, name);
      $("#folderDialog").close();
      refreshCurrent();
      toast(t("childPageCreated"), "success");
    } catch (err) {
      toast(err.message, "error");
    }
  };
  $("#renameForm").onsubmit = async (e) => {
    e.preventDefault();
    const name = $("#renameInput").value.trim(),
      item = state.renameItem;
    if (!name || !item) return;
    try {
      await renameItem(item, name);
      state.renameItem = null;
      $("#renameDialog").close();
    } catch (err) {
      toast(err.message, "error");
    }
  };
  $("#settingsForm").onsubmit = busyOperation(saveSettings);
  $("#testConnectionButton").onclick = async () => {
    const token = $("#tokenInput").value.trim(),
      rootInput = $("#rootPageInput").value.trim();
    if (!token) {
      els.settingsStatus.className = "settings-status error";
      els.settingsStatus.textContent = t("notionTokenInputRequired");
      return;
    }
    if (!parseNotionPageId(rootInput)) {
      els.settingsStatus.className = "settings-status error";
      els.settingsStatus.textContent = t("rootPageInvalid");
      return;
    }
    if (hasActiveTransfers()) {
      els.settingsStatus.className = "settings-status error";
      els.settingsStatus.textContent = t("transferInProgressNoTokenSwitch");
      return;
    }
    els.settingsStatus.className = "settings-status";
    els.settingsStatus.textContent = t("testing");
    try {
      const message = await testConnection(token, rootInput);
      els.settingsStatus.className = "settings-status success";
      els.settingsStatus.textContent = message;
    } catch (e) {
      els.settingsStatus.className = "settings-status error";
      els.settingsStatus.textContent = safeErrorMessage(e, [token]);
    }
  };
  $("#rebuildIndexButton").onclick = async () => {
    if (!ensureConfigured() || !ensureVaultVerified()) return;
    if (
      !confirm(t("rebuildIndexConfirm"))
    )
      return;
    els.settingsDialog.close();
    await rebuildIndex();
  };
  $("#newFolderContextButton").onclick = () => {
    closeContextMenu();
    openNewFolderDialog();
  };
  $("#downloadContextButton").onclick = async () => {
    const items = selectedActionItems();
    closeContextMenu();
    await downloadSelectedItems(items);
  };
  $("#renameContextButton").onclick = () => {
    const items = selectedActionItems();
    closeContextMenu();
    if (items.length === 1) openRenameDialog(items[0]);
  };
  $("#cutContextButton").onclick = () => {
    const item = state.contextItem;
    if (item) cutSelection(item);
  };
  $("#pasteIntoContextButton").onclick = () => {
    const item = state.contextItem;
    closeContextMenu();
    if (item?.kind === "Folder") pasteCutItems(item.id);
    else pasteCutItems(state.currentPageId);
  };
  $("#trashContextButton").onclick = () => {
    const items = selectedActionItems();
    closeContextMenu();
    openTrashConfirmation(items);
  };
  els.cancelTrashButton.onclick = closeTrashConfirmation;
  els.confirmTrashButton.onclick = trashSelectedItemsSequentially;
  document.addEventListener("click", (e) => {
    if (!e.target.closest("#contextMenu")) closeContextMenu();
  });
  window.addEventListener("blur", closeContextMenu);
  window.addEventListener("keydown", (event) => {
    const editing =
      event.target instanceof HTMLInputElement ||
      event.target instanceof HTMLTextAreaElement;
    if (event.key === "Escape") {
      closeContextMenu();
      if (!editing && (state.selectedIds.size || state.cutIds.size))
        cancelSelectionState();
      return;
    }
    if (editing) return;
    if (
      !event.ctrlKey &&
      !event.metaKey &&
      !event.altKey &&
      (event.key === "ArrowLeft" || event.key === "ArrowRight") &&
      navigateImagePreview(event.key === "ArrowLeft" ? -1 : 1)
    ) {
      event.preventDefault();
      return;
    }
    if (
      (event.ctrlKey || event.metaKey) &&
      event.key.toLowerCase() === "x" &&
      state.selectedIds.size
    ) {
      event.preventDefault();
      cutSelection();
    } else if (
      (event.ctrlKey || event.metaKey) &&
      event.key.toLowerCase() === "v" &&
      state.cutIds.size &&
      state.view === "files"
    ) {
      event.preventDefault();
      pasteCutItems();
    }
  });
  $$("dialog").forEach((dialog) =>
    dialog.addEventListener("click", (e) => {
      if (e.target !== dialog) return;
      if (dialog === els.trashDialog && state.trashRunning) return;
      dialog.close();
    }),
  );
  els.settingsDialog.addEventListener("close", () => {
    for (const id of ["encryptionPasswordInput", "newPasswordInput", "confirmEncryptionPasswordInput"]) $(`#${id}`).value = "";
    if (state.settings?.provisional) void rollbackProvisionalProfile();
  });
  els.trashDialog.addEventListener("cancel", (event) => {
    if (state.trashRunning) event.preventDefault();
  });
  els.trashDialog.addEventListener("close", () => {
    if (!state.trashRunning) state.pendingTrashItems = [];
  });
  els.previewDialog.addEventListener("close", () => {
    // close is queued by the browser. A later preview may already be opening.
    if (!els.previewDialog.open && state.previewDialogController === state.previewController)
      releasePreviewResources();
  });
  window.addEventListener("pagehide", releasePreviewResources);
  window.addEventListener("pagehide", clearPreviewThumbnails);
  let dragDepth = 0;
  const isFileDrag = (e) =>
    [...(e.dataTransfer?.types || [])].includes("Files");
  document.addEventListener("dragenter", (e) => {
    if (!isFileDrag(e)) return;
    e.preventDefault();
    dragDepth++;
    $("#dropOverlay").classList.remove("hidden");
  });
  document.addEventListener("dragover", (e) => {
    if (!isFileDrag(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
  });
  document.addEventListener("dragleave", (e) => {
    if (!isFileDrag(e)) return;
    e.preventDefault();
    dragDepth = Math.max(0, dragDepth - 1);
    if (!dragDepth) $("#dropOverlay").classList.add("hidden");
  });
  document.addEventListener("drop", async (e) => {
    if (!isFileDrag(e)) return;
    e.preventDefault();
    dragDepth = 0;
    await handleDrop(e.dataTransfer);
  });
  $$("button[value='cancel']").forEach(
    (b) =>
      (b.onclick = (e) => {
        e.preventDefault();
        const dialog = b.closest("dialog");
        dialog.close();
      }),
  );
  $("#closeUploadPanel").onclick = () =>
    els.uploadPanel.classList.remove("open");
  $("#cancelAllTransfers").onclick = cancelAllTransfers;
  $("#clearCompleted").onclick = () => {
    state.uploadTasks = state.uploadTasks.filter(
      (t) => !["done", "cancelled"].includes(t.status),
    );
    renderUploads();
  };
  window.addEventListener("beforeunload", (event) => {
    if (hasActiveTransfers()) {
      event.preventDefault();
      event.returnValue = "";
    }
  });
  $("#closePreviewButton").onclick = () => els.previewDialog.close();
  $("#downloadButton").onclick = () => {
    const item = state.preview;
    focusPreviewStage();
    if (item) void downloadItem(item);
  };
  $("#favoritePreviewButton").onclick = () => {
    const item = state.preview;
    focusPreviewStage();
    if (item) void toggleFavorite(item);
  };
  els.search.oninput = (e) => {
    state.query = e.target.value.trim();
    render();
  };
  $$(".segmented").forEach(
    (b) =>
      (b.onclick = () => {
        $$(".segmented").forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        state.layout = b.dataset.layout;
        render();
      }),
  );
  $$(".nav-item[data-view]").forEach(
    (b) =>
      (b.onclick = async () => {
        state.view = b.dataset.view;
        state.query = "";
        state.selectedIds.clear();
        state.selectionMode = false;
        state.selectionAnchorId = null;
        els.search.value = "";
        syncNav();
        if (state.view === "files" && state.root) {
          if (!state.currentPageId) {
            state.currentPageId = state.root.id;
            state.path = [state.root];
          }
          await refreshCurrent();
        } else render();
      }),
  );
  els.clearView.onclick = busyOperation(async () => {
    if (
      state.view === "trash" &&
      confirm(t("clearTrashConfirm"))
    ) {
      state.trash = [];
      for (const [id, item] of Object.entries(state.meta)) {
        if (!item.trashed) continue;
        delete state.meta[id];
        state.indexedFolders.delete(id);
        state.selectedIds.delete(id);
        state.cutIds.delete(id);
      }
      await persistLocal();
      render();
    }
  });
}
async function activateRoot(page) {
  if (!state.vaultVerified) throw vaultAccessError();
  if (!page.is_locked) await lockPage(page.id);
  state.root = { id: page.id, name: pageTitle(page) };
  state.meta[page.id] = {
    ...(state.meta[page.id] || {}),
    id: page.id,
    kind: "Folder",
    name: state.root.name,
    parentId: null,
    trashed: false,
  };
  state.currentPageId = page.id;
  state.path = [state.root];
  updateConnection(true);
  if (state.indexedFolders.has(page.id)) {
    await persistLocal();
    refreshCurrent();
  } else await syncCurrentFolder({ silent: true });
  startBackgroundIndex();
}
async function connectRoot() {
  try {
    const page = await notion(`/pages/${state.settings.rootPageId}`);
    state.vaultConfigBlockId = await verifyRootVmk(page.id, state.vmk);
    state.vaultVerified = true;
    await activateRoot(page);
    if (!state.vaultVerified) {
      setTimeout(openSettings, 100);
      return false;
    }
    return true;
  } catch (error) {
    lockVault(
      error.code === "VAULT_VERIFICATION_FAILED"
        ? error
        : new Error(error.message),
    );
    render();
    setTimeout(openSettings, 100);
    return false;
  }
}
async function init() {
  localizeDocument();
  bind();

  try {
    await loadLocal();
    void cleanupStaleDownloadStaging();
  } catch (e) {
    state.settings = state.settings || {
      notionToken: "",
      rootPageId: "",
      rememberVmk: true,
    };
    showNotice(safeErrorMessage(e));
  }
  if (state.leaving) return;
  if (hasChrome) chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && Object.keys(changes).some(key => key.startsWith(SYNC_PREFIX)))
      showNotice(t("syncRefreshNotice"));
  });
  render();
  if (ensureConfigured(false) && ensureVmk(false))
    await connectRoot();
  else setTimeout(openSettings, 300);
}
init();
