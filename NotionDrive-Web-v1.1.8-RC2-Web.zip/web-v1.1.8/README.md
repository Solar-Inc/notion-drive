# Notion Drive Web 1.1.8 RC2

繁體中文的靜態網頁／PWA 移植版。介面與 Web 1.1.4 基準一致，使用 Chrome 1.1.8 RC2 的 Vault、加密檔案、上傳與媒體播放核心。這是候選版；尚未完成真實 Notion 帳號、GitHub Pages、Safari 或 Mac M4 的端到端驗收。

將此資料夾加入 `Solar-Inc/notion-drive` 並等 Pages workflow 部署完成後，可從 <https://solar-inc.github.io/notion-drive/web-v1.1.8/> 開啟此版本。

## 本機啟動

需要 Python 3。不要直接雙擊 `index.html`，ES Modules、IndexedDB、Web Crypto 與 Service Worker 需要安全來源。

```sh
cd web-v1.1.8
npm start
```

在瀏覽器開啟 <http://localhost:8088/>。`npm start` 只呼叫 Python 標準函式庫，不需要 `npm install`。若是從本版本 ZIP 解壓，先進入解壓出的 `web-v1.1.8` 資料夾，再執行 `npm start`。也可直接執行 `python3 -m http.server 8088`。要停止伺服器，在終端機按 `Ctrl+C`。

## 初次連線

1. 在 Notion 建立並分享給整合的根頁面，準備 Notion API Token 與根頁面網址或 ID。
2. 在應用程式的設定中輸入 Token、根頁面與 Vault 密碼。
3. 先用可丟棄的測試 Vault 驗證上傳、下載、重新整理後解鎖與移動檔案，再匯入正式資料。

應用程式會把 Web 版設定存於目前網站來源的瀏覽器 IndexedDB；Web 版不會讀取 Chrome 擴充功能的設定，也不會跨瀏覽器同步。不要把 Token、密碼、Notion 頁面 ID 或真實附件網址寫進原始碼、issue 或公開截圖。更換網域或瀏覽器設定檔時，瀏覽器本機資料不會自動搬過去。

## 1.1.8 RC2 功能範圍

- 沿用 1.1.4 Web/PWA 的原 GUI、暗色樣式、設定畫面與本機 IndexedDB 名稱，讓既有同來源設定仍可讀取。
- 使用 RC2 的 Vault、Safe Save、AES-GCM 加密、分段上傳／下載、重試與重複檔案處理程式。
- 使用 RC2 的 FLV、MP4、FLAC、MP3 播放器及播放倍速修正。
- 影片縮圖維持播放後擷取的分頁 RAM 快取；關閉頁籤或重新載入後不保留。全檔案自動縮圖、批次補齊、跨裝置縮圖同步仍未實作。
- PWA Service Worker 只快取靜態程式檔，不快取 Notion API 回應、Token、簽署附件網址、明文或使用者檔案。

## 已知限制

- 這是 RC2 核心移植到 Web/PWA 的候選包，不等於 Chrome 擴充功能；Web 版的 Profile 同步、Chrome 下載管理器與擴充功能權限無法使用。
- Notion API CORS、附件 CDN 的 HTTP Range/CORS、上傳權限與瀏覽器媒體解碼需以你的 Notion workspace 和實際裝置驗證。可先開 `/diagnostics.html` 檢查網路端點；診斷時只輸入仍有效、且你信任的附件網址。
- 若附件 CDN 不允許瀏覽器 Range 請求，`web-config.js` 可填入你自行管理的 HTTPS CDN 代理網址。代理必須限制允許的主機，並正確轉送 `Range` 與 `Content-Range`；不要使用不明的公開代理。
- 此版本未做完整的多瀏覽器、超大檔、長時間預讀、離線外接磁碟及 4K 播放驗收。RC2 原始碼包的 Node 測試結果不能當作這個 Web 移植版已端到端通過的證據。

## 目錄

- `index.html`、`styles.css`：沿用原本 Web GUI。
- `app.js`、`crypto.js`、播放器與分段檔案：來自 Notion Drive 1.1.8 RC2 核心。
- `web-bootstrap.js`、`web-storage.js`：Web/PWA 啟動與瀏覽器本機儲存介面。
- `diagnostics.html`：Notion API CORS 與附件 Range 連線檢查。
- `THIRD_PARTY_NOTICES.md`、`vendor/`：第三方程式與授權說明。
