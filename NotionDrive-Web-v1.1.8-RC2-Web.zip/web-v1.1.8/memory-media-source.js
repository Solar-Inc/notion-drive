/** Preview-local RAM cache. Preloading never waits for MSE or playback. */
import {abortError} from './range-http.js';

function waitFor(promise, signal) {
  if (!signal) return promise;
  if (signal.aborted) return Promise.reject(abortError());
  return new Promise((resolve, reject) => {
    const cancel = () => { cleanup(); reject(abortError()); };
    const cleanup = () => signal.removeEventListener('abort', cancel);
    signal.addEventListener('abort', cancel, {once: true});
    promise.then(value => { cleanup(); resolve(value); }, error => { cleanup(); reject(error); });
  });
}

export function createMemoryMediaSource(source, {signal, onProgress = () => {}, pageSize = 4 * 1024 * 1024} = {}) {
  if (!Number.isSafeInteger(pageSize) || pageSize <= 0) throw new Error('記憶體分頁大小無效');
  const controller = new AbortController(), pages = new Map(), pending = new Map();
  let closed = false, total = 0, loaded = 0, error = null, task = null, running = false;
  const cancel = () => close();
  signal?.addEventListener('abort', cancel, {once: true});
  function check(operationSignal) {
    if (closed || signal?.aborted || operationSignal?.aborted) throw abortError();
  }
  const stats = () => ({total, loaded, complete: total > 0 && loaded === total, running, error: error?.message || null, closed, scanned});
  const notify = () => { if (!closed) onProgress(stats()); };
  let initialization;
  async function ready() {
    check();
    // A rejected initialization is not retained forever. Allow transient failure recovery.
    if (!initialization) {
      initialization = Promise.resolve().then(() => source.ready()).then(info => {
        check();
        if (!Number.isSafeInteger(info.total) || info.total <= 0) throw new Error('媒體大小無效');
        total = info.total;
        return info;
      }).catch(cause => { initialization = null; throw cause; });
    }
    return initialization;
  }
  async function getPage(index, operationSignal) {
    await ready(); check(operationSignal);
    if (pages.has(index)) return pages.get(index);
    if (!pending.has(index)) {
      const from = index * pageSize, end = Math.min(total, from + pageSize);
      const promise = Promise.resolve().then(() => source.readRange(from, end, controller.signal)).then(bytes => {
        check();
        if (!(bytes instanceof Uint8Array) || bytes.length !== end - from) throw new Error('解密媒體分頁長度不符');
        pages.set(index, bytes); loaded += bytes.length; notify();
        return bytes;
      }).finally(() => pending.delete(index));
      pending.set(index, promise);
    }
    return waitFor(pending.get(index), operationSignal);
  }
  async function readRange(from, end, operationSignal) {
    await ready(); check(operationSignal);
    if (!Number.isSafeInteger(from) || !Number.isSafeInteger(end) || from < 0 || end <= from || end > total)
      throw new Error('媒體記憶體 Range 無效');
    const output = new Uint8Array(end - from);
    for (let at = from; at < end;) {
      const index = Math.floor(at / pageSize), bytes = await getPage(index, operationSignal);
      check(operationSignal);
      const offset = at - index * pageSize, count = Math.min(end - at, bytes.length - offset);
      output.set(bytes.subarray(offset, offset + count), at - from); at += count;
    }
    return output;
  }
  async function* readParts(from, end, operationSignal) {
    await ready(); check(operationSignal);
    if (!Number.isSafeInteger(from) || !Number.isSafeInteger(end) || from < 0 || end <= from || end > total)
      throw new Error('媒體記憶體串流範圍無效');
    for (let at = from; at < end;) {
      const bytes = await getPage(Math.floor(at / pageSize), operationSignal);
      check(operationSignal);
      const offset = at % pageSize, count = Math.min(end - at, bytes.length - offset, 512 * 1024);
      yield {offset: at, data: bytes.slice(offset, offset + count)};
      at += count;
    }
  }
  // Completed plaintext pages remain in RAM for this preview, with NO LRU eviction.
  // Only consecutive successfully verified pages advance `scanned`; seeks may fill later pages.
  let scanned = 0;
  function preload() {
    check();
    if (task) return task;
    if (total > 0 && scanned === total) return Promise.resolve(stats());
    const current = (async () => {
      running = true; error = null;
      try {
        await ready(); notify();
        for (let i = Math.floor(scanned / pageSize); i < Math.ceil(total / pageSize); i++) {
          check(); await getPage(i);
          scanned = Math.min(total, (i + 1) * pageSize);
          notify();
          // Let foreground seeks, cancellation and the UI run between pages.
          await new Promise(resolve => setTimeout(resolve, 0));
        }
        check();
        return stats();
      } catch (cause) {
        if (!closed && cause.name !== 'AbortError') error = cause;
        throw cause;
      } finally { running = false; notify(); }
    })();
    task = current;
    // Observe settlement without creating an unhandled rejected child promise.
    void current.then(() => { if (task === current) task = null; },
                      () => { if (task === current) task = null; });
    return current;
  }
  function close() {
    if (closed) return;
    closed = true; running = false; controller.abort();
    signal?.removeEventListener('abort', cancel);
    source.close?.();
    for (const bytes of pages.values()) bytes.fill(0);
    pages.clear(); pending.clear(); loaded = 0;
  }
  if (signal?.aborted) close();
  return {ready, readRange, readParts, preload, close, get stats() { return stats(); }, get closed() { return closed; }};
}
