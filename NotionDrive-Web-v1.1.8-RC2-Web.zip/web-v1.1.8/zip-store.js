const encoder = new TextEncoder();
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

class Crc32 {
  constructor() { this.value = 0xffffffff; }
  update(bytes) {
    for (const byte of bytes) this.value = CRC_TABLE[(this.value ^ byte) & 0xff] ^ (this.value >>> 8);
  }
  digest() { return (this.value ^ 0xffffffff) >>> 0; }
}

function view(size) {
  const bytes = new Uint8Array(size);
  return { bytes, dv: new DataView(bytes.buffer) };
}
function u64(dv, offset, value) { dv.setBigUint64(offset, BigInt(value), true); }
function dosTimeDate(value = Date.now()) {
  const d = new Date(value);
  const year = Math.min(2107, Math.max(1980, d.getFullYear()));
  return {
    time: (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2),
    date: ((year - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate(),
  };
}
function zip64Extra(values) {
  const { bytes, dv } = view(4 + values.length * 8);
  dv.setUint16(0, 0x0001, true);
  dv.setUint16(2, values.length * 8, true);
  values.forEach((value, index) => u64(dv, 4 + index * 8, value));
  return bytes;
}

export class Zip64StoreWriter {
  constructor(writable) {
    this.writable = writable;
    this.offset = 0n;
    this.entries = [];
    this.closed = false;
  }
  async write(bytes) {
    const value = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    await this.writable.write(value);
    this.offset += BigInt(value.byteLength);
  }
  async seek(offset) {
    await this.writable.seek(Number(offset));
    this.offset = BigInt(offset);
  }
  async truncate(offset) {
    await this.writable.truncate(Number(offset));
    if (this.offset > BigInt(offset)) this.offset = BigInt(offset);
  }
  async addFile(path, producer, { modifiedAt = Date.now(), retry = 1 } = {}) {
    if (this.closed) throw new Error("ZIP writer already closed");
    const name = String(path).replaceAll("\\", "/").replace(/^\/+/, "");
    const nameBytes = encoder.encode(name);
    const { time, date } = dosTimeDate(modifiedAt);
    const flags = 0x0808;
    const localOffset = this.offset;
    const extra = zip64Extra([0n, 0n]);
    const { bytes: header, dv } = view(30);
    dv.setUint32(0, 0x04034b50, true);
    dv.setUint16(4, 45, true);
    dv.setUint16(6, flags, true);
    dv.setUint16(8, 0, true);
    dv.setUint16(10, time, true);
    dv.setUint16(12, date, true);
    dv.setUint32(14, 0, true);
    dv.setUint32(18, 0xffffffff, true);
    dv.setUint32(22, 0xffffffff, true);
    dv.setUint16(26, nameBytes.length, true);
    dv.setUint16(28, extra.length, true);
    await this.write(header);
    await this.write(nameBytes);
    await this.write(extra);
    const dataStart = this.offset;
    let crc = new Crc32(), size = 0n, attempt = 0;
    while (true) {
      crc = new Crc32();
      size = 0n;
      const sink = {
        write: async (value) => {
          const bytes = value instanceof Uint8Array ? value : new Uint8Array(value);
          crc.update(bytes);
          size += BigInt(bytes.byteLength);
          await this.write(bytes);
        },
      };
      try {
        await producer(sink, attempt);
        break;
      } catch (error) {
        if (attempt >= retry || ![401, 403].includes(Number(error?.status))) throw error;
        attempt++;
        await this.truncate(dataStart);
        await this.seek(dataStart);
      }
    }
    const { bytes: descriptor, dv: dd } = view(24);
    dd.setUint32(0, 0x08074b50, true);
    dd.setUint32(4, crc.digest(), true);
    u64(dd, 8, size);
    u64(dd, 16, size);
    await this.write(descriptor);
    this.entries.push({ nameBytes, flags, time, date, crc: crc.digest(), size, localOffset });
  }
  async close() {
    if (this.closed) return;
    const centralOffset = this.offset;
    for (const entry of this.entries) {
      const extra = zip64Extra([entry.size, entry.size, entry.localOffset]);
      const { bytes: header, dv } = view(46);
      dv.setUint32(0, 0x02014b50, true);
      dv.setUint16(4, 45, true);
      dv.setUint16(6, 45, true);
      dv.setUint16(8, entry.flags, true);
      dv.setUint16(10, 0, true);
      dv.setUint16(12, entry.time, true);
      dv.setUint16(14, entry.date, true);
      dv.setUint32(16, entry.crc, true);
      dv.setUint32(20, 0xffffffff, true);
      dv.setUint32(24, 0xffffffff, true);
      dv.setUint16(28, entry.nameBytes.length, true);
      dv.setUint16(30, extra.length, true);
      dv.setUint16(32, 0, true);
      dv.setUint16(34, 0, true);
      dv.setUint16(36, 0, true);
      dv.setUint32(38, 0, true);
      dv.setUint32(42, 0xffffffff, true);
      await this.write(header);
      await this.write(entry.nameBytes);
      await this.write(extra);
    }
    const centralSize = this.offset - centralOffset;
    const zip64Offset = this.offset;
    const { bytes: z64, dv: z } = view(56);
    z.setUint32(0, 0x06064b50, true);
    u64(z, 4, 44n);
    z.setUint16(12, 45, true);
    z.setUint16(14, 45, true);
    z.setUint32(16, 0, true);
    z.setUint32(20, 0, true);
    u64(z, 24, BigInt(this.entries.length));
    u64(z, 32, BigInt(this.entries.length));
    u64(z, 40, centralSize);
    u64(z, 48, centralOffset);
    await this.write(z64);
    const { bytes: locator, dv: l } = view(20);
    l.setUint32(0, 0x07064b50, true);
    l.setUint32(4, 0, true);
    u64(l, 8, zip64Offset);
    l.setUint32(16, 1, true);
    await this.write(locator);
    const { bytes: end, dv: e } = view(22);
    e.setUint32(0, 0x06054b50, true);
    e.setUint16(4, 0, true);
    e.setUint16(6, 0, true);
    e.setUint16(8, Math.min(0xffff, this.entries.length), true);
    e.setUint16(10, Math.min(0xffff, this.entries.length), true);
    e.setUint32(12, centralSize > 0xffffffffn ? 0xffffffff : Number(centralSize), true);
    e.setUint32(16, centralOffset > 0xffffffffn ? 0xffffffff : Number(centralOffset), true);
    e.setUint16(20, 0, true);
    await this.write(end);
    await this.writable.close();
    this.closed = true;
  }
  async abort() {
    if (this.closed) return;
    try { await this.writable.abort(); } catch {}
    this.closed = true;
  }
}
